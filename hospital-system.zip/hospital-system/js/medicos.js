// FUNCIONES DE MEMORIA COMPARTIDA ENTRE PÁGINAS (Triage <-> Asignación Médica)
function obtenerPacientesGuardados() {
    return JSON.parse(localStorage.getItem('pacientesRegistrados_SM')) || {};
}

function guardarPacienteEnMemoria(cui, datos) {
    const registro = obtenerPacientesGuardados();
    registro[cui] = datos;
    localStorage.setItem('pacientesRegistrados_SM', JSON.stringify(registro));
}

// 1. PROTOCOLOS POR ÁREA MÉDICA (Con restricciones de Sexo y Edad)
const protocolosPorArea = {
    // --- ÁREAS DE 1 MÉDICO ---
    "Ginecología": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Consulta, diagnóstico y control ginecológico general.",
        requeridos: ["Ginecólogo"],
        sexoPermitido: "Femenino"
    },
    "Pediatría": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Atención médica exclusiva para el desarrollo y salud infantil (menores de 18 años).",
        requeridos: ["Pediatra"],
        edadMax: 17
    },
    "Traumatología": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Evaluación y tratamiento conservador de lesiones óseas y musculares.",
        requeridos: ["Traumatólogo"]
    },
    "Dermatología": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Diagnóstico y tratamiento directo de afecciones de la piel.",
        requeridos: ["Dermatólogo"]
    },
    "Cardiología": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Evaluación clínica cardiovascular y control de presión arterial.",
        requeridos: ["Cardiólogo"]
    },
    "Oftalmología": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Evaluación y tratamiento directo de salud visual y ocular.",
        requeridos: ["Oftalmólogo"]
    },
    "Otorrinolaringología": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Diagnóstico y tratamiento de oído, nariz y garganta.",
        requeridos: ["Otorrinolaringólogo"]
    },
    "Gastroenterología": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Consulta y tratamiento de enfermedades del sistema digestivo.",
        requeridos: ["Gastroenterólogo"]
    },
    "Urología": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Atención de afecciones del sistema urinario y renal.",
        requeridos: ["Urólogo"]
    },
    "Medicina Interna": {
        categoria: "Consultas y Especialidades (1 Médico)",
        descripcion: "Evaluación clínica integral exclusiva para pacientes adultos (18+ años).",
        requeridos: ["Médico Internista"],
        edadMin: 18
    },

    // --- ÁREAS DE 2 MÉDICOS ---
    "Anestesiología": {
        categoria: "Atención Conjunta e Intervenciones (2 Médicos)",
        descripcion: "Evaluación conjunta de sedación, manejo del dolor y monitoreo sistémico.",
        requeridos: ["Anestesiólogo", "Médico Internista"]
    },
    "Geriatría": {
        categoria: "Atención Conjunta e Intervenciones (2 Médicos)",
        descripcion: "Atención especializada al adulto mayor (60+ años) y control de enfermedades crónicas.",
        requeridos: ["Geriatra", "Médico Internista"],
        edadMin: 60
    },
    "Neurología": {
        categoria: "Atención Conjunta e Intervenciones (2 Médicos)",
        descripcion: "Evaluación del sistema nervioso central y monitoreo clínico interno.",
        requeridos: ["Neurólogo", "Médico Internista"]
    },
    "Cirugía Traumatológica": {
        categoria: "Atención Conjunta e Intervenciones (2 Médicos)",
        descripcion: "Reducción quirúrgica de fracturas y sedación especializada.",
        requeridos: ["Traumatólogo", "Anestesiólogo"]
    },
    "Endoscopía Digestiva": {
        categoria: "Atención Conjunta e Intervenciones (2 Médicos)",
        descripcion: "Procedimiento diagnóstico digestivo bajo sedación controlada.",
        requeridos: ["Gastroenterólogo", "Anestesiólogo"]
    },
    "Urgencia Cardiológica": {
        categoria: "Atención Conjunta e Intervenciones (2 Médicos)",
        descripcion: "Estabilización hemodinámica urgente y soporte clínico sistémico.",
        requeridos: ["Cardiólogo", "Médico Internista"]
    },

    // --- ÁREAS DE 3 MÉDICOS ---
    "Maternidad y Obstetricia": {
        categoria: "Unidades Complejas y Quirófano (3 Médicos)",
        descripcion: "Atención integral para labor de parto, cesárea y recepción del recién nacido.",
        requeridos: ["Ginecólogo", "Pediatra", "Anestesiólogo"],
        sexoPermitido: "Femenino",
        edadMin: 12,
        edadMax: 60
    },
    "Cirugía General": {
        categoria: "Unidades Complejas y Quirófano (3 Médicos)",
        descripcion: "Equipo quirúrgico completo con soporte anestésico y control metabólico.",
        requeridos: ["Cirujano General", "Anestesiólogo", "Médico Internista"]
    },
    "Cuidados Intensivos": {
        categoria: "Unidades Complejas y Quirófano (3 Médicos)",
        descripcion: "Soporte vital avanzado multidisciplinario para pacientes en estado crítico.",
        requeridos: ["Intensivista", "Médico Internista", "Anestesiólogo"]
    }
};

// 2. PLANTILLA DE MÉDICOS
const medicos = [
    // Ginecólogos (4)
    { id: 1, nombre: "Dra. Patricia Castellanos", especialidad: "Ginecólogo", disponible: true, guardia: 0 },
    { id: 2, nombre: "Dr. Alejandro Solares", especialidad: "Ginecólogo", disponible: true, guardia: 0 },
    { id: 3, nombre: "Dra. Gabriela Marroquín", especialidad: "Ginecólogo", disponible: true, guardia: 0 },
    { id: 4, nombre: "Dra. Regina Morales", especialidad: "Ginecólogo", disponible: true, guardia: 0 },

    // Pediatras (4)
    { id: 5, nombre: "Dra. Natalia Gálvez", especialidad: "Pediatra", disponible: true, guardia: 0 },
    { id: 6, nombre: "Dr. Hugo Samayoa", especialidad: "Pediatra", disponible: true, guardia: 0 },
    { id: 7, nombre: "Dra. Valeria Fuentes", especialidad: "Pediatra", disponible: true, guardia: 0 },
    { id: 8, nombre: "Dr. Daniel Orellana", especialidad: "Pediatra", disponible: true, guardia: 0 },

    // Anestesiólogos (5)
    { id: 9, nombre: "Dr. Carlos Mendoza", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 10, nombre: "Dra. Elena Rostova", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 11, nombre: "Dr. Mario Villatoro", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 12, nombre: "Dra. Lucía Paredes", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 13, nombre: "Dr. Jorge Echeverría", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },

    // Médicos Internistas (6)
    { id: 14, nombre: "Dr. Roberto Chang", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 15, nombre: "Dra. Sofía Valenzuela", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 16, nombre: "Dr. Fernando Galindo", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 17, nombre: "Dra. Claudia Morales", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 18, nombre: "Dr. Javier Santizo", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 19, nombre: "Dra. Paola Méndez", especialidad: "Médico Internista", disponible: true, guardia: 0 },

    // Traumatólogos (4)
    { id: 20, nombre: "Dr. Héctor Cifuentes", especialidad: "Traumatólogo", disponible: true, guardia: 0 },
    { id: 21, nombre: "Dr. Rodrigo Pineda", especialidad: "Traumatólogo", disponible: true, guardia: 0 },
    { id: 22, nombre: "Dra. Mónica Estrada", especialidad: "Traumatólogo", disponible: true, guardia: 0 },
    { id: 23, nombre: "Dr. Sebastián Paz", especialidad: "Traumatólogo", disponible: true, guardia: 0 },

    // Dermatólogos (3)
    { id: 24, nombre: "Dra. Andrea Monterroso", especialidad: "Dermatólogo", disponible: true, guardia: 0 },
    { id: 25, nombre: "Dr. Pablo Girón", especialidad: "Dermatólogo", disponible: true, guardia: 0 },
    { id: 26, nombre: "Dra. Camila Salazar", especialidad: "Dermatólogo", disponible: true, guardia: 0 },

    // Geriatras (3)
    { id: 27, nombre: "Dr. Julio Cabrera", especialidad: "Geriatra", disponible: true, guardia: 0 },
    { id: 28, nombre: "Dra. Carmen Godoy", especialidad: "Geriatra", disponible: true, guardia: 0 },
    { id: 29, nombre: "Dr. Emilio Tello", especialidad: "Geriatra", disponible: true, guardia: 0 },

    // Cardiólogos (3)
    { id: 30, nombre: "Dr. Adrián Monzón", especialidad: "Cardiólogo", disponible: true, guardia: 0 },
    { id: 31, nombre: "Dra. Silvia Pellecer", especialidad: "Cardiólogo", disponible: true, guardia: 0 },
    { id: 32, nombre: "Dr. Marco Tulio Barrios", especialidad: "Cardiólogo", disponible: true, guardia: 0 },

    // Neurólogos (3)
    { id: 33, nombre: "Dr. Esteban Coronado", especialidad: "Neurólogo", disponible: true, guardia: 0 },
    { id: 34, nombre: "Dra. Diana Recinos", especialidad: "Neurólogo", disponible: true, guardia: 0 },
    { id: 35, nombre: "Dr. César Batres", especialidad: "Neurólogo", disponible: true, guardia: 0 },

    // Oftalmólogos (2)
    { id: 36, nombre: "Dr. Sergio Arzú", especialidad: "Oftalmólogo", disponible: true, guardia: 0 },
    { id: 37, nombre: "Dra. Laura Melgar", especialidad: "Oftalmólogo", disponible: true, guardia: 0 },

    // Otorrinolaringólogos (2)
    { id: 38, nombre: "Dr. Álvaro Dardón", especialidad: "Otorrinolaringólogo", disponible: true, guardia: 0 },
    { id: 39, nombre: "Dra. Lorena Chinchilla", especialidad: "Otorrinolaringólogo", disponible: true, guardia: 0 },

    // Gastroenterólogos (3)
    { id: 40, nombre: "Dr. Mauricio Rosales", especialidad: "Gastroenterólogo", disponible: true, guardia: 0 },
    { id: 41, nombre: "Dra. Karina Polanco", especialidad: "Gastroenterólogo", disponible: true, guardia: 0 },
    { id: 42, nombre: "Dr. Tomás Velásquez", especialidad: "Gastroenterólogo", disponible: true, guardia: 0 },

    // Urólogos (2)
    { id: 43, nombre: "Dr. Ramiro Asturias", especialidad: "Urólogo", disponible: true, guardia: 0 },
    { id: 44, nombre: "Dr. Gustavo Ovalle", especialidad: "Urólogo", disponible: true, guardia: 0 },

    // Cirujanos Generales (3)
    { id: 45, nombre: "Dr. Arturo Lemus", especialidad: "Cirujano General", disponible: true, guardia: 0 },
    { id: 46, nombre: "Dra. Beatriz Barrios", especialidad: "Cirujano General", disponible: true, guardia: 0 },
    { id: 47, nombre: "Dr. Óscar Taracena", especialidad: "Cirujano General", disponible: true, guardia: 0 },

    // Intensivistas (3)
    { id: 48, nombre: "Dr. Víctor Portillo", especialidad: "Intensivista", disponible: true, guardia: 0 },
    { id: 49, nombre: "Dra. Teresa Lima", especialidad: "Intensivista", disponible: true, guardia: 0 },
    { id: 50, nombre: "Dr. Nicolás Mérida", especialidad: "Intensivista", disponible: true, guardia: 0 }
];

let asignacionesActivas = [];

// 3. REFERENCIAS DEL DOM Y MODAL
const inputPaciente = document.getElementById('nombrePaciente');
const inputCui = document.getElementById('cui');
const inputFecha = document.getElementById('fechaNacimiento');
const selectSexo = document.getElementById('sexo');
const inputBuscadorArea = document.getElementById('buscadorArea');
const inputAreaSeleccionada = document.getElementById('areaMedica');
const dropdownAreas = document.getElementById('listaAreasDropdown');
const infoProtocolo = document.getElementById('infoProtocolo');

// Limitar el calendario para que no permita fechas futuras
inputFecha.max = new Date().toISOString().split("T")[0];

function mostrarAlerta(mensaje, titulo = "Sistema Médico") {
    const modal = document.getElementById('modalSistema');
    document.getElementById('modalTitulo').textContent = titulo;
    document.getElementById('modalTexto').textContent = mensaje;
    modal.style.display = 'flex';
}

document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

function normalizarTexto(texto) {
    return texto.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

// 4. CÁLCULO DE EDAD Y VALIDACIÓN DE RESTRICCIONES POR ÁREA
function calcularEdad(fechaNacimiento) {
    if (!fechaNacimiento) return null;
    const hoy = new Date();
    const cumple = new Date(fechaNacimiento + "T00:00:00");
    let edad = hoy.getFullYear() - cumple.getFullYear();
    const mes = hoy.getMonth() - cumple.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < cumple.getDate())) {
        edad--;
    }
    return edad;
}

function evaluarCompatibilidadArea(nombreArea, sexo, edad) {
    const datos = protocolosPorArea[nombreArea];
    if (!datos) return { compatible: false, motivo: "Área médica no encontrada." };

    // Filtro por Sexo
    if (sexo && datos.sexoPermitido && datos.sexoPermitido !== sexo) {
        return {
            compatible: false,
            motivo: `El área de ${nombreArea} es exclusiva para pacientes de sexo ${datos.sexoPermitido}.`
        };
    }

    // Filtro por Edad
    if (edad !== null && !isNaN(edad)) {
        if (edad < 0) {
            return {
                compatible: false,
                motivo: "La fecha de nacimiento ingresada no puede ser una fecha futura."
            };
        }
        if (datos.edadMax !== undefined && edad > datos.edadMax) {
            return {
                compatible: false,
                motivo: `El área de ${nombreArea} solo admite pacientes de hasta ${datos.edadMax} años (el paciente tiene ${edad} años).`
            };
        }
        if (datos.edadMin !== undefined && edad < datos.edadMin) {
            return {
                compatible: false,
                motivo: `El área de ${nombreArea} requiere que el paciente tenga al menos ${datos.edadMin} años (el paciente tiene ${edad} años).`
            };
        }
    }

    return { compatible: true, motivo: "" };
}

// Verifica si un área previamente elegida deja de ser válida al cambiar sexo o fecha de nacimiento
function revalidarAreaSeleccionada() {
    const areaActual = inputAreaSeleccionada.value;
    if (areaActual) {
        const sexo = selectSexo.value;
        const edad = calcularEdad(inputFecha.value);
        const resultado = evaluarCompatibilidadArea(areaActual, sexo, edad);

        if (!resultado.compatible) {
            inputBuscadorArea.value = '';
            inputAreaSeleccionada.value = '';
            infoProtocolo.style.display = 'none';
            mostrarAlerta(
                `${resultado.motivo}\n\nSe ha removido la selección de "${areaActual}". Por favor elija un área acorde al perfil del paciente.`,
                "Área No Compatible"
            );
        }
    }
}

// 5. VALIDACIONES Y AUTORELLENO POR CUI
inputPaciente.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
});

inputCui.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
    const cuiIngresado = this.value.trim();
    const pacientesRegistrados = obtenerPacientesGuardados();

    if (pacientesRegistrados[cuiIngresado]) {
        const paciente = pacientesRegistrados[cuiIngresado];
        inputPaciente.value = paciente.nombre;
        inputFecha.value = paciente.fecha;
        selectSexo.value = paciente.sexo || paciente.genero || '';
        revalidarAreaSeleccionada();
    }
});

// Si cambia la fecha de nacimiento o el sexo, actualizamos las áreas disponibles
inputFecha.addEventListener('change', () => {
    revalidarAreaSeleccionada();
    if (dropdownAreas.style.display === 'block') {
        renderizarOpcionesArea(inputBuscadorArea.value);
    }
});

selectSexo.addEventListener('change', () => {
    revalidarAreaSeleccionada();
    if (dropdownAreas.style.display === 'block') {
        renderizarOpcionesArea(inputBuscadorArea.value);
    }
});

// 6. LÓGICA DEL BUSCADOR INTERACTIVO DE ÁREAS (Con filtrado dinámico)
function renderizarOpcionesArea(filtro = "") {
    dropdownAreas.innerHTML = "";
    const filtroNorm = normalizarTexto(filtro.trim());
    const sexoActual = selectSexo.value;
    const edadActual = calcularEdad(inputFecha.value);

    let categoriaActual = "";
    let coincidencias = 0;

    Object.entries(protocolosPorArea).forEach(([nombreArea, datos]) => {
        // 1. Verificar si el área es compatible con el sexo y la edad del paciente
        const validacion = evaluarCompatibilidadArea(nombreArea, sexoActual, edadActual);
        if (!validacion.compatible) {
            return; // Se omite/remueve de la lista desplegable
        }

        // 2. Verificar si coincide con lo escrito en el buscador
        const textoBusqueda = normalizarTexto(`${nombreArea} ${datos.requeridos.join(" ")} ${datos.descripcion}`);
        if (textoBusqueda.includes(filtroNorm)) {
            coincidencias++;
            if (datos.categoria !== categoriaActual) {
                categoriaActual = datos.categoria;
                const divCat = document.createElement('div');
                divCat.className = 'dropdown-categoria';
                divCat.textContent = categoriaActual;
                dropdownAreas.appendChild(divCat);
            }

            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">${nombreArea}</span>
                <span class="dropdown-item-sub">👨‍⚕️ ${datos.requeridos.join(' + ')}</span>
            `;

            item.addEventListener('click', () => {
                seleccionarArea(nombreArea);
            });

            dropdownAreas.appendChild(item);
        }
    });

    if (coincidencias === 0) {
        dropdownAreas.innerHTML = `<div class="dropdown-vacio">No hay áreas disponibles que coincidan con la búsqueda y el perfil (edad/sexo) del paciente.</div>`;
    }
}

function seleccionarArea(nombreArea) {
    inputBuscadorArea.value = nombreArea;
    inputAreaSeleccionada.value = nombreArea;
    dropdownAreas.style.display = 'none';

    const prot = protocolosPorArea[nombreArea];
    if (prot) {
        infoProtocolo.style.display = 'block';
        infoProtocolo.innerHTML = `<strong>Protocolo de ${nombreArea}:</strong> ${prot.descripcion}<br>
        <strong>Especialistas requeridos (${prot.requeridos.length}):</strong> ${prot.requeridos.join(' + ')}`;
    }
}

inputBuscadorArea.addEventListener('focus', () => {
    renderizarOpcionesArea(inputBuscadorArea.value);
    dropdownAreas.style.display = 'block';
});

inputBuscadorArea.addEventListener('input', function() {
    inputAreaSeleccionada.value = '';
    infoProtocolo.style.display = 'none';
    renderizarOpcionesArea(this.value);
    dropdownAreas.style.display = 'block';
});

document.addEventListener('click', (e) => {
    if (!e.target.closest('.buscador-area-container')) {
        dropdownAreas.style.display = 'none';
    }
});

function limpiarFormulario() {
    inputPaciente.value = '';
    inputCui.value = '';
    inputFecha.value = '';
    selectSexo.value = '';
    inputBuscadorArea.value = '';
    inputAreaSeleccionada.value = '';
    infoProtocolo.style.display = 'none';
    dropdownAreas.style.display = 'none';
}

document.getElementById('btnLimpiar').addEventListener('click', limpiarFormulario);

// 7. ALGORITMO VORAZ (GREEDY) PARA SELECCIÓN DE ESPECIALISTAS
function asignarEquipoMedico() {
    const paciente = inputPaciente.value.trim();
    const cui = inputCui.value.trim();
    const fecha = inputFecha.value;
    const sexo = selectSexo.value;
    const edad = calcularEdad(fecha);
    let area = inputAreaSeleccionada.value;

    // Validar si escribió el nombre exacto del área sin hacer clic en la lista
    if (!area && inputBuscadorArea.value.trim() !== '') {
        const textoEscrito = normalizarTexto(inputBuscadorArea.value.trim());
        const areaEncontrada = Object.keys(protocolosPorArea).find(
            k => normalizarTexto(k) === textoEscrito
        );
        if (areaEncontrada) {
            area = areaEncontrada;
        }
    }

    if (!paciente || !cui || !fecha || !sexo || !area) {
        mostrarAlerta("Por favor complete todos los campos del paciente (Nombre, CUI, Fecha de Nacimiento, Sexo) y seleccione un Área Médica válida.", "Datos Incompletos");
        return;
    }

    // Verificación de seguridad de edad y sexo antes de asignar
    const validacion = evaluarCompatibilidadArea(area, sexo, edad);
    if (!validacion.compatible) {
        mostrarAlerta(validacion.motivo, "Asignación No Permitida");
        inputBuscadorArea.value = '';
        inputAreaSeleccionada.value = '';
        infoProtocolo.style.display = 'none';
        return;
    }

    const especialidadesRequeridas = protocolosPorArea[area].requeridos;
    const equipoSeleccionado = [];

    for (const esp of especialidadesRequeridas) {
        const candidatos = medicos
            .filter(m => m.especialidad === esp && m.disponible && !equipoSeleccionado.includes(m))
            .sort((a, b) => a.guardia - b.guardia);

        if (candidatos.length > 0) {
            equipoSeleccionado.push(candidatos[0]);
        } else {
            mostrarAlerta(
                `No es posible completar la asignación para ${area}.\nActualmente todos los especialistas en "${esp}" están ocupados atendiendo a otros pacientes.`,
                "Personal Insuficiente"
            );
            return;
        }
    }

    // Guardar o actualizar al paciente en la memoria compartida por su CUI
    guardarPacienteEnMemoria(cui, { nombre: paciente, fecha, sexo });

    equipoSeleccionado.forEach(medico => {
        medico.disponible = false;
        medico.guardia += 1;
    });

    const nuevaAsignacion = {
        id: Date.now(),
        paciente,
        cui,
        fecha,
        edad,
        sexo,
        area,
        equipo: equipoSeleccionado
    };

    asignacionesActivas.push(nuevaAsignacion);

    const resumenEquipo = equipoSeleccionado.map(m => `• ${m.nombre} (${m.especialidad})`).join('\n');
    mostrarAlerta(
        `Paciente: ${paciente} (${edad} años)\nCUI: ${cui} | Sexo: ${sexo}\nÁrea: ${area}\n\nPersonal Asignado (${equipoSeleccionado.length}):\n${resumenEquipo}`,
        "Asignación Exitosa"
    );

    limpiarFormulario();
    actualizarUI();
}

document.getElementById('btnAsignar').addEventListener('click', asignarEquipoMedico);

// Permitir asignar con la tecla Enter en cualquiera de los campos
[inputPaciente, inputCui, inputFecha, selectSexo, inputBuscadorArea].forEach(campo => {
    campo.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            asignarEquipoMedico();
        }
    });
});

// 8. LIBERAR PERSONAL MÉDICO
document.getElementById('listaAsignaciones').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-eliminar')) {
        const idAsignacion = parseInt(e.target.getAttribute('data-id'));
        const index = asignacionesActivas.findIndex(a => a.id === idAsignacion);

        if (index !== -1) {
            asignacionesActivas[index].equipo.forEach(medico => {
                medico.disponible = true;
            });
            asignacionesActivas.splice(index, 1);
            actualizarUI();
        }
    }
});

// 9. RENDERIZADO DE LA INTERFAZ
function actualizarUI() {
    const divAsignaciones = document.getElementById('listaAsignaciones');
    divAsignaciones.innerHTML = '<h3>Equipos Médicos en Atención Activa:</h3>';

    if (asignacionesActivas.length === 0) {
        divAsignaciones.innerHTML += '<p style="justify-content: center; color: var(--text-muted);">No hay asignaciones activas en este momento.</p>';
    } else {
        asignacionesActivas.forEach(asig => {
            const listaNombres = asig.equipo.map(m => `<strong>${m.nombre}</strong> (${m.especialidad})`).join(' + ');
            const etiquetaPersonal = asig.equipo.length === 1 ? 'Médico asignado' : `Equipo (${asig.equipo.length})`;
            
            divAsignaciones.innerHTML += `
                <p style="flex-direction: column; align-items: flex-start; gap: 6px;">
                    <span style="width: 100%; display: flex; justify-content: space-between; align-items: center;">
                        <span>Paciente: <strong>${asig.paciente}</strong> (${asig.edad} años) — Área: <strong style="color: var(--primary-blue);">${asig.area}</strong></span>
                        <button class="btn-eliminar" data-id="${asig.id}" style="background-color: #2e7d32;">✔ Dar de Alta / Liberar</button>
                    </span>
                    <span style="font-size: 0.85rem; color: var(--text-muted);">
                        CUI: ${asig.cui} | Nacimiento: ${asig.fecha} | Sexo: ${asig.sexo}
                    </span>
                    <span style="font-size: 0.88rem; color: var(--text-muted);">
                        👨‍⚕️ ${etiquetaPersonal}: ${listaNombres}
                    </span>
                </p>`;
        });
    }

    const grid = document.getElementById('gridMedicos');
    grid.innerHTML = '';
    medicos.forEach(m => {
        const colorEstado = m.disponible ? '#2e7d32' : '#d32f2f';
        const textoEstado = m.disponible ? 'Disponible' : 'Ocupado';
        const fondoTarjeta = m.disponible ? '#ffffff' : '#f8f9fa';

        grid.innerHTML += `
            <div style="background: ${fondoTarjeta}; border: 1px solid var(--border-color); border-left: 4px solid ${colorEstado}; padding: 10px 12px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.04);">
                <div style="font-weight: 600; font-size: 0.92rem; color: var(--text-dark);">${m.nombre}</div>
                <div style="font-size: 0.8rem; color: var(--primary-blue); font-weight: 500;">${m.especialidad}</div>
                <div style="display: flex; justify-content: space-between; margin-top: 6px; font-size: 0.78rem;">
                    <span style="color: ${colorEstado}; font-weight: 600;">● ${textoEstado}</span>
                    <span style="color: var(--text-muted);">Turnos: ${m.guardia}</span>
                </div>
            </div>`;
    });
}

actualizarUI();