// =========================================================================
// MOTOR CENTRAL DE BASE DE DATOS DEL SISTEMA MÉDICO (js/database.js)
// Gestiona: Pacientes (CUI Constante), Historial, Egresos, Médicos, Salas,
// Enfermedades y Credenciales + Respaldo en archivo JSON e IndexedDB.
// =========================================================================

const CLAVES_TABLAS = {
    credenciales: 'credenciales_SM',
    pacientes: 'pacientesRegistrados_SM',
    historial: 'historialMedico_SM',
    egresos: 'egresosHospital_SM',
    medicos: 'medicosRRHH_SM',
    protocolos: 'protocolosRRHH_SM',
    enfermedades: 'catalogoClinicoRRHH_SM',
    salas: 'salasRRHH_SM'
};

export const HospitalDB = {
    // 1. Obtener toda la base de datos unificada
    obtenerEstadoCompleto() {
        return {
            metadata: {
                sistema: "Sistema Médico Hospitalario",
                version: "2.0",
                fechaRespaldo: new Date().toISOString()
            },
            tablas: {
                credenciales: JSON.parse(localStorage.getItem(CLAVES_TABLAS.credenciales)) || null,
                pacientes: JSON.parse(localStorage.getItem(CLAVES_TABLAS.pacientes)) || {},
                historial: JSON.parse(localStorage.getItem(CLAVES_TABLAS.historial)) || {},
                egresos: JSON.parse(localStorage.getItem(CLAVES_TABLAS.egresos)) || [],
                medicos: JSON.parse(localStorage.getItem(CLAVES_TABLAS.medicos)) || null,
                protocolos: JSON.parse(localStorage.getItem(CLAVES_TABLAS.protocolos)) || null,
                enfermedades: JSON.parse(localStorage.getItem(CLAVES_TABLAS.enfermedades)) || null,
                salas: JSON.parse(localStorage.getItem(CLAVES_TABLAS.salas)) || null
            }
        };
    },

    // 2. Guardar espejo de seguridad en IndexedDB del navegador (capacidad de cientos de MB)
    sincronizarIndexedDB() {
        if (!window.indexedDB) return;
        const request = indexedDB.open("HospitalBaseDeDatos_DB", 1);

        request.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains("respaldo_tablas")) {
                db.createObjectStore("respaldo_tablas", { keyPath: "id" });
            }
        };

        request.onsuccess = (e) => {
            const db = e.target.result;
            const tx = db.transaction("respaldo_tablas", "readwrite");
            const store = tx.objectStore("respaldo_tablas");
            store.put({
                id: "estado_principal",
                datos: this.obtenerEstadoCompleto()
            });
        };
    },

    // 3. Restaurar automáticamente desde IndexedDB si localStorage fue vaciado
    restaurarDesdeIndexedDB(callback) {
        if (!window.indexedDB) return;
        const request = indexedDB.open("HospitalBaseDeDatos_DB", 1);

        request.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains("respaldo_tablas")) {
                db.createObjectStore("respaldo_tablas", { keyPath: "id" });
            }
        };

        request.onsuccess = (e) => {
            const db = e.target.result;
            const tx = db.transaction("respaldo_tablas", "readonly");
            const store = tx.objectStore("respaldo_tablas");
            const getReq = store.get("estado_principal");

            getReq.onsuccess = () => {
                if (getReq.result && getReq.result.datos) {
                    const hayPacientesEnLocal = localStorage.getItem(CLAVES_TABLAS.pacientes);
                    if (!hayPacientesEnLocal) {
                        this.importarDesdeObjeto(getReq.result.datos, false);
                        if (typeof callback === 'function') callback();
                    }
                }
            };
        };
    },

    // 4. Descargar la Base de Datos completa en un archivo .json
    exportarArchivoJSON() {
        const datos = this.obtenerEstadoCompleto();
        const blob = new Blob([JSON.stringify(datos, null, 4)], { type: "application/json" });
        const url = URL.createObjectURL(blob);

        const enlace = document.createElement("a");
        const fechaHoy = new Date().toISOString().split("T")[0];
        enlace.href = url;
        enlace.download = `base_datos_hospital_${fechaHoy}.json`;
        document.body.appendChild(enlace);
        enlace.click();
        document.body.removeChild(enlace);
        URL.revokeObjectURL(url);
    },

    // 5. Cargar / Restaurar la Base de Datos desde un archivo .json
    importarDesdeObjeto(contenidoJSON, recargarPagina = true) {
        if (!contenidoJSON || !contenidoJSON.tablas) {
            throw new Error("El archivo no tiene el formato válido de la base de datos hospitalaria.");
        }

        const t = contenidoJSON.tablas;
        if (t.credenciales) localStorage.setItem(CLAVES_TABLAS.credenciales, JSON.stringify(t.credenciales));
        if (t.pacientes) localStorage.setItem(CLAVES_TABLAS.pacientes, JSON.stringify(t.pacientes));
        if (t.historial) localStorage.setItem(CLAVES_TABLAS.historial, JSON.stringify(t.historial));
        if (t.egresos) localStorage.setItem(CLAVES_TABLAS.egresos, JSON.stringify(t.egresos));
        if (t.medicos) localStorage.setItem(CLAVES_TABLAS.medicos, JSON.stringify(t.medicos));
        if (t.protocolos) localStorage.setItem(CLAVES_TABLAS.protocolos, JSON.stringify(t.protocolos));
        if (t.enfermedades) localStorage.setItem(CLAVES_TABLAS.enfermedades, JSON.stringify(t.enfermedades));
        if (t.salas) localStorage.setItem(CLAVES_TABLAS.salas, JSON.stringify(t.salas));

        this.sincronizarIndexedDB();
        if (recargarPagina) {
            window.location.reload();
        }
    }
};

// Sincronizar automáticamente con IndexedDB cada vez que se carga o modifica una página
HospitalDB.restaurarDesdeIndexedDB();
window.addEventListener('beforeunload', () => HospitalDB.sincronizarIndexedDB());