import { MaxHeap } from './estructuras/PriorityQueue.js';

const triageQueue = new MaxHeap();

// FUNCIONES DE MEMORIA COMPARTIDA ENTRE PÁGINAS (Solo datos personales por CUI)
function obtenerPacientesGuardados() {
    return JSON.parse(localStorage.getItem('pacientesRegistrados_SM')) || {};
}

function guardarPacienteEnMemoria(cui, datos) {
    const registro = obtenerPacientesGuardados();
    registro[cui] = datos;
    localStorage.setItem('pacientesRegistrados_SM', JSON.stringify(registro));
}

// 1. PROTOCOLOS POR ÁREA MÉDICA
const protocolosPorArea = {
    "Cirugía Plástica y Estética": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación preoperatoria, control reconstructivo y tratamientos estéticos.", requeridos: ["Cirujano Plástico"] },
    "Ginecología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Consulta, diagnóstico y control ginecológico general.", requeridos: ["Ginecólogo"], sexoPermitido: "Femenino" },
    "Pediatría": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Atención médica exclusiva para el desarrollo y salud infantil (menores de 18 años).", requeridos: ["Pediatra"], edadMax: 17 },
    "Neonatología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación especializada para recién nacidos y lactantes (0 a 1 año).", requeridos: ["Neonatólogo"], edadMax: 1 },
    "Traumatología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación y tratamiento conservador de lesiones óseas y musculares.", requeridos: ["Traumatólogo"] },
    "Dermatología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Diagnóstico y tratamiento directo de afecciones de la piel.", requeridos: ["Dermatólogo"] },
    "Cardiología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación clínica cardiovascular y control de presión arterial.", requeridos: ["Cardiólogo"] },
    "Neurología Clínica": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Consulta externa para migrañas, epilepsia y trastornos nerviosos.", requeridos: ["Neurólogo"] },
    "Neumología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Diagnóstico y tratamiento de enfermedades pulmonares y vías respiratorias.", requeridos: ["Neumólogo"] },
    "Gastroenterología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Consulta y tratamiento de enfermedades del sistema digestivo.", requeridos: ["Gastroenterólogo"] },
    "Nefrología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación de la función renal e hipertensión arterial secundaria.", requeridos: ["Nefrólogo"] },
    "Endocrinología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Control de diabetes, tiroides y trastornos hormonales o metabólicos.", requeridos: ["Endocrinólogo"] },
    "Urología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Atención general de afecciones del sistema urinario y vías renales.", requeridos: ["Urólogo"] },
    "Andrología y Control Prostático": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación urológica específica masculina y salud prostática (18+ años).", requeridos: ["Urólogo"], sexoPermitido: "Masculino", edadMin: 18 },
    "Oftalmología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación y tratamiento directo de salud visual y ocular.", requeridos: ["Oftalmólogo"] },
    "Otorrinolaringología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Diagnóstico y tratamiento de oído, nariz y garganta.", requeridos: ["Otorrinolaringólogo"] },
    "Reumatología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Tratamiento de artritis, enfermedades autoinmunes y dolor articular.", requeridos: ["Reumatólogo"] },
    "Hematología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Diagnóstico de anemias, trastornos de coagulación y enfermedades de la sangre.", requeridos: ["Hematólogo"] },
    "Infectología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Manejo de infecciones complejas, virales, bacterianas o tropicales.", requeridos: ["Infectólogo"] },
    "Oncología Médica": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Valoración diagnóstica y seguimiento clínico de tumores y cáncer.", requeridos: ["Oncólogo"] },
    "Psiquiatría y Salud Mental": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación psiquiátrica, manejo farmacológico y salud emocional.", requeridos: ["Psiquiatra"] },
    "Medicina Interna": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación clínica integral exclusiva para pacientes adultos (18+ años).", requeridos: ["Médico Internista"], edadMin: 18 },

    "Cirugía Plástica Ambulatoria": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Procedimientos reconstructivos o estéticos menores bajo sedación controlada.", requeridos: ["Cirujano Plástico", "Anestesiólogo"] },
    "Cirugía Dermatológica Reconstructiva": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Extirpación de lesiones cutáneas profundas con cierre estético reconstructivo.", requeridos: ["Cirujano Plástico", "Dermatólogo"] },
    "Anestesiología": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Evaluación conjunta de sedación, manejo del dolor agudo y monitoreo sistémico.", requeridos: ["Anestesiólogo", "Médico Internista"] },
    "Geriatría": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Atención especializada al adulto mayor (60+ años) y control de comorbilidades.", requeridos: ["Geriatra", "Médico Internista"], edadMin: 60 },
    "Neurología": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Evaluación hospitalaria del sistema nervioso central y monitoreo clínico interno.", requeridos: ["Neurólogo", "Médico Internista"] },
    "Cirugía Traumatológica": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Reducción quirúrgica de fracturas, artroscopías y sedación especializada.", requeridos: ["Traumatólogo", "Anestesiólogo"] },
    "Endoscopía Digestiva": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Procedimiento diagnóstico y terapéutico digestivo bajo sedación.", requeridos: ["Gastroenterólogo", "Anestesiólogo"] },
    "Broncoscopía Respiratoria": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Exploración invasiva de vías aéreas y pulmones bajo sedación.", requeridos: ["Neumólogo", "Anestesiólogo"] },
    "Hemodiálisis y Soporte Renal": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Terapia de reemplazo renal con monitoreo hemodinámico interno.", requeridos: ["Nefrólogo", "Médico Internista"] },
    "Quimioterapia y Control Oncológico": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Administración de tratamiento antineoplásico y estabilización sistémica.", requeridos: ["Oncólogo", "Médico Internista"] },
    "Urgencia Cardiológica": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Estabilización hemodinámica urgente de arritmias o dolor torácico.", requeridos: ["Cardiólogo", "Médico Internista"] },
    "Cirugía Oftalmológica": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Microcirugía ocular (cataratas, retina o córnea) con bloqueo anestésico.", requeridos: ["Oftalmólogo", "Anestesiólogo"] },

    "Unidad de Quemados y Cirugía Reconstructiva": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Reconstrucción de tejidos por quemaduras severas, injertos, analgesia y soporte vital.", requeridos: ["Cirujano Plástico", "Anestesiólogo", "Médico Internista"] },
    "Reconstrucción Maxilofacial y Traumática": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Cirugía combinada para fracturas graves, reconstrucción ósea y de tejidos blandos.", requeridos: ["Cirujano Plástico", "Traumatólogo", "Anestesiólogo"] },
    "Cirugía Reconstructiva Pediátrica": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Corrección quirúrgica de malformaciones congénitas (ej. labio leporino) en menores.", requeridos: ["Cirujano Plástico", "Pediatra", "Anestesiólogo"], edadMax: 17 },
    "Maternidad y Obstetricia": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Atención integral para labor de parto, cesárea y recepción del recién nacido.", requeridos: ["Ginecólogo", "Pediatra", "Anestesiólogo"], sexoPermitido: "Femenino", edadMin: 12, edadMax: 60 },
    "Parto de Alto Riesgo Neonatal": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Intervención obstétrica compleja con soporte intensivo para prematuros.", requeridos: ["Ginecólogo", "Neonatólogo", "Anestesiólogo"], sexoPermitido: "Femenino", edadMin: 12, edadMax: 60 },
    "Cirugía General": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Equipo quirúrgico completo con soporte anestésico y control metabólico.", requeridos: ["Cirujano General", "Anestesiólogo", "Médico Internista"] },
    "Cirugía Oncológica": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Resección quirúrgica de tumores complejos con estadificación oncológica en quirófano.", requeridos: ["Cirujano General", "Oncólogo", "Anestesiólogo"] },
    "Cirugía Cardiovascular": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Intervención quirúrgica de corazón o grandes vasos con monitoreo cardiológico.", requeridos: ["Cirujano Cardiovascular", "Cardiólogo", "Anestesiólogo"] },
    "Neurocirugía": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Cirugía craneal o de columna vertebral con monitoreo neurofisiológico.", requeridos: ["Neurocirujano", "Neurólogo", "Anestesiólogo"] },
    "Cuidados Intensivos": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Soporte vital avanzado multidisciplinario para pacientes en estado crítico.", requeridos: ["Intensivista", "Médico Internista", "Anestesiólogo"] }
};

// 2. CATÁLOGO DE ENFERMEDADES, DIAGNÓSTICOS Y QUEBRADURAS
const catalogoClinico = {
    // --- QUEBRADURAS Y TRAUMATISMOS ---
    "Quebradura de Cráneo / Traumatismo Craneoencefálico": { categoria: "Quebraduras y Traumatismos", gravedad: 10, areas: ["Neurocirugía", "Cuidados Intensivos", "Neurología"] },
    "Quebradura Expuesta de Fémur": { categoria: "Quebraduras y Traumatismos", gravedad: 9, areas: ["Cirugía Traumatológica", "Cuidados Intensivos", "Traumatología"] },
    "Quebradura de Cadera": { categoria: "Quebraduras y Traumatismos", gravedad: 8, areas: ["Cirugía Traumatológica", "Traumatología", "Geriatría"] },
    "Quebradura de Costillas con Trauma Torácico": { categoria: "Quebraduras y Traumatismos", gravedad: 8, areas: ["Cirugía Traumatológica", "Cuidados Intensivos", "Neumología"] },
    "Quebradura de Tibia y Peroné": { categoria: "Quebraduras y Traumatismos", gravedad: 7, areas: ["Cirugía Traumatológica", "Traumatología"] },
    "Quebradura Nasal y Maxilofacial": { categoria: "Quebraduras y Traumatismos", gravedad: 7, areas: ["Reconstrucción Maxilofacial y Traumática", "Cirugía Plástica Ambulatoria", "Otorrinolaringología"] },
    "Quebradura de Radio y Cúbito (Antebrazo)": { categoria: "Quebraduras y Traumatismos", gravedad: 6, areas: ["Traumatología", "Cirugía Traumatológica", "Pediatría"] },
    "Quebradura de Clavícula o Hombro": { categoria: "Quebraduras y Traumatismos", gravedad: 5, areas: ["Traumatología", "Cirugía Traumatológica", "Pediatría"] },
    "Quebradura de Tobillo o Pie": { categoria: "Quebraduras y Traumatismos", gravedad: 5, areas: ["Traumatología", "Cirugía Traumatológica"] },
    "Quebradura de Mano, Muñeca o Dedos": { categoria: "Quebraduras y Traumatismos", gravedad: 4, areas: ["Traumatología", "Cirugía Plástica Ambulatoria"] },
    "Luxación Articular / Esguince Grado III": { categoria: "Quebraduras y Traumatismos", gravedad: 4, areas: ["Traumatología"] },

    // --- ENFERMEDADES Y CONDICIONES ---
    "Infarto Agudo de Miocardio (Ataque Cardíaco)": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Urgencia Cardiológica", "Cirugía Cardiovascular", "Cuidados Intensivos"] },
    "Accidente Cerebrovascular (ACV / Derrame Cerebral)": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Neurocirugía", "Neurología", "Cuidados Intensivos"] },
    "Paro Cardiorrespiratorio / Choque Séptico": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Cuidados Intensivos", "Urgencia Cardiológica"] },
    "Quemaduras Severas de Segundo y Tercer Grado": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Unidad de Quemados y Cirugía Reconstructiva", "Cuidados Intensivos"] },
    "Aneurisma Cerebral / Tumor Intracraneal": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Neurocirugía", "Neurología", "Oncología Médica"] },
    "Apendicitis Aguda / Peritonitis": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Cirugía General", "Pediatría"] },
    "Insuficiencia Respiratoria Aguda / Neumonía Severa": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Cuidados Intensivos", "Neumología", "Medicina Interna"] },
    "Preeclampsia Severa / Embarazo Ectópico Roto": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Parto de Alto Riesgo Neonatal", "Maternidad y Obstetricia", "Cuidados Intensivos"], sexoPermitido: "Femenino" },
    "Síndrome de Distrés Respiratorio Neonatal / Prematurez": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Neonatología", "Parto de Alto Riesgo Neonatal"] },
    "Labor de Parto Activo / Cesárea": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Maternidad y Obstetricia", "Parto de Alto Riesgo Neonatal"], sexoPermitido: "Femenino" },
    "Valvulopatía Cardíaca / Enfermedad Arterial Coronaria": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cirugía Cardiovascular", "Cardiología", "Urgencia Cardiológica"] },
    "Insuficiencia Cardíaca Congestiva": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cardiología", "Urgencia Cardiológica", "Geriatría", "Medicina Interna"] },
    "Hemorragia Digestiva / Úlcera Péptica Perforada": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Endoscopía Digestiva", "Gastroenterología", "Cirugía General"] },
    "Insuficiencia Renal Crónica / Crisis Urémica": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Hemodiálisis y Soporte Renal", "Nefrología", "Medicina Interna"] },
    "Diabetes Descompensada / Cetoacidosis Diabética": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Endocrinología", "Medicina Interna", "Cuidados Intensivos"] },
    "Obstrucción de Vías Aéreas / Broncoaspiración": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Broncoscopía Respiratoria", "Neumología", "Pediatría"] },
    "Tumor Maligno Sólido / Neoplasia Oncológica": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cirugía Oncológica", "Quimioterapia y Control Oncológico", "Oncología Médica"] },
    "Sepsis / Infección Sistémica Aguda (Dengue Grave)": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Infectología", "Cuidados Intensivos", "Medicina Interna"] },
    "Arritmia Cardíaca / Fibrilación Auricular": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cardiología", "Urgencia Cardiológica", "Medicina Interna"] },
    "Epilepsia y Crisis Convulsivas": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Neurología", "Neurología Clínica", "Pediatría"] },
    "Colecistitis Aguda / Cálculos en la Vesícula": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cirugía General", "Gastroenterología"] },
    "Carcinoma Cutáneo / Melanoma": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cirugía Dermatológica Reconstructiva", "Dermatología", "Oncología Médica"] },
    "Anemia Severa / Leucemia / Hemofilia": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Hematología", "Oncología Médica", "Quimioterapia y Control Oncológico"] },
    "Hipertensión Arterial Descontrolada": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Cardiología", "Medicina Interna", "Nefrología", "Geriatría"] },
    "Asma Bronquial / Crisis Asmática": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Neumología", "Pediatría"] },
    "Enfermedad Pulmonar Obstructiva Crónica (EPOC)": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Neumología", "Geriatría", "Medicina Interna"] },
    "Hepatitis Viral / Cirrosis Hepática": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Gastroenterología", "Infectología", "Medicina Interna"] },
    "Cálculos Renales (Litiasis / Cólico Nefrítico)": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Urología", "Nefrología"] },
    "Gastroenteritis Aguda y Deshidratación": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Pediatría", "Gastroenterología", "Medicina Interna"] },
    "Hernia Inguinal, Umbilical o Hiatal": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía General", "Gastroenterología"] },
    "Labio Leporino / Malformación Congénita": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía Reconstructiva Pediátrica", "Cirugía Plástica y Estética", "Pediatría"] },
    "Cataratas, Glaucoma o Desprendimiento de Retina": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía Oftalmológica", "Oftalmología"] },
    "Trastorno Depresivo Mayor / Crisis de Ansiedad": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Psiquiatría y Salud Mental"] },
    "Dolor Agudo Postoperatorio / Sedación": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Anestesiología"] },
    "Enfermedad de Parkinson / Demencia Senil / Alzheimer": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Geriatría", "Neurología Clínica", "Neurología"] },
    "Quiste Ovárico / Miomatosis Uterina / Endometriosis": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Ginecología"], sexoPermitido: "Femenino" },
    "Hiperplasia Prostática Benigna / Prostatitis": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Andrología y Control Prostático", "Urología"], sexoPermitido: "Masculino" },
    "Artritis Reumatoide / Lupus / Fibromialgia": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Reumatología", "Medicina Interna", "Geriatría"] },
    "Cicatriz Queloide / Reconstrucción Estética Corporal": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Cirugía Plástica y Estética", "Cirugía Plástica Ambulatoria"] },
    "Gastritis Crónica, Colitis y Reflujo Gastroesofágico": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Gastroenterología", "Medicina Interna"] },
    "Hipotiroidismo / Hipertiroidismo / Nódulo Tiroideo": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Endocrinología", "Medicina Interna"] },
    "Infección del Tracto Urinario (Cistitis)": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Urología", "Ginecología", "Medicina Interna"] },
    "Otitis Media, Sinusitis, Rinitis o Amigdalitis": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Otorrinolaringología", "Pediatría"] },
    "Migraña y Cefalea Tensional": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Neurología Clínica", "Medicina Interna"] },
    "Dermatitis, Psoriasis, Rosácea o Acné Severo": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Dermatología"] },
    "Conjuntivitis, Miopía o Astigmatismo": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Oftalmología"] },
    "Control Ginecológico Anual": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Ginecología"], sexoPermitido: "Femenino" },

    // --- DIAGNÓSTICOS Y ESTUDIOS ---
    "Angiografía Coronaria y Cateterismo Diagnóstico": { categoria: "Diagnósticos y Estudios", gravedad: 7, areas: ["Urgencia Cardiológica", "Cirugía Cardiovascular", "Cardiología"] },
    "Tomografía Computarizada (TAC) Multicorte": { categoria: "Diagnósticos y Estudios", gravedad: 6, areas: ["Neurología", "Neurocirugía", "Cirugía General", "Neumología", "Oncología Médica", "Traumatología"] },
    "Biopsia Tumoral y Marcadores Oncológicos": { categoria: "Diagnósticos y Estudios", gravedad: 6, areas: ["Oncología Médica", "Cirugía Oncológica", "Quimioterapia y Control Oncológico"] },
    "Electrocardiograma (ECG) y Ecocardiograma Doppler": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Cardiología", "Urgencia Cardiológica", "Cirugía Cardiovascular", "Medicina Interna"] },
    "Resonancia Magnética (RMN) Cerebral y Articular": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Neurología", "Neurología Clínica", "Neurocirugía", "Traumatología", "Cirugía Traumatológica"] },
    "Endoscopía Digestiva Alta y Colonoscopía Diagnóstica": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Endoscopía Digestiva", "Gastroenterología"] },
    "Broncoscopía Diagnóstica y Espirometría Pulmonar": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Broncoscopía Respiratoria", "Neumología"] },
    "Radiografía Digital (Rayos X) Ósea y Torácica": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Traumatología", "Cirugía Traumatológica", "Neumología", "Pediatría", "Reconstrucción Maxilofacial y Traumática"] },
    "Electroencefalograma (EEG) y Potenciales Evocados": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Neurología Clínica", "Neurología", "Pediatría"] },
    "Ultrasonido Obstétrico 4D y Monitoreo Fetal Doppler": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Ginecología", "Maternidad y Obstetricia", "Parto de Alto Riesgo Neonatal"], sexoPermitido: "Femenino" },
    "Tamiz Neonatal y Ecografía Transfontanelar": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Neonatología", "Pediatría"] },
    "Evaluación Preanestésica y Riesgo Quirúrgico (ASA)": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Anestesiología", "Cirugía Plástica Ambulatoria", "Cirugía General"] },
    "Prueba de Esfuerzo Cardiovascular (Ergometría)": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Cardiología"] },
    "Biopsia Cutánea y Dermatoscopía Digital": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Dermatología", "Cirugía Dermatológica Reconstructiva", "Cirugía Plástica y Estética"] },
    "Perfil Renal, Ecografía Vesical y Urodinamia": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Nefrología", "Urología", "Hemodiálisis y Soporte Renal"] },
    "Antígeno Prostático Específico (PSA) y Ultrasonido": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Andrología y Control Prostático", "Urología"], sexoPermitido: "Masculino" },
    "Biometría Hemática, Coagulograma y Panel Infeccioso": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Hematología", "Infectología", "Medicina Interna"] },
    "Perfil Tiroideo y Hemoglobina Glicosilada": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Endocrinología", "Medicina Interna"] },
    "Evaluación Psicométrica y Diagnóstico Psiquiátrico": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Psiquiatría y Salud Mental"] },
    "Mamografía Digital y Papanicolaou": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Ginecología", "Oncología Médica"], sexoPermitido: "Femenino" },
    "Fondo de Ojo, Campimetría y Tonometría Ocular": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Oftalmología", "Cirugía Oftalmológica"] },
    "Audiometría Tonal y Nasofibrolaringoscopía": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Otorrinolaringología"] },
    "Densitometría Ósea y Perfil Reumatológico": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Reumatología", "Geriatría", "Traumatología"] }
};

// 3. PLANTILLA COMPLETA DE MÉDICOS (84 Especialistas para asignar en Triage)
const medicos = [
    { id: 1, nombre: "Dr. Alejandro Valladares", especialidad: "Cirujano Plástico", disponible: true, guardia: 0 },
    { id: 2, nombre: "Dra. Renata Mendizábal", especialidad: "Cirujano Plástico", disponible: true, guardia: 0 },
    { id: 3, nombre: "Dr. Cristian Wyld", especialidad: "Cirujano Plástico", disponible: true, guardia: 0 },
    { id: 4, nombre: "Dra. Isabella Toriello", especialidad: "Cirujano Plástico", disponible: true, guardia: 0 },
    { id: 5, nombre: "Dra. Patricia Castellanos", especialidad: "Ginecólogo", disponible: true, guardia: 0 },
    { id: 6, nombre: "Dr. Alejandro Solares", especialidad: "Ginecólogo", disponible: true, guardia: 0 },
    { id: 7, nombre: "Dra. Gabriela Marroquín", especialidad: "Ginecólogo", disponible: true, guardia: 0 },
    { id: 8, nombre: "Dra. Regina Morales", especialidad: "Ginecólogo", disponible: true, guardia: 0 },
    { id: 9, nombre: "Dra. Natalia Gálvez", especialidad: "Pediatra", disponible: true, guardia: 0 },
    { id: 10, nombre: "Dr. Hugo Samayoa", especialidad: "Pediatra", disponible: true, guardia: 0 },
    { id: 11, nombre: "Dra. Valeria Fuentes", especialidad: "Pediatra", disponible: true, guardia: 0 },
    { id: 12, nombre: "Dr. Daniel Orellana", especialidad: "Pediatra", disponible: true, guardia: 0 },
    { id: 13, nombre: "Dra. Mariana Batres", especialidad: "Neonatólogo", disponible: true, guardia: 0 },
    { id: 14, nombre: "Dr. Ernesto Zelaya", especialidad: "Neonatólogo", disponible: true, guardia: 0 },
    { id: 15, nombre: "Dra. Rocío Argueta", especialidad: "Neonatólogo", disponible: true, guardia: 0 },
    { id: 16, nombre: "Dr. Carlos Mendoza", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 17, nombre: "Dra. Elena Rostova", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 18, nombre: "Dr. Mario Villatoro", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 19, nombre: "Dra. Lucía Paredes", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 20, nombre: "Dr. Jorge Echeverría", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 21, nombre: "Dra. Jimena Peralta", especialidad: "Anestesiólogo", disponible: true, guardia: 0 },
    { id: 22, nombre: "Dr. Roberto Chang", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 23, nombre: "Dra. Sofía Valenzuela", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 24, nombre: "Dr. Fernando Galindo", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 25, nombre: "Dra. Claudia Morales", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 26, nombre: "Dr. Javier Santizo", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 27, nombre: "Dra. Paola Méndez", especialidad: "Médico Internista", disponible: true, guardia: 0 },
    { id: 28, nombre: "Dr. Héctor Cifuentes", especialidad: "Traumatólogo", disponible: true, guardia: 0 },
    { id: 29, nombre: "Dr. Rodrigo Pineda", especialidad: "Traumatólogo", disponible: true, guardia: 0 },
    { id: 30, nombre: "Dra. Mónica Estrada", especialidad: "Traumatólogo", disponible: true, guardia: 0 },
    { id: 31, nombre: "Dr. Sebastián Paz", especialidad: "Traumatólogo", disponible: true, guardia: 0 },
    { id: 32, nombre: "Dra. Andrea Monterroso", especialidad: "Dermatólogo", disponible: true, guardia: 0 },
    { id: 33, nombre: "Dr. Pablo Girón", especialidad: "Dermatólogo", disponible: true, guardia: 0 },
    { id: 34, nombre: "Dra. Camila Salazar", especialidad: "Dermatólogo", disponible: true, guardia: 0 },
    { id: 35, nombre: "Dr. Julio Cabrera", especialidad: "Geriatra", disponible: true, guardia: 0 },
    { id: 36, nombre: "Dra. Carmen Godoy", especialidad: "Geriatra", disponible: true, guardia: 0 },
    { id: 37, nombre: "Dr. Emilio Tello", especialidad: "Geriatra", disponible: true, guardia: 0 },
    { id: 38, nombre: "Dr. Adrián Monzón", especialidad: "Cardiólogo", disponible: true, guardia: 0 },
    { id: 39, nombre: "Dra. Silvia Pellecer", especialidad: "Cardiólogo", disponible: true, guardia: 0 },
    { id: 40, nombre: "Dr. Marco Tulio Barrios", especialidad: "Cardiólogo", disponible: true, guardia: 0 },
    { id: 41, nombre: "Dr. Federico Novales", especialidad: "Cirujano Cardiovascular", disponible: true, guardia: 0 },
    { id: 42, nombre: "Dra. Viviana Saravia", especialidad: "Cirujano Cardiovascular", disponible: true, guardia: 0 },
    { id: 43, nombre: "Dr. Esteban Coronado", especialidad: "Neurólogo", disponible: true, guardia: 0 },
    { id: 44, nombre: "Dra. Diana Recinos", especialidad: "Neurólogo", disponible: true, guardia: 0 },
    { id: 45, nombre: "Dr. César Batres", especialidad: "Neurólogo", disponible: true, guardia: 0 },
    { id: 46, nombre: "Dr. Leonardo Aycinena", especialidad: "Neurocirujano", disponible: true, guardia: 0 },
    { id: 47, nombre: "Dra. Rebeca Urruela", especialidad: "Neurocirujano", disponible: true, guardia: 0 },
    { id: 48, nombre: "Dr. Gonzalo Illescas", especialidad: "Neumólogo", disponible: true, guardia: 0 },
    { id: 49, nombre: "Dra. Adriana Rodas", especialidad: "Neumólogo", disponible: true, guardia: 0 },
    { id: 50, nombre: "Dr. Benjamín Alcázar", especialidad: "Neumólogo", disponible: true, guardia: 0 },
    { id: 51, nombre: "Dr. Mauricio Rosales", especialidad: "Gastroenterólogo", disponible: true, guardia: 0 },
    { id: 52, nombre: "Dra. Karina Polanco", especialidad: "Gastroenterólogo", disponible: true, guardia: 0 },
    { id: 53, nombre: "Dr. Tomás Velásquez", especialidad: "Gastroenterólogo", disponible: true, guardia: 0 },
    { id: 54, nombre: "Dr. Salvador Gándara", especialidad: "Nefrólogo", disponible: true, guardia: 0 },
    { id: 55, nombre: "Dra. Olga Villagrán", especialidad: "Nefrólogo", disponible: true, guardia: 0 },
    { id: 56, nombre: "Dr. Luis Pedro Mencos", especialidad: "Nefrólogo", disponible: true, guardia: 0 },
    { id: 57, nombre: "Dra. Estefanía Klee", especialidad: "Endocrinólogo", disponible: true, guardia: 0 },
    { id: 58, nombre: "Dr. Juan Pablo Lehnhoff", especialidad: "Endocrinólogo", disponible: true, guardia: 0 },
    { id: 59, nombre: "Dr. Ramiro Asturias", especialidad: "Urólogo", disponible: true, guardia: 0 },
    { id: 60, nombre: "Dr. Gustavo Ovalle", especialidad: "Urólogo", disponible: true, guardia: 0 },
    { id: 61, nombre: "Dra. Verónica Cordón", especialidad: "Urólogo", disponible: true, guardia: 0 },
    { id: 62, nombre: "Dr. Sergio Arzú", especialidad: "Oftalmólogo", disponible: true, guardia: 0 },
    { id: 63, nombre: "Dra. Laura Melgar", especialidad: "Oftalmólogo", disponible: true, guardia: 0 },
    { id: 64, nombre: "Dr. Andrés Sinibaldi", especialidad: "Oftalmólogo", disponible: true, guardia: 0 },
    { id: 65, nombre: "Dr. Álvaro Dardón", especialidad: "Otorrinolaringólogo", disponible: true, guardia: 0 },
    { id: 66, nombre: "Dra. Lorena Chinchilla", especialidad: "Otorrinolaringólogo", disponible: true, guardia: 0 },
    { id: 67, nombre: "Dra. Marta Beltranena", especialidad: "Reumatólogo", disponible: true, guardia: 0 },
    { id: 68, nombre: "Dr. Óscar Berger-Pemueller", especialidad: "Reumatólogo", disponible: true, guardia: 0 },
    { id: 69, nombre: "Dr. David Monterroso", especialidad: "Hematólogo", disponible: true, guardia: 0 },
    { id: 70, nombre: "Dra. Leticia Sagastume", especialidad: "Hematólogo", disponible: true, guardia: 0 },
    { id: 71, nombre: "Dr. Carlos Mejía Villatoro", especialidad: "Infectólogo", disponible: true, guardia: 0 },
    { id: 72, nombre: "Dra. Iris Cazali", especialidad: "Infectólogo", disponible: true, guardia: 0 },
    { id: 73, nombre: "Dr. Enrique Maegli", especialidad: "Oncólogo", disponible: true, guardia: 0 },
    { id: 74, nombre: "Dra. Fabiola Berganza", especialidad: "Oncólogo", disponible: true, guardia: 0 },
    { id: 75, nombre: "Dr. Ricardo Bressani", especialidad: "Oncólogo", disponible: true, guardia: 0 },
    { id: 76, nombre: "Dra. Susana Neutze", especialidad: "Psiquiatra", disponible: true, guardia: 0 },
    { id: 77, nombre: "Dr. Mateo Zirión", especialidad: "Psiquiatra", disponible: true, guardia: 0 },
    { id: 78, nombre: "Dr. Arturo Lemus", especialidad: "Cirujano General", disponible: true, guardia: 0 },
    { id: 79, nombre: "Dra. Beatriz Barrios", especialidad: "Cirujano General", disponible: true, guardia: 0 },
    { id: 80, nombre: "Dr. Óscar Taracena", especialidad: "Cirujano General", disponible: true, guardia: 0 },
    { id: 81, nombre: "Dra. Carla Aldana", especialidad: "Cirujano General", disponible: true, guardia: 0 },
    { id: 82, nombre: "Dr. Víctor Portillo", especialidad: "Intensivista", disponible: true, guardia: 0 },
    { id: 83, nombre: "Dra. Teresa Lima", especialidad: "Intensivista", disponible: true, guardia: 0 },
    { id: 84, nombre: "Dr. Nicolás Mérida", especialidad: "Intensivista", disponible: true, guardia: 0 }
];

// 4. CONEXIÓN CON LOS INPUTS DEL HTML
const inputNombre = document.getElementById('nombreP');
const inputCui = document.getElementById('cui');
const inputFecha = document.getElementById('fechaNacimiento');
const selectSexo = document.getElementById('sexo');

const inputBuscadorCondicion = document.getElementById('buscadorCondicion');
const inputCondicionSeleccionada = document.getElementById('condicionMedica');
const dropdownCondiciones = document.getElementById('listaCondicionesDropdown');

const inputBuscadorArea = document.getElementById('buscadorArea');
const inputAreaSeleccionada = document.getElementById('areaMedica');
const dropdownAreas = document.getElementById('listaAreasDropdown');
const infoTriage = document.getElementById('infoTriage');

inputFecha.max = new Date().toISOString().split("T")[0];

// --- CONTROLADOR DE LA VENTANA MODAL ---
function mostrarAlerta(mensaje, titulo = "Sistema Médico") {
    const modal = document.getElementById('modalSistema');
    document.getElementById('modalTitulo').textContent = titulo;
    document.getElementById('modalTexto').textContent = mensaje;
    modal.style.display = 'flex';
}

document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

function normalizarTexto(texto) {
    return texto.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function calcularEdad(fechaNacimiento) {
    if (!fechaNacimiento) return null;
    const hoy = new Date();
    const cumple = new Date(fechaNacimiento + "T00:00:00");
    let edad = hoy.getFullYear() - cumple.getFullYear();
    const mes = hoy.getMonth() - cumple.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < cumple.getDate())) {
        edad--;
    }
    return edad;
}

// 5. VALIDACIÓN CRUZADA: EDAD, SEXO, CONDICIÓN Y ÁREA MÉDICA
function evaluarCompatibilidadArea(nombreArea, sexo, edad, condicionActiva = "") {
    const datos = protocolosPorArea[nombreArea];
    if (!datos) return { compatible: false, motivo: "Área médica no encontrada." };

    if (sexo && datos.sexoPermitido && datos.sexoPermitido !== sexo) {
        return { compatible: false, motivo: `El área de ${nombreArea} es exclusiva para pacientes de sexo ${datos.sexoPermitido}.` };
    }

    if (edad !== null && !isNaN(edad)) {
        if (edad < 0) return { compatible: false, motivo: "La fecha de nacimiento no puede ser futura." };
        if (datos.edadMax !== undefined && edad > datos.edadMax) {
            return { compatible: false, motivo: `El área de ${nombreArea} solo admite pacientes de hasta ${datos.edadMax} años.` };
        }
        if (datos.edadMin !== undefined && edad < datos.edadMin) {
            return { compatible: false, motivo: `El área de ${nombreArea} requiere al menos ${datos.edadMin} años.` };
        }
    }

    if (condicionActiva && catalogoClinico[condicionActiva]) {
        if (!catalogoClinico[condicionActiva].areas.includes(nombreArea)) {
            return { compatible: false, motivo: `El área de ${nombreArea} no corresponde a "${condicionActiva}".` };
        }
    }

    return { compatible: true, motivo: "" };
}

function evaluarCompatibilidadCondicion(nombreCondicion, sexo, edad, areaActiva = "") {
    const datos = catalogoClinico[nombreCondicion];
    if (!datos) return { compatible: false, motivo: "Condición no encontrada." };

    if (sexo && datos.sexoPermitido && datos.sexoPermitido !== sexo) {
        return { compatible: false, motivo: `"${nombreCondicion}" aplica únicamente para pacientes de sexo ${datos.sexoPermitido}.` };
    }

    if (areaActiva && !datos.areas.includes(areaActiva)) {
        return { compatible: false, motivo: `"${nombreCondicion}" no pertenece al área de ${areaActiva}.` };
    }

    const tieneAreaValida = datos.areas.some(a => evaluarCompatibilidadArea(a, sexo, edad, "").compatible);
    if (!tieneAreaValida) {
        return { compatible: false, motivo: `"${nombreCondicion}" no es compatible con la edad o sexo del paciente.` };
    }

    return { compatible: true, motivo: "" };
}

function actualizarBannerTriage() {
    const cond = inputCondicionSeleccionada.value;
    const area = inputAreaSeleccionada.value;

    if (!cond && !area) {
        infoTriage.style.display = 'none';
        return;
    }

    let html = "";
    if (cond && catalogoClinico[cond]) {
        const g = catalogoClinico[cond].gravedad;
        const colorUrgencia = g >= 8 ? "#d32f2f" : (g >= 5 ? "#ef6c00" : "#2e7d32");
        html += `<div><strong>${catalogoClinico[cond].categoria}:</strong> ${cond} — <span style="color: ${colorUrgencia}; font-weight: 700;">Nivel de Gravedad Calculado: ${g} / 10</span></div>`;
    }
    if (area && protocolosPorArea[area]) {
        const prot = protocolosPorArea[area];
        html += `<div><strong>Área Médica:</strong> ${area} — <strong>Especialistas a asignar (${prot.requeridos.length}):</strong> ${prot.requeridos.join(' + ')}</div>`;
    }

    infoTriage.innerHTML = html;
    infoTriage.style.display = 'block';
}

function revalidarSelecciones() {
    const sexo = selectSexo.value;
    const edad = calcularEdad(inputFecha.value);
    const condActual = inputCondicionSeleccionada.value;
    const areaActual = inputAreaSeleccionada.value;

    if (condActual) {
        const valCond = evaluarCompatibilidadCondicion(condActual, sexo, edad, areaActual);
        if (!valCond.compatible) {
            inputBuscadorCondicion.value = '';
            inputCondicionSeleccionada.value = '';
        }
    }

    if (areaActual) {
        const valArea = evaluarCompatibilidadArea(areaActual, sexo, edad, inputCondicionSeleccionada.value);
        if (!valArea.compatible) {
            inputBuscadorArea.value = '';
            inputAreaSeleccionada.value = '';
        }
    }

    actualizarBannerTriage();
}

// 6. BUSCADOR INTERACTIVO DE ENFERMEDAD / DIAGNÓSTICO / QUEBRADURA
function renderizarOpcionesCondicion(filtro = "") {
    dropdownCondiciones.innerHTML = "";
    const filtroNorm = normalizarTexto(filtro.trim());
    const sexoActual = selectSexo.value;
    const edadActual = calcularEdad(inputFecha.value);
    const areaActual = inputAreaSeleccionada.value;

    let categoriaActual = "";
    let coincidencias = 0;

    Object.entries(catalogoClinico).forEach(([nombreCond, datos]) => {
        if (!evaluarCompatibilidadCondicion(nombreCond, sexoActual, edadActual, areaActual).compatible) {
            return;
        }

        const textoBusqueda = normalizarTexto(`${nombreCond} ${datos.categoria} ${datos.areas.join(" ")}`);
        if (textoBusqueda.includes(filtroNorm)) {
            coincidencias++;
            if (datos.categoria !== categoriaActual) {
                categoriaActual = datos.categoria;
                const divCat = document.createElement('div');
                divCat.className = 'dropdown-categoria';
                divCat.textContent = categoriaActual;
                dropdownCondiciones.appendChild(divCat);
            }

            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">${nombreCond}</span>
                <span class="dropdown-item-sub">⚡ Gravedad: <strong>${datos.gravedad}/10</strong> | 🏥 Áreas: ${datos.areas.join(', ')}</span>
            `;

            item.addEventListener('click', () => {
                seleccionarCondicion(nombreCond);
            });

            dropdownCondiciones.appendChild(item);
        }
    });

    if (coincidencias === 0) {
        dropdownCondiciones.innerHTML = `<div class="dropdown-vacio">No hay enfermedades, diagnósticos o quebraduras compatibles con el filtro actual.</div>`;
    }
}

function seleccionarCondicion(nombreCond) {
    inputBuscadorCondicion.value = nombreCond;
    inputCondicionSeleccionada.value = nombreCond;
    dropdownCondiciones.style.display = 'none';

    const sexo = selectSexo.value;
    const edad = calcularEdad(inputFecha.value);
    const datos = catalogoClinico[nombreCond];

    if (inputAreaSeleccionada.value && !datos.areas.includes(inputAreaSeleccionada.value)) {
        inputBuscadorArea.value = '';
        inputAreaSeleccionada.value = '';
    }

    if (!inputAreaSeleccionada.value) {
        const areasCompatibles = datos.areas.filter(a => evaluarCompatibilidadArea(a, sexo, edad, nombreCond).compatible);
        if (areasCompatibles.length === 1) {
            inputBuscadorArea.value = areasCompatibles[0];
            inputAreaSeleccionada.value = areasCompatibles[0];
        }
    }

    actualizarBannerTriage();
}

// 7. BUSCADOR INTERACTIVO DE ÁREA MÉDICA
function renderizarOpcionesArea(filtro = "") {
    dropdownAreas.innerHTML = "";
    const filtroNorm = normalizarTexto(filtro.trim());
    const sexoActual = selectSexo.value;
    const edadActual = calcularEdad(inputFecha.value);
    const condicionActual = inputCondicionSeleccionada.value;

    let categoriaActual = "";
    let coincidencias = 0;

    Object.entries(protocolosPorArea).forEach(([nombreArea, datos]) => {
        if (!evaluarCompatibilidadArea(nombreArea, sexoActual, edadActual, condicionActual).compatible) {
            return;
        }

        const textoBusqueda = normalizarTexto(`${nombreArea} ${datos.requeridos.join(" ")} ${datos.descripcion}`);
        if (textoBusqueda.includes(filtroNorm)) {
            coincidencias++;
            if (datos.categoria !== categoriaActual) {
                categoriaActual = datos.categoria;
                const divCat = document.createElement('div');
                divCat.className = 'dropdown-categoria';
                divCat.textContent = categoriaActual;
                dropdownAreas.appendChild(divCat);
            }

            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">${nombreArea}</span>
                <span class="dropdown-item-sub">👨‍⚕️ ${datos.requeridos.join(' + ')}</span>
            `;

            item.addEventListener('click', () => {
                seleccionarArea(nombreArea);
            });

            dropdownAreas.appendChild(item);
        }
    });

    if (coincidencias === 0) {
        dropdownAreas.innerHTML = `<div class="dropdown-vacio">No hay áreas compatibles con el diagnóstico/enfermedad y perfil del paciente.</div>`;
    }
}

function seleccionarArea(nombreArea) {
    inputBuscadorArea.value = nombreArea;
    inputAreaSeleccionada.value = nombreArea;
    dropdownAreas.style.display = 'none';

    if (inputCondicionSeleccionada.value && !catalogoClinico[inputCondicionSeleccionada.value].areas.includes(nombreArea)) {
        inputBuscadorCondicion.value = '';
        inputCondicionSeleccionada.value = '';
    }

    actualizarBannerTriage();
}

inputBuscadorCondicion.addEventListener('focus', () => {
    dropdownAreas.style.display = 'none';
    renderizarOpcionesCondicion(inputBuscadorCondicion.value);
    dropdownCondiciones.style.display = 'block';
});

inputBuscadorCondicion.addEventListener('input', function() {
    inputCondicionSeleccionada.value = '';
    actualizarBannerTriage();
    renderizarOpcionesCondicion(this.value);
    dropdownCondiciones.style.display = 'block';
});

inputBuscadorArea.addEventListener('focus', () => {
    dropdownCondiciones.style.display = 'none';
    renderizarOpcionesArea(inputBuscadorArea.value);
    dropdownAreas.style.display = 'block';
});

inputBuscadorArea.addEventListener('input', function() {
    inputAreaSeleccionada.value = '';
    actualizarBannerTriage();
    renderizarOpcionesArea(this.value);
    dropdownAreas.style.display = 'block';
});

document.addEventListener('click', (e) => {
    if (!e.target.closest('.buscador-area-container')) {
        dropdownCondiciones.style.display = 'none';
        dropdownAreas.style.display = 'none';
    }
});

// 8. VALIDACIONES DE CAMPOS Y AUTORELLENO POR CUI (Solo Nombre, Fecha y Sexo)
inputNombre.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
});

inputCui.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
    const cuiIngresado = this.value.trim();
    const pacientesRegistrados = obtenerPacientesGuardados();

    if (pacientesRegistrados[cuiIngresado]) {
        const paciente = pacientesRegistrados[cuiIngresado];
        inputNombre.value = paciente.nombre;
        inputFecha.value = paciente.fecha;
        selectSexo.value = paciente.sexo || paciente.genero || '';
        revalidarSelecciones();
    }
});

inputFecha.addEventListener('change', revalidarSelecciones);
selectSexo.addEventListener('change', revalidarSelecciones);

function limpiarFormulario() {
    inputNombre.value = '';
    inputCui.value = '';
    inputFecha.value = '';
    selectSexo.value = '';
    inputBuscadorCondicion.value = '';
    inputCondicionSeleccionada.value = '';
    inputBuscadorArea.value = '';
    inputAreaSeleccionada.value = '';
    infoTriage.style.display = 'none';
    dropdownCondiciones.style.display = 'none';
    dropdownAreas.style.display = 'none';
}

// Función auxiliar para liberar a los médicos asignados a un paciente
function liberarMedicosDePaciente(paciente) {
    if (paciente && Array.isArray(paciente.equipo)) {
        paciente.equipo.forEach(medicoAsignado => {
            const medicoEnPlantilla = medicos.find(m => m.id === medicoAsignado.id);
            if (medicoEnPlantilla) {
                medicoEnPlantilla.disponible = true;
            }
        });
    }
}

// 9. LÓGICA DE INGRESO A TRIAGE + ASIGNACIÓN DE MÉDICOS
function registrarPaciente() {
    const nombre = inputNombre.value.trim();
    const cui = inputCui.value.trim();
    const fecha = inputFecha.value;
    const sexo = selectSexo.value;
    const edad = calcularEdad(fecha);
    let condicion = inputCondicionSeleccionada.value;
    let area = inputAreaSeleccionada.value;

    if (!condicion && inputBuscadorCondicion.value.trim() !== '') {
        const textoCond = normalizarTexto(inputBuscadorCondicion.value.trim());
        const encontrada = Object.keys(catalogoClinico).find(k => normalizarTexto(k) === textoCond);
        if (encontrada) seleccionarCondicion(encontrada);
        condicion = inputCondicionSeleccionada.value;
    }

    if (!area && inputBuscadorArea.value.trim() !== '') {
        const textoArea = normalizarTexto(inputBuscadorArea.value.trim());
        const encontrada = Object.keys(protocolosPorArea).find(k => normalizarTexto(k) === textoArea);
        if (encontrada) seleccionarArea(encontrada);
        area = inputAreaSeleccionada.value;
    }

    if (!nombre || !cui || !fecha || !sexo || !condicion || !area) {
        mostrarAlerta("Por favor complete todos los campos (Nombre, CUI, Fecha, Sexo, Enfermedad/Diagnóstico/Quebradura y Área Médica).", "Campos Incompletos");
        return;
    }

    const valCond = evaluarCompatibilidadCondicion(condicion, sexo, edad, area);
    if (!valCond.compatible) {
        mostrarAlerta(valCond.motivo, "Incompatibilidad Clínica");
        return;
    }

    const valArea = evaluarCompatibilidadArea(area, sexo, edad, condicion);
    if (!valArea.compatible) {
        mostrarAlerta(valArea.motivo, "Área No Compatible");
        return;
    }

    // SELECCIÓN VORAZ (GREEDY) DE UNO O VARIOS MÉDICOS SEGÚN EL ÁREA
    const especialidadesRequeridas = protocolosPorArea[area].requeridos;
    const equipoSeleccionado = [];

    for (const esp of especialidadesRequeridas) {
        const candidatos = medicos
            .filter(m => m.especialidad === esp && m.disponible && !equipoSeleccionado.includes(m))
            .sort((a, b) => a.guardia - b.guardia);

        if (candidatos.length > 0) {
            equipoSeleccionado.push(candidatos[0]);
        } else {
            mostrarAlerta(
                `No es posible ingresar al paciente en ${area}.\nActualmente todos los especialistas en "${esp}" están ocupados en la cola de espera.`,
                "Personal Médico Insuficiente"
            );
            return;
        }
    }

    // Marcar a los especialistas seleccionados como ocupados y sumar turno
    equipoSeleccionado.forEach(medico => {
        medico.disponible = false;
        medico.guardia += 1;
    });

    // Nivel de gravedad calculado según la condición médica
    const gravedad = catalogoClinico[condicion].gravedad;

    // Guardar únicamente datos personales asociados al CUI
    guardarPacienteEnMemoria(cui, { nombre, fecha, sexo });

    function registrarEventoHistorial(cui, evento) {
    const historial = JSON.parse(localStorage.getItem('historialMedico_SM')) || {};
    if (!historial[cui]) {
        historial[cui] = [];
    }
    historial[cui].unshift(evento); // Guarda el registro más reciente de primero
    localStorage.setItem('historialMedico_SM', JSON.stringify(historial));
}

    const id = Date.now();
    triageQueue.insert({
        id,
        nombre,
        gravedad,
        cui,
        fecha,
        edad,
        sexo,
        condicion,
        area,
        equipo: equipoSeleccionado
    });

    limpiarFormulario();
    actualizarUI();
}

document.getElementById('btnLimpiar').addEventListener('click', limpiarFormulario);
document.getElementById('btnIngresar').addEventListener('click', registrarPaciente);

// Detector global de tecla Enter
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const modal = document.getElementById('modalSistema');
        if (modal && modal.style.display === 'flex') {
            e.preventDefault();
            modal.style.display = 'none';
            return;
        }

        e.preventDefault();

        if (!inputCondicionSeleccionada.value && inputBuscadorCondicion.value.trim() !== '') {
            renderizarOpcionesCondicion(inputBuscadorCondicion.value);
            const primeraCond = dropdownCondiciones.querySelector('.dropdown-item-titulo');
            if (primeraCond) seleccionarCondicion(primeraCond.textContent);
        }

        if (!inputAreaSeleccionada.value && inputBuscadorArea.value.trim() !== '') {
            renderizarOpcionesArea(inputBuscadorArea.value);
            const primeraArea = dropdownAreas.querySelector('.dropdown-item-titulo');
            if (primeraArea) seleccionarArea(primeraArea.textContent);
        }

        registrarPaciente();
    }
});

// ATENDER PRÓXIMO PACIENTE (Y liberar a su equipo médico al finalizar)
document.getElementById('btnAtender').addEventListener('click', () => {
    if (triageQueue.heap.length > 0) {
        const atendido = triageQueue.extractMax();
        liberarMedicosDePaciente(atendido);

        const resumenMedicos = atendido.equipo
            .map(m => `• ${m.nombre} (${m.especialidad})`)
            .join('\n');

        mostrarAlerta(
            `Atendiendo a: ${atendido.nombre} (${atendido.edad} años)\nCUI: ${atendido.cui} | Sexo: ${atendido.sexo}\nDiagnóstico/Condición: ${atendido.condicion}\nNivel de Gravedad: ${atendido.gravedad}/10\nÁrea: ${atendido.area}\n\nEquipo Médico (${atendido.equipo.length}):\n${resumenMedicos}`,
            "Atención Médica de Triage"
        );
        actualizarUI();
    } else {
        mostrarAlerta("No hay pacientes en la cola de espera.", "Cola Vacía");
    }
});

// CANCELAR PACIENTE DE LA COLA (Y liberar a los médicos que tenía asignados)
document.getElementById('listaEspera').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-eliminar')) {
        const pacienteId = parseInt(e.target.getAttribute('data-id'));
        const pacienteEnCola = triageQueue.heap.find(p => p.id === pacienteId);

        if (pacienteEnCola) {
            liberarMedicosDePaciente(pacienteEnCola);
        }

        triageQueue.removeById(pacienteId);
        actualizarUI();
    }
});

// 10. ACTUALIZAR INTERFAZ GRÁFICA DE LA COLA DE ESPERA
function actualizarUI() {
    const div = document.getElementById('listaEspera');
    div.innerHTML = '<h3>Cola de espera:</h3>';
    
    if (triageQueue.heap.length === 0) {
        div.innerHTML += '<p style="justify-content: center; color: var(--text-muted);">La cola está vacía.</p>';
        return;
    }

    triageQueue.heap.forEach(p => {
        const listaNombres = p.equipo.map(m => `<strong>${m.nombre}</strong> (${m.especialidad})`).join(' + ');
        const etiquetaPersonal = p.equipo.length === 1 ? 'Médico asignado' : `Equipo (${p.equipo.length})`;

        div.innerHTML += `
            <p style="flex-direction: column; align-items: flex-start; gap: 6px;">
                <span style="width: 100%; display: flex; justify-content: space-between; align-items: center;">
                    <span><strong>${p.nombre}</strong> (${p.edad} años) — Urgencia Calculada: <strong>${p.gravedad}/10</strong></span>
                    <button class="btn-eliminar" data-id="${p.id}">❌ Cancelar</button>
                </span>
                <span style="font-size: 0.88rem; color: var(--primary-blue); font-weight: 500;">
                    🩺 ${p.condicion} | 🏥 Área: <strong>${p.area}</strong>
                </span>
                <span style="font-size: 0.88rem; color: var(--text-dark);">
                    👨‍⚕️ ${etiquetaPersonal}: ${listaNombres}
                </span>
                <span style="font-size: 0.85rem; color: var(--text-muted);">
                    CUI: ${p.cui} | Nacimiento: ${p.fecha} | Sexo: ${p.sexo}
                </span>
            </p>`;
    });
}