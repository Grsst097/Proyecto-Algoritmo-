import { MaxHeap } from './estructuras/PriorityQueue.js';

const triageQueue = new MaxHeap();

// 1. CONEXIÓN CON LOS INPUTS DEL HTML
const inputNombre = document.getElementById('nombreP');
const inputGravedad = document.getElementById('gravedad');
const inputCui = document.getElementById('cui');
const inputFecha = document.getElementById('fechaNacimiento');
const selectGenero = document.getElementById('genero');

// 2. VALIDACIONES EN TIEMPO REAL
// Solo letras en nombre
inputNombre.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
});

// Solo números del 1 al 10 en gravedad
inputGravedad.addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value !== '') {
        let valor = parseInt(this.value, 10);
        if (valor > 10) this.value = 10;
        else if (valor === 0) this.value = 1;
    }
});

// Solo letras y números en CUI
inputCui.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
});

// 3. FUNCIÓN PARA LIMPIAR TODO EL FORMULARIO
function limpiarFormulario() {
    inputNombre.value = '';
    inputGravedad.value = '';
    inputCui.value = '';
    inputFecha.value = '';
    selectGenero.value = '';
}

// 4. ACCIONES DE LOS BOTONES
// Botón: Limpiar Datos manualmente
document.getElementById('btnLimpiar').addEventListener('click', () => {
    limpiarFormulario();
});

// Botón: Ingresar a Triage
document.getElementById('btnIngresar').addEventListener('click', () => {
    const nombre = inputNombre.value;
    const gravedad = parseInt(inputGravedad.value);
    const cui = inputCui.value;
    const fecha = inputFecha.value;
    const genero = selectGenero.value;
    
    if(nombre && gravedad && cui && fecha && genero) {
        const id = Date.now(); 
        triageQueue.insert({ id, nombre, gravedad, cui, fecha, genero });
        
        // Limpiamos los campos automáticamente después de guardar
        limpiarFormulario(); 
        actualizarUI();
    } else {
        alert("Por favor complete todos los campos (Nombre, Gravedad, CUI, Fecha y Género).");
    }
});

// Botón: Atender Próximo
document.getElementById('btnAtender').addEventListener('click', () => {
    if(triageQueue.heap.length > 0) {
        const atendido = triageQueue.extractMax();
        alert(`Atendiendo a: ${atendido.nombre} (Gravedad: ${atendido.gravedad})`);
        actualizarUI();
    } else {
        alert("No hay pacientes en la cola.");
    }
});

// Botón: Cancelar (Eliminar de la fila)
document.getElementById('listaEspera').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-eliminar')) {
        const pacienteId = parseInt(e.target.getAttribute('data-id'));
        triageQueue.removeById(pacienteId);
        actualizarUI();
    }
});

// 5. ACTUALIZAR INTERFAZ GRÁFICA
function actualizarUI() {
    const div = document.getElementById('listaEspera');
    div.innerHTML = '<h3>Cola de espera:</h3>';
    
    if(triageQueue.heap.length === 0) {
        div.innerHTML += '<p style="justify-content: center; color: var(--text-muted);">La cola está vacía.</p>';
        return;
    }

    triageQueue.heap.forEach(p => {
        div.innerHTML += `
            <p style="flex-direction: column; align-items: flex-start; gap: 5px;">
                <span style="width: 100%; display: flex; justify-content: space-between; align-items: center;">
                    <span><strong>${p.nombre}</strong> (Urgencia: <strong>${p.gravedad}</strong>)</span>
                    <button class="btn-eliminar" data-id="${p.id}">❌ Cancelar</button>
                </span>
                <span style="font-size: 0.85rem; color: var(--text-muted);">
                    CUI: ${p.cui} | Nacimiento: ${p.fecha} | Género: ${p.genero}
                </span>
            </p>`;
    });
}