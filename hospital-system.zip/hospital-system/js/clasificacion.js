import { MaxHeap } from './estructuras/PriorityQueue.js';

const triageQueue = new MaxHeap();
const pacientesRegistrados = {};

// 1. CONEXIÓN CON LOS INPUTS DEL HTML
const inputNombre = document.getElementById('nombreP');
const inputGravedad = document.getElementById('gravedad');
const inputCui = document.getElementById('cui');
const inputFecha = document.getElementById('fechaNacimiento');
const selectGenero = document.getElementById('genero');

// --- CONTROLADOR DE LA NUEVA VENTANA MODAL ---
function mostrarAlerta(mensaje, titulo = "Sistema Médico") {
    const modal = document.getElementById('modalSistema');
    const texto = document.getElementById('modalTexto');
    const tituloElem = document.getElementById('modalTitulo');
    
    tituloElem.textContent = titulo;
    texto.textContent = mensaje;
    modal.style.display = 'flex';
}

// Evento para cerrar el modal al hacer clic en "Aceptar"
document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

// 2. VALIDACIONES Y AUTORELLENO EN TIEMPO REAL
inputNombre.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
});

inputGravedad.addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value !== '') {
        let valor = parseInt(this.value, 10);
        if (valor > 10) this.value = 10;
        else if (valor === 0) this.value = 1;
    }
});

inputCui.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
    const cuiIngresado = this.value.trim();

    if (pacientesRegistrados[cuiIngresado]) {
        const paciente = pacientesRegistrados[cuiIngresado];
        inputNombre.value = paciente.nombre;
        inputFecha.value = paciente.fecha;
        selectGenero.value = paciente.genero;
    }
});

// 3. FUNCIÓN PARA LIMPIAR TODO EL FORMULARIO
function limpiarFormulario() {
    inputNombre.value = '';
    inputGravedad.value = '';
    inputCui.value = '';
    inputFecha.value = '';
    selectGenero.value = '';
}

// LÓGICA DE INGRESO
function registrarPaciente() {
    const nombre = inputNombre.value;
    const gravedad = parseInt(inputGravedad.value);
    const cui = inputCui.value;
    const fecha = inputFecha.value;
    const genero = selectGenero.value;
    
    if(nombre && gravedad && cui && fecha && genero) {
        pacientesRegistrados[cui] = { nombre, fecha, genero };

        const id = Date.now(); 
        triageQueue.insert({ id, nombre, gravedad, cui, fecha, genero });
        
        limpiarFormulario(); 
        actualizarUI();
    } else {
        mostrarAlerta("Por favor complete todos los campos (Nombre, Gravedad, CUI, Fecha y Género).", "Campos Incompletos");
    }
}

// 4. ACCIONES DE LOS BOTONES Y TECLADO
document.getElementById('btnLimpiar').addEventListener('click', () => {
    limpiarFormulario();
});

document.getElementById('btnIngresar').addEventListener('click', () => {
    registrarPaciente();
});

// Tecla Enter para registrar
const camposFormulario = [inputNombre, inputGravedad, inputCui, inputFecha, selectGenero];
camposFormulario.forEach(campo => {
    campo.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            registrarPaciente();
        }
    });
});

document.getElementById('btnAtender').addEventListener('click', () => {
    if(triageQueue.heap.length > 0) {
        const atendido = triageQueue.extractMax();
        mostrarAlerta(`Atendiendo a:\nNombre: ${atendido.nombre}\nUrgencia: ${atendido.gravedad}\nCUI: ${atendido.cui}`, "Atención Médica");
        actualizarUI();
    } else {
        mostrarAlerta("No hay pacientes en la cola de espera.", "Cola Vacía");
    }
});

document.getElementById('listaEspera').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-eliminar')) {
        const pacienteId = parseInt(e.target.getAttribute('data-id'));
        triageQueue.removeById(pacienteId);
        actualizarUI();
    }
});

// 5. ACTUALIZAR INTERFAZ GRÁFICA
function actualizarUI() {
    const div = document.getElementById('listaEspera');
    div.innerHTML = '<h3>Cola de espera:</h3>';
    
    if(triageQueue.heap.length === 0) {
        div.innerHTML += '<p style="justify-content: center; color: var(--text-muted);">La cola está vacía.</p>';
        return;
    }

    triageQueue.heap.forEach(p => {
        div.innerHTML += `
            <p style="flex-direction: column; align-items: flex-start; gap: 5px;">
                <span style="width: 100%; display: flex; justify-content: space-between; align-items: center;">
                    <span><strong>${p.nombre}</strong> (Urgencia: <strong>${p.gravedad}</strong>)</span>
                    <button class="btn-eliminar" data-id="${p.id}">❌ Cancelar</button>
                </span>
                <span style="font-size: 0.85rem; color: var(--text-muted);">
                    CUI: ${p.cui} | Nacimiento: ${p.fecha} | Género: ${p.genero}
                </span>
            </p>`;
    });
}