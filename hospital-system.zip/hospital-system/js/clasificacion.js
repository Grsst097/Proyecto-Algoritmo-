import { MaxHeap } from './estructuras/PriorityQueue.js';

const triageQueue = new MaxHeap();

// FUNCIONES DE MEMORIA COMPARTIDA ENTRE PÁGINAS (Triage <-> Asignación Médica)
function obtenerPacientesGuardados() {
    return JSON.parse(localStorage.getItem('pacientesRegistrados_SM')) || {};
}

function guardarPacienteEnMemoria(cui, datos) {
    const registro = obtenerPacientesGuardados();
    registro[cui] = datos;
    localStorage.setItem('pacientesRegistrados_SM', JSON.stringify(registro));
}

// 1. CONEXIÓN CON LOS INPUTS DEL HTML
const inputNombre = document.getElementById('nombreP');
const inputGravedad = document.getElementById('gravedad');
const inputCui = document.getElementById('cui');
const inputFecha = document.getElementById('fechaNacimiento');
// Soporta id="sexo" o id="genero" por seguridad
const selectSexo = document.getElementById('sexo') || document.getElementById('genero');

// --- CONTROLADOR DE LA VENTANA MODAL ---
function mostrarAlerta(mensaje, titulo = "Sistema Médico") {
    const modal = document.getElementById('modalSistema');
    const texto = document.getElementById('modalTexto');
    const tituloElem = document.getElementById('modalTitulo');
    
    tituloElem.textContent = titulo;
    texto.textContent = mensaje;
    modal.style.display = 'flex';
}

document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

// 2. VALIDACIONES Y AUTORELLENO EN TIEMPO REAL
inputNombre.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
});

inputGravedad.addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value !== '') {
        let valor = parseInt(this.value, 10);
        if (valor > 10) this.value = 10;
        else if (valor === 0) this.value = 1;
    }
});

// CUI: Solo letras y números + AUTORELLENO desde la memoria compartida
inputCui.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
    const cuiIngresado = this.value.trim();
    const pacientesRegistrados = obtenerPacientesGuardados();

    if (pacientesRegistrados[cuiIngresado]) {
        const paciente = pacientesRegistrados[cuiIngresado];
        inputNombre.value = paciente.nombre;
        inputFecha.value = paciente.fecha;
        selectSexo.value = paciente.sexo || paciente.genero || '';
    }
});

// 3. FUNCIÓN PARA LIMPIAR TODO EL FORMULARIO
function limpiarFormulario() {
    inputNombre.value = '';
    inputGravedad.value = '';
    inputCui.value = '';
    inputFecha.value = '';
    selectSexo.value = '';
}

// LÓGICA DE INGRESO
function registrarPaciente() {
    const nombre = inputNombre.value.trim();
    const gravedad = parseInt(inputGravedad.value);
    const cui = inputCui.value.trim();
    const fecha = inputFecha.value;
    const sexo = selectSexo.value;
    
    if(nombre && gravedad && cui && fecha && sexo) {
        // Guardamos en localStorage para que Triage y Asignación Médica lo recuerden
        guardarPacienteEnMemoria(cui, { nombre, fecha, sexo });

        const id = Date.now(); 
        triageQueue.insert({ id, nombre, gravedad, cui, fecha, sexo });
        
        limpiarFormulario(); 
        actualizarUI();
    } else {
        mostrarAlerta("Por favor complete todos los campos (Nombre, Gravedad, CUI, Fecha y Sexo).", "Campos Incompletos");
    }
}

// 4. ACCIONES DE LOS BOTONES Y TECLADO
document.getElementById('btnLimpiar').addEventListener('click', () => {
    limpiarFormulario();
});

document.getElementById('btnIngresar').addEventListener('click', () => {
    registrarPaciente();
});

const camposFormulario = [inputNombre, inputGravedad, inputCui, inputFecha, selectSexo];
camposFormulario.forEach(campo => {
    campo.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            registrarPaciente();
        }
    });
});

document.getElementById('btnAtender').addEventListener('click', () => {
    if(triageQueue.heap.length > 0) {
        const atendido = triageQueue.extractMax();
        mostrarAlerta(`Atendiendo a:\nNombre: ${atendido.nombre}\nUrgencia: ${atendido.gravedad}\nCUI: ${atendido.cui}\nSexo: ${atendido.sexo}`, "Atención Médica");
        actualizarUI();
    } else {
        mostrarAlerta("No hay pacientes en la cola de espera.", "Cola Vacía");
    }
});

document.getElementById('listaEspera').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-eliminar')) {
        const pacienteId = parseInt(e.target.getAttribute('data-id'));
        triageQueue.removeById(pacienteId);
        actualizarUI();
    }
});

// 5. ACTUALIZAR INTERFAZ GRÁFICA
function actualizarUI() {
    const div = document.getElementById('listaEspera');
    div.innerHTML = '<h3>Cola de espera:</h3>';
    
    if(triageQueue.heap.length === 0) {
        div.innerHTML += '<p style="justify-content: center; color: var(--text-muted);">La cola está vacía.</p>';
        return;
    }

    triageQueue.heap.forEach(p => {
        div.innerHTML += `
            <p style="flex-direction: column; align-items: flex-start; gap: 5px;">
                <span style="width: 100%; display: flex; justify-content: space-between; align-items: center;">
                    <span><strong>${p.nombre}</strong> (Urgencia: <strong>${p.gravedad}</strong>)</span>
                    <button class="btn-eliminar" data-id="${p.id}">❌ Cancelar</button>
                </span>
                <span style="font-size: 0.85rem; color: var(--text-muted);">
                    CUI: ${p.cui} | Nacimiento: ${p.fecha} | Sexo: ${p.sexo}
                </span>
            </p>`;
    });
}