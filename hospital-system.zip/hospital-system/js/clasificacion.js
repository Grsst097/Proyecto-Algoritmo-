import { MaxHeap } from './estructuras/PriorityQueue.js';

const triageQueue = new MaxHeap();

// Base de datos temporal en memoria para recordar pacientes por su CUI
const pacientesRegistrados = {};

// 1. CONEXIÓN CON LOS INPUTS DEL HTML
const inputNombre = document.getElementById('nombreP');
const inputGravedad = document.getElementById('gravedad');
const inputCui = document.getElementById('cui');
const inputFecha = document.getElementById('fechaNacimiento');
const selectGenero = document.getElementById('genero');

// 2. VALIDACIONES Y AUTORELLENO EN TIEMPO REAL
// Solo letras en nombre
inputNombre.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
});

// Solo números del 1 al 10 en gravedad
inputGravedad.addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value !== '') {
        let valor = parseInt(this.value, 10);
        if (valor > 10) this.value = 10;
        else if (valor === 0) this.value = 1;
    }
});

// CUI: Solo letras y números + AUTORELLENO si ya existe
inputCui.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
    const cuiIngresado = this.value.trim();

    if (pacientesRegistrados[cuiIngresado]) {
        const paciente = pacientesRegistrados[cuiIngresado];
        inputNombre.value = paciente.nombre;
        inputFecha.value = paciente.fecha;
        selectGenero.value = paciente.genero;
    }
});

// 3. FUNCIÓN PARA LIMPIAR TODO EL FORMULARIO
function limpiarFormulario() {
    inputNombre.value = '';
    inputGravedad.value = '';
    inputCui.value = '';
    inputFecha.value = '';
    selectGenero.value = '';
}

// LÓGICA PRINCIPAL DE INGRESO (Reutilizable para el Botón y para la tecla Enter)
function registrarPaciente() {
    const nombre = inputNombre.value;
    const gravedad = parseInt(inputGravedad.value);
    const cui = inputCui.value;
    const fecha = inputFecha.value;
    const genero = selectGenero.value;
    
    if(nombre && gravedad && cui && fecha && genero) {
        pacientesRegistrados[cui] = { nombre, fecha, genero };

        const id = Date.now(); 
        triageQueue.insert({ id, nombre, gravedad, cui, fecha, genero });
        
        limpiarFormulario(); 
        actualizarUI();
    } else {
        alert("Por favor complete todos los campos (Nombre, Gravedad, CUI, Fecha y Género).");
    }
}

// 4. ACCIONES DE LOS BOTONES Y TECLADO
// Botón: Limpiar Datos manualmente
document.getElementById('btnLimpiar').addEventListener('click', () => {
    limpiarFormulario();
});

// Botón: Ingresar a Triage
document.getElementById('btnIngresar').addEventListener('click', () => {
    registrarPaciente();
});

// NUEVO: Permitir ingresar presionando la tecla Enter en cualquier campo
const camposFormulario = [inputNombre, inputGravedad, inputCui, inputFecha, selectGenero];
camposFormulario.forEach(campo => {
    campo.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault(); // Evita recargas o comportamientos extraños del navegador
            registrarPaciente(); // Ejecuta la misma función que el botón
        }
    });
});

// Botón: Atender Próximo
document.getElementById('btnAtender').addEventListener('click', () => {
    if(triageQueue.heap.length > 0) {
        const atendido = triageQueue.extractMax();
        alert(`Atendiendo a: ${atendido.nombre} (Gravedad: ${atendido.gravedad})`);
        actualizarUI();
    } else {
        alert("No hay pacientes en la cola.");
    }
});

// Botón: Cancelar (Eliminar de la fila)
document.getElementById('listaEspera').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-eliminar')) {
        const pacienteId = parseInt(e.target.getAttribute('data-id'));
        triageQueue.removeById(pacienteId);
        actualizarUI();
    }
});

// 5. ACTUALIZAR INTERFAZ GRÁFICA
function actualizarUI() {
    const div = document.getElementById('listaEspera');
    div.innerHTML = '<h3>Cola de espera:</h3>';
    
    if(triageQueue.heap.length === 0) {
        div.innerHTML += '<p style="justify-content: center; color: var(--text-muted);">La cola está vacía.</p>';
        return;
    }

    triageQueue.heap.forEach(p => {
        div.innerHTML += `
            <p style="flex-direction: column; align-items: flex-start; gap: 5px;">
                <span style="width: 100%; display: flex; justify-content: space-between; align-items: center;">
                    <span><strong>${p.nombre}</strong> (Urgencia: <strong>${p.gravedad}</strong>)</span>
                    <button class="btn-eliminar" data-id="${p.id}">❌ Cancelar</button>
                </span>
                <span style="font-size: 0.85rem; color: var(--text-muted);">
                    CUI: ${p.cui} | Nacimiento: ${p.fecha} | Género: ${p.genero}
                </span>
            </p>`;
    });
}