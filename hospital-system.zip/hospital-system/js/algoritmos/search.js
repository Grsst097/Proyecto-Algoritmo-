// Búsqueda Binaria en Arreglos Ordenados
export function binarySearch(sortedArray, key, targetValue) {
    let left = 0;
    let right = sortedArray.length - 1;

    while (left <= right) {
        let mid = Math.floor((left + right) / 2);
        if (sortedArray[mid][key] === targetValue) return sortedArray[mid];
        if (sortedArray[mid][key] < targetValue) left = mid + 1;
        else right = mid - 1;
    }
    return null;
}

// Búsqueda recursiva en un Árbol Binario (BST)
export function searchInBST(root, targetId) {
    if (root === null || root.paciente.id === targetId) {
        return root;
    }
    if (targetId < root.paciente.id) {
        return searchInBST(root.left, targetId);
    }
    return searchInBST(root.right, targetId);
}