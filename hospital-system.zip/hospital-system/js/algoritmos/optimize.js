// Algoritmo de Optimización Voraz: Asignación de carga médica equitativa
export function greedyDoctorAssignment(doctorsList, patient) {
    // doctorsList es un arreglo de objetos: { id: 1, especialidad: 'General', load: 3 }
    let bestDoctor = null;
    let minLoad = Infinity;

    for (let doc of doctorsList) {
        if (doc.especialidad === patient.requiereEspecialidad) {
            if (doc.load < minLoad) {
                minLoad = doc.load;
                bestDoctor = doc; // Se toma la mejor decisión en el momento
            }
        }
    }
    
    if (bestDoctor) {
        bestDoctor.load += 1; // Se asigna al médico
    }
    return bestDoctor;
}