// 1. FUNCIONES DE LECTURA Y ALMACENAMIENTO DE INGRESOS Y EGRESOS
function obtenerPacientesGuardados() {
    return JSON.parse(localStorage.getItem('pacientesRegistrados_SM')) || {};
}

function obtenerHistorialCompleto() {
    return JSON.parse(localStorage.getItem('historialMedico_SM')) || {};
}

function obtenerEgresosGuardados() {
    return JSON.parse(localStorage.getItem('egresosHospital_SM')) || [];
}

function guardarListaEgresos(lista) {
    localStorage.setItem('egresosHospital_SM', JSON.stringify(lista));
}

function normalizarTexto(texto) {
    return (texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

// 2. ESTADO DEL FILTRO TEMPORAL (Por defecto: 'dia')
let periodoActual = 'dia';

// Referencias del DOM
const subtituloPeriodo = document.getElementById('subtituloPeriodo');
const statTotalIngresos = document.getElementById('statTotalIngresos');
const statTotalEgresos = document.getElementById('statTotalEgresos');
const statBalanceActivos = document.getElementById('statBalanceActivos');
const statTasaEgreso = document.getElementById('statTasaEgreso');
const barrasComparativas = document.getElementById('barrasComparativas');
const listaDetalleIngresos = document.getElementById('listaDetalleIngresos');
const listaDetalleEgresos = document.getElementById('listaDetalleEgresos');
const contadorListaIngresos = document.getElementById('contadorListaIngresos');
const contadorListaEgresos = document.getElementById('contadorListaEgresos');

const inputCuiEgreso = document.getElementById('inputCuiEgreso');
const dropdownSugerencias = document.getElementById('sugerenciasEgresoDropdown');
const selectModuloEgreso = document.getElementById('moduloEgreso');

function mostrarAlerta(mensaje, titulo = "Estadísticas Hospitalarias") {
    const modal = document.getElementById('modalSistema');
    document.getElementById('modalTitulo').textContent = titulo;
    document.getElementById('modalTexto').textContent = mensaje;
    modal.style.display = 'flex';
}

document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

// 3. LÓGICA DE FILTRADO POR DÍA, SEMANA, MES Y AÑO
function obtenerFechaDeRegistro(registro) {
    if (registro.timestamp) return new Date(registro.timestamp);
    if (registro.id && typeof registro.id === 'number' && registro.id > 1000000000000) {
        return new Date(registro.id);
    }
    return new Date();
}

function perteneceAlPeriodo(registro, periodo) {
    const fechaReg = obtenerFechaDeRegistro(registro);
    const hoy = new Date();

    if (periodo === 'dia') {
        return (
            fechaReg.getDate() === hoy.getDate() &&
            fechaReg.getMonth() === hoy.getMonth() &&
            fechaReg.getFullYear() === hoy.getFullYear()
        );
    }

    if (periodo === 'semana') {
        // Calcula el inicio de la semana actual (Lunes a las 00:00:00)
        const inicioSemana = new Date(hoy);
        const diaSemana = hoy.getDay() === 0 ? 6 : hoy.getDay() - 1; 
        inicioSemana.setDate(hoy.getDate() - diaSemana);
        inicioSemana.setHours(0, 0, 0, 0);

        const finSemana = new Date(inicioSemana);
        finSemana.setDate(inicioSemana.getDate() + 6);
        finSemana.setHours(23, 59, 59, 999);

        return fechaReg >= inicioSemana && fechaReg <= finSemana;
    }

    if (periodo === 'mes') {
        return (
            fechaReg.getMonth() === hoy.getMonth() &&
            fechaReg.getFullYear() === hoy.getFullYear()
        );
    }

    if (periodo === 'anio') {
        return fechaReg.getFullYear() === hoy.getFullYear();
    }

    return true;
}

function obtenerTextoSubtitulo(periodo) {
    const hoy = new Date();
    const meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

    if (periodo === 'dia') {
        return `Mostrando ingresos y egresos del día de hoy (${hoy.toLocaleDateString('es-GT')})`;
    }
    if (periodo === 'semana') {
        return `Mostrando ingresos y egresos acumulados de la semana actual`;
    }
    if (periodo === 'mes') {
        return `Mostrando ingresos y egresos del mes de ${meses[hoy.getMonth()]} de ${hoy.getFullYear()}`;
    }
    if (periodo === 'anio') {
        return `Mostrando ingresos y egresos acumulados del año ${hoy.getFullYear()}`;
    }
}

// 4. RECOPILAR TODOS LOS INGRESOS Y EGRESOS FILTRADOS
function obtenerIngresosFiltrados(periodo) {
    const historial = obtenerHistorialCompleto();
    const listaIngresos = [];

    Object.entries(historial).forEach(([cui, eventos]) => {
        if (Array.isArray(eventos)) {
            eventos.forEach(ev => {
                if (perteneceAlPeriodo(ev, periodo)) {
                    listaIngresos.push({ ...ev, cui });
                }
            });
        }
    });

    return listaIngresos.sort((a, b) => (b.id || 0) - (a.id || 0));
}

function obtenerEgresosFiltrados(periodo) {
    const egresos = obtenerEgresosGuardados();
    return egresos
        .filter(eg => perteneceAlPeriodo(eg, periodo))
        .sort((a, b) => (b.id || 0) - (a.id || 0));
}

// 5. RENDERIZADO DE ESTADÍSTICAS, BARRAS Y LISTAS
function actualizarEstadisticasUI() {
    subtituloPeriodo.textContent = obtenerTextoSubtitulo(periodoActual);

    const ingresos = obtenerIngresosFiltrados(periodoActual);
    const egresos = obtenerEgresosFiltrados(periodoActual);

    const totalIng = ingresos.length;
    const totalEgr = egresos.length;
    const enPermanencia = Math.max(0, totalIng - totalEgr);
    const tasa = totalIng > 0 ? Math.min(100, Math.round((totalEgr / totalIng) * 100)) : 0;

    // Actualizar KPIs
    statTotalIngresos.textContent = totalIng;
    statTotalEgresos.textContent = totalEgr;
    statBalanceActivos.textContent = enPermanencia;
    statTasaEgreso.textContent = `${tasa}%`;

    contadorListaIngresos.textContent = totalIng;
    contadorListaEgresos.textContent = totalEgr;

    // Renderizar Barras Comparativas por Módulo
    const modulos = ["Triage", "Asignación Médica", "Gestión de Camas"];
    barrasComparativas.innerHTML = '';

    modulos.forEach(mod => {
        const ingMod = ingresos.filter(i => i.modulo === mod).length;
        const egrMod = egresos.filter(e => e.modulo === mod || (mod === "Asignación Médica" && e.modulo === "Alta Hospitalaria General")).length;
        const maxValor = Math.max(1, ingMod, egrMod);

        const porcIng = Math.round((ingMod / maxValor) * 100);
        const porcEgr = Math.round((egrMod / maxValor) * 100);

        barrasComparativas.innerHTML += `
            <div style="background: #f8fafc; border: 1px solid var(--border-color); border-radius: 10px; padding: 14px 16px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 6px;">
                    <strong style="color: var(--text-dark); font-size: 0.95rem;">${mod}</strong>
                    <span style="font-size: 0.85rem; color: var(--text-muted);">
                        📥 Ingresos: <strong style="color: var(--primary-blue);">${ingMod}</strong> &nbsp;|&nbsp; 
                        📤 Egresos: <strong style="color: #2e7d32;">${egrMod}</strong>
                    </span>
                </div>
                <div style="display: flex; flex-direction: column; gap: 6px;">
                    <div style="width: 100%; background: #e2e8f0; height: 10px; border-radius: 6px; overflow: hidden;">
                        <div style="width: ${porcIng}%; background: var(--primary-blue); height: 100%; transition: width 0.3s ease;" title="Ingresos: ${ingMod}"></div>
                    </div>
                    <div style="width: 100%; background: #e2e8f0; height: 10px; border-radius: 6px; overflow: hidden;">
                        <div style="width: ${porcEgr}%; background: #2e7d32; height: 100%; transition: width 0.3s ease;" title="Egresos: ${egrMod}"></div>
                    </div>
                </div>
            </div>
        `;
    });

    // Renderizar Lista Detallada de Ingresos
    if (ingresos.length === 0) {
        listaDetalleIngresos.innerHTML = `<p style="justify-content: center; color: var(--text-muted); margin: 0;">No hay ingresos registrados en este período.</p>`;
    } else {
        listaDetalleIngresos.innerHTML = '';
        ingresos.forEach(ing => {
            listaDetalleIngresos.innerHTML += `
                <div class="feed-item" style="border-left: 4px solid var(--primary-blue);">
                    <div class="feed-top">
                        <strong>${ing.nombre} <span style="font-weight: 400; color: var(--text-muted); font-size: 0.82rem;">(CUI: ${ing.cui})</span></strong>
                        <span class="feed-modulo" style="color: var(--primary-blue);">📥 ${ing.modulo}</span>
                    </div>
                    <div class="feed-mid">
                        🩺 ${ing.condicion || 'Consulta general'} — 🏥 <strong>${ing.area || 'Área asignada'}</strong>
                    </div>
                    <div class="feed-bottom">
                        <span>👨‍⚕️ ${Array.isArray(ing.equipo) ? ing.equipo.join(' + ') : 'Personal asignado'}</span>
                        <span>🕒 ${ing.fechaHora}</span>
                    </div>
                </div>
            `;
        });
    }

    // Renderizar Lista Detallada de Egresos
    if (egresos.length === 0) {
        listaDetalleEgresos.innerHTML = `<p style="justify-content: center; color: var(--text-muted); margin: 0;">No hay egresos registrados en este período.</p>`;
    } else {
        listaDetalleEgresos.innerHTML = '';
        egresos.forEach(egr => {
            listaDetalleEgresos.innerHTML += `
                <div class="feed-item" style="border-left: 4px solid #2e7d32;">
                    <div class="feed-top">
                        <strong>${egr.nombre} <span style="font-weight: 400; color: var(--text-muted); font-size: 0.82rem;">(CUI: ${egr.cui})</span></strong>
                        <span class="feed-modulo" style="color: #2e7d32;">📤 Egreso (${egr.modulo})</span>
                    </div>
                    <div class="feed-mid">
                        🩺 ${egr.condicion || 'Alta clínica'} — 🏥 <strong>${egr.area || 'Unidad hospitalaria'}</strong>
                    </div>
                    <div class="feed-bottom">
                        <span>✔ ${egr.detalle || 'Paciente dado de alta satisfactoriamente'}</span>
                        <span>🕒 ${egr.fechaHora}</span>
                    </div>
                </div>
            `;
        });
    }
}

// 6. EVENTOS DE LOS BOTONES DE FILTRO (DÍA, SEMANA, MES, AÑO)
document.querySelectorAll('.filtro-tiempo-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        periodoActual = btn.getAttribute('data-periodo');
        document.querySelectorAll('.filtro-tiempo-btn').forEach(b => b.classList.add('btn-secondary'));
        btn.classList.remove('btn-secondary');
        actualizarEstadisticasUI();
    });
});

// 7. AUTOCOMPLETADO Y REGISTRO DE EGRESO / DESHACER (PILA DE EGRESOS)
inputCuiEgreso.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    mostrarSugerenciasPacientes(this.value.trim());
});

inputCuiEgreso.addEventListener('focus', function() {
    mostrarSugerenciasPacientes(this.value.trim());
});

function mostrarSugerenciasPacientes(filtro = "") {
    const pacientes = obtenerPacientesGuardados();
    const historial = obtenerHistorialCompleto();
    const cuis = Object.keys(pacientes);

    dropdownSugerencias.innerHTML = '';
    let coincidencias = 0;

    cuis.forEach(cui => {
        const pac = pacientes[cui];
        if (cui.toLowerCase().includes(filtro.toLowerCase()) || normalizarTexto(pac.nombre).includes(normalizarTexto(filtro))) {
            coincidencias++;
            const ultimoIngreso = historial[cui] && historial[cui][0] ? historial[cui][0] : null;
            const infoExtra = ultimoIngreso ? `${ultimoIngreso.modulo} (${ultimoIngreso.area})` : 'Sin ingresos previos';

            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">CUI: ${cui} — ${pac.nombre}</span>
                <span class="dropdown-item-sub">🏥 Último ingreso: ${infoExtra}</span>
            `;

            item.addEventListener('click', () => {
                inputCuiEgreso.value = cui;
                if (ultimoIngreso && ultimoIngreso.modulo) {
                    selectModuloEgreso.value = ultimoIngreso.modulo;
                }
                dropdownSugerencias.style.display = 'none';
            });

            dropdownSugerencias.appendChild(item);
        }
    });

    dropdownSugerencias.style.display = coincidencias > 0 ? 'block' : 'none';
}

document.addEventListener('click', (e) => {
    if (!e.target.closest('.buscador-area-container')) {
        dropdownSugerencias.style.display = 'none';
    }
});

// Botón: Registrar Egreso
document.getElementById('btnRegistrarEgreso').addEventListener('click', () => {
    const cui = inputCuiEgreso.value.trim().toUpperCase();
    if (!cui) {
        mostrarAlerta("Por favor ingrese o seleccione el CUI del paciente para registrar su egreso.", "Campo Vacío");
        return;
    }

    const pacientes = obtenerPacientesGuardados();
    const historial = obtenerHistorialCompleto();
    const paciente = pacientes[cui];

    if (!paciente) {
        mostrarAlerta(`No se encontró ningún paciente registrado con el CUI: ${cui}.`, "Paciente No Encontrado");
        return;
    }

    const ultimoEvento = historial[cui] && historial[cui][0] ? historial[cui][0] : {};
    const modulo = selectModuloEgreso.value;

    const nuevoEgreso = {
        id: Date.now(),
        timestamp: Date.now(),
        cui,
        nombre: paciente.nombre,
        modulo,
        condicion: ultimoEvento.condicion || "Atención médica completada",
        area: ultimoEvento.area || "General",
        detalle: "Alta médica registrada en sistema",
        fechaHora: new Date().toLocaleString('es-GT')
    };

    const listaEgresos = obtenerEgresosGuardados();
    listaEgresos.unshift(nuevoEgreso);
    guardarListaEgresos(listaEgresos);

    inputCuiEgreso.value = '';
    actualizarEstadisticasUI();
    mostrarAlerta(`Se ha registrado el egreso (alta médica) de:\nPaciente: ${paciente.nombre}\nCUI: ${cui}\nMódulo: ${modulo}`, "Egreso Registrado");
});

// Botón: Deshacer Último Egreso (Pop de la Pila)
document.getElementById('btnDeshacerEgreso').addEventListener('click', () => {
    const listaEgresos = obtenerEgresosGuardados();
    if (listaEgresos.length === 0) {
        mostrarAlerta("No hay egresos registrados para deshacer.", "Sin Egresos");
        return;
    }

    const eliminado = listaEgresos.shift();
    guardarListaEgresos(listaEgresos);
    actualizarEstadisticasUI();
    mostrarAlerta(`Se ha revertido el último egreso registrado:\nPaciente: ${eliminado.nombre} (CUI: ${eliminado.cui})`, "Egreso Revertido");
});

// Inicializar vista por defecto en "Día"
actualizarEstadisticasUI();