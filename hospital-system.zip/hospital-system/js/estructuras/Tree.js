class TreeNode {
    constructor(paciente) {
        this.paciente = paciente; // Ej: { id: 105, nombre: 'Juan' }
        this.left = null;
        this.right = null;
    }
}

export class BinarySearchTree {
    constructor() {
        this.root = null;
    }

    insert(paciente) {
        const newNode = new TreeNode(paciente);
        if (this.root === null) {
            this.root = newNode;
            return this;
        }
        let current = this.root;
        while (true) {
            if (paciente.id === current.paciente.id) return undefined; // Duplicados no
            if (paciente.id < current.paciente.id) {
                if (current.left === null) {
                    current.left = newNode;
                    return this;
                }
                current = current.left;
            } else {
                if (current.right === null) {
                    current.right = newNode;
                    return this;
                }
                current = current.right;
            }
        }
    }
}