export class HospitalGraph {
    constructor() {
        this.adjacencyList = new Map(); // Tabla Hash subyacente
    }

    addWard(ward) {
        this.adjacencyList.set(ward, []);
    }

    addEdge(ward1, ward2) {
        this.adjacencyList.get(ward1).push(ward2);
        this.adjacencyList.get(ward2).push(ward1);
    }

    // Algoritmo de Búsqueda 1: BFS para encontrar la cama más cercana
    findNearestAvailableBed(startWard, bedStatusMap) {
        const queue = [startWard]; // Uso de estructura de datos Cola
        const visited = new Set([startWard]);

        while (queue.length > 0) {
            const currentWard = queue.shift();
            
            if (bedStatusMap.get(currentWard) === "DISPONIBLE") {
                return currentWard;
            }

            const neighbors = this.adjacencyList.get(currentWard);
            for (let neighbor of neighbors) {
                if (!visited.has(neighbor)) {
                    visited.add(neighbor);
                    queue.push(neighbor);
                }
            }
        }
        return null; // No hay camas
    }
}