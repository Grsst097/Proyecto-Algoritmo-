// Implementación de un Max-Heap usando Arreglos
export class MaxHeap {
    constructor() {
        this.heap = [];
    }

    insert(paciente) {
        this.heap.push(paciente);
        this.bubbleUp();
    }

    bubbleUp() {
        let index = this.heap.length - 1;
        const element = this.heap[index];
        while (index > 0) {
            let parentIndex = Math.floor((index - 1) / 2);
            let parent = this.heap[parentIndex];
            if (element.gravedad <= parent.gravedad) break;
            this.heap[parentIndex] = element;
            this.heap[index] = parent;
            index = parentIndex;
        }
    }

    extractMax() {
        const max = this.heap[0];
        const end = this.heap.pop();
        if (this.heap.length > 0) {
            this.heap[0] = end;
            this.sinkDown(0);
        }
        return max;
    }

    sinkDown(index) {
        let length = this.heap.length;
        let element = this.heap[index];
        while (true) {
            let leftChildIdx = 2 * index + 1;
            let rightChildIdx = 2 * index + 2;
            let leftChild, rightChild;
            let swap = null;

            if (leftChildIdx < length) {
                leftChild = this.heap[leftChildIdx];
                if (leftChild.gravedad > element.gravedad) swap = leftChildIdx;
            }
            if (rightChildIdx < length) {
                rightChild = this.heap[rightChildIdx];
                if ((swap === null && rightChild.gravedad > element.gravedad) || 
                    (swap !== null && rightChild.gravedad > leftChild.gravedad)) {
                    swap = rightChildIdx;
                }
            }
            if (swap === null) break;
            this.heap[index] = this.heap[swap];
            this.heap[swap] = element;
            index = swap;
        }
    }

// (Mantén el resto de tu código de PriorityQueue.js igual y agrega esto al final de la clase)

    // NUEVA FUNCIÓN: Eliminar un paciente específico y reestructurar el Heap (Heapify)
    removeById(id) {
        // 1. Filtramos y eliminamos al paciente usando su ID
        this.heap = this.heap.filter(p => p.id !== id);
        
        // 2. Reconstruimos el Heap desde los nodos padre hacia abajo
        // Esto garantiza que la regla del Max-Heap se mantenga intacta
        for (let i = Math.floor(this.heap.length / 2) - 1; i >= 0; i--) {
            this.sinkDown(i);
        }
    }
}