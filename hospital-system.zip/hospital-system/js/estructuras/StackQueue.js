// Implementación de Nodos para la Lista Enlazada
class Node {
    constructor(value) {
        this.value = value;
        this.next = null;
    }
}

// Pila (Stack) usando Lista Enlazada
export class Stack {
    constructor() {
        this.first = null;
        this.last = null;
        this.size = 0;
    }

    // Agregar al historial (Push)
    push(val) {
        var newNode = new Node(val);
        if (!this.first) {
            this.first = newNode;
            this.last = newNode;
        } else {
            var temp = this.first;
            this.first = newNode;
            this.first.next = temp;
        }
        return ++this.size;
    }

    // Deshacer acción (Pop)
    pop() {
        if (!this.first) return null;
        var temp = this.first;
        if (this.first === this.last) {
            this.last = null;
        }
        this.first = this.first.next;
        this.size--;
        return temp.value;
    }
}