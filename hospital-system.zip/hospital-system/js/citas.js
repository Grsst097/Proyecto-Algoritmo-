// 1. FUNCIONES PARA LEER LA MEMORIA DEL SISTEMA
function obtenerPacientesGuardados() {
    return JSON.parse(localStorage.getItem('pacientesRegistrados_SM')) || {};
}

function obtenerHistorialCompleto() {
    return JSON.parse(localStorage.getItem('historialMedico_SM')) || {};
}

function calcularEdad(fechaNacimiento) {
    if (!fechaNacimiento) return "N/A";
    const hoy = new Date();
    const cumple = new Date(fechaNacimiento + "T00:00:00");
    let edad = hoy.getFullYear() - cumple.getFullYear();
    const mes = hoy.getMonth() - cumple.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < cumple.getDate())) {
        edad--;
    }
    return edad;
}

// 2. REFERENCIAS DEL DOM Y MODAL
const inputBuscarCui = document.getElementById('inputBuscarCui');
const dropdownSugerencias = document.getElementById('sugerenciasCuiDropdown');
const divFichaPaciente = document.getElementById('fichaPaciente');
const divContenedorHistorial = document.getElementById('contenedorHistorial');

function mostrarAlerta(mensaje, titulo = "Historial Médico") {
    const modal = document.getElementById('modalSistema');
    document.getElementById('modalTitulo').textContent = titulo;
    document.getElementById('modalTexto').textContent = mensaje;
    modal.style.display = 'flex';
}

document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

// 3. VALIDACIÓN ALFANUMÉRICA Y SUGERENCIAS EN TIEMPO REAL POR CUI
inputBuscarCui.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '');
    const texto = this.value.trim();
    mostrarSugerenciasCui(texto);
});

inputBuscarCui.addEventListener('focus', function() {
    mostrarSugerenciasCui(this.value.trim());
});

function mostrarSugerenciasCui(filtro = "") {
    const pacientes = obtenerPacientesGuardados();
    const historial = obtenerHistorialCompleto();
    const todosLosCui = new Set([...Object.keys(pacientes), ...Object.keys(historial)]);

    dropdownSugerencias.innerHTML = "";
    let coincidencias = 0;

    todosLosCui.forEach(cui => {
        const datosPac = pacientes[cui] || (historial[cui] && historial[cui][0]) || {};
        const nombre = datosPac.nombre || "Paciente Registrado";
        
        if (cui.toLowerCase().includes(filtro.toLowerCase()) || nombre.toLowerCase().includes(filtro.toLowerCase())) {
            coincidencias++;
            const totalVisitas = historial[cui] ? historial[cui].length : 0;

            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">CUI: ${cui} — ${nombre}</span>
                <span class="dropdown-item-sub">📋 Registros en historial: ${totalVisitas}</span>
            `;

            item.addEventListener('click', () => {
                inputBuscarCui.value = cui;
                dropdownSugerencias.style.display = 'none';
                buscarHistorialPorCui(cui);
            });

            dropdownSugerencias.appendChild(item);
        }
    });

    if (todosLosCui.size > 0 && coincidencias > 0) {
        dropdownSugerencias.style.display = 'block';
    } else {
        dropdownSugerencias.style.display = 'none';
    }
}

document.addEventListener('click', (e) => {
    if (!e.target.closest('.buscador-area-container')) {
        dropdownSugerencias.style.display = 'none';
    }
});

// 4. FUNCIÓN PRINCIPAL: BUSCAR Y MOSTRAR EL HISTORIAL DEL PACIENTE
function buscarHistorialPorCui(cuiParam) {
    const cui = (cuiParam || inputBuscarCui.value).trim();
    dropdownSugerencias.style.display = 'none';

    if (!cui) {
        mostrarAlerta("Por favor ingrese un número de CUI para realizar la búsqueda.", "Campo Vacío");
        return;
    }

    const pacientes = obtenerPacientesGuardados();
    const historialGeneral = obtenerHistorialCompleto();
    const registrosPaciente = historialGeneral[cui] || [];
    const datosPersonales = pacientes[cui] || registrosPaciente[0];

    if (!datosPersonales && registrosPaciente.length === 0) {
        divFichaPaciente.style.display = 'none';
        divContenedorHistorial.innerHTML = `
            <h3>Registros Clínicos:</h3>
            <p style="justify-content: center; color: var(--text-muted);">No se encontró ningún paciente ni historial médico asociado al CUI <strong>${cui}</strong>.</p>
        `;
        mostrarAlerta(`No existen registros en Triage ni en Asignación Médica para el CUI: ${cui}`, "Sin Resultados");
        return;
    }

    // Contabilizar cuántas veces estuvo en Triage y cuántas en Asignación Médica
    const vecesTriage = registrosPaciente.filter(r => r.modulo === "Triage").length;
    const vecesAsignacion = registrosPaciente.filter(r => r.modulo === "Asignación Médica").length;
    const fechaNac = datosPersonales.fecha || datosPersonales.fechaNacimiento || "No registrada";
    const edadActual = calcularEdad(fechaNac);
    const sexoPac = datosPersonales.sexo || datosPersonales.genero || "No registrado";

    // Renderizar Ficha de Resumen del Paciente
    divFichaPaciente.style.display = 'block';
    divFichaPaciente.innerHTML = `
        <div class="card" style="flex-direction: column; align-items: flex-start; gap: 12px; border-left: 5px solid var(--primary-blue);">
            <div style="width: 100%; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div>
                    <h3 style="margin: 0; color: var(--primary-blue); font-size: 1.3rem;">👤 ${datosPersonales.nombre}</h3>
                    <span style="font-size: 0.9rem; color: var(--text-muted);">
                        <strong>CUI:</strong> ${cui} | <strong>Fecha de Nacimiento:</strong> ${fechaNac} (${edadActual} años) | <strong>Sexo:</strong> ${sexoPac}
                    </span>
                </div>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <span style="background: rgba(0, 91, 150, 0.1); color: var(--primary-blue); padding: 6px 14px; border-radius: 20px; font-weight: 600; font-size: 0.88rem;">
                        🚨 Veces en Triage: ${vecesTriage}
                    </span>
                    <span style="background: rgba(46, 125, 50, 0.12); color: #2e7d32; padding: 6px 14px; border-radius: 20px; font-weight: 600; font-size: 0.88rem;">
                        👨‍⚕️ Veces en Asignación Médica: ${vecesAsignacion}
                    </span>
                    <span style="background: #f0f4f8; color: var(--text-dark); padding: 6px 14px; border-radius: 20px; font-weight: 600; font-size: 0.88rem;">
                        📋 Total de Ingresos: ${registrosPaciente.length}
                    </span>
                </div>
            </div>
        </div>
    `;

    // Renderizar cada evento del historial
    divContenedorHistorial.innerHTML = `<h3>Detalle de Ingresos Clínicos (${registrosPaciente.length}):</h3>`;

    if (registrosPaciente.length === 0) {
        divContenedorHistorial.innerHTML += `
            <p style="justify-content: center; color: var(--text-muted);">El paciente está registrado, pero aún no cuenta con eventos detallados en el historial.</p>
        `;
        return;
    }

    registrosPaciente.forEach((reg, index) => {
        const esTriage = reg.modulo === "Triage";
        const colorModulo = esTriage ? "#005b96" : "#2e7d32";
        const iconoModulo = esTriage ? "🚨 Ingreso en Triage" : "👨‍⚕️ Asignación Médica";
        const textoGravedad = reg.gravedad ? ` | ⚡ Gravedad: <strong>${reg.gravedad}/10</strong>` : "";
        const listaMedicos = Array.isArray(reg.equipo) && reg.equipo.length > 0
            ? reg.equipo.join(' + ')
            : "Personal estándar del área";

        divContenedorHistorial.innerHTML += `
            <p style="flex-direction: column; align-items: flex-start; gap: 6px; border-left: 4px solid ${colorModulo};">
                <span style="width: 100%; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <span style="color: ${colorModulo}; font-weight: 700; font-size: 1rem;">
                        ${iconoModulo} #${registrosPaciente.length - index}
                    </span>
                    <span style="font-size: 0.82rem; color: var(--text-muted); font-weight: 500;">
                        🕒 Fecha y hora de registro: ${reg.fechaHora}
                    </span>
                </span>
                <span style="font-size: 0.92rem; color: var(--text-dark);">
                    🩺 <strong>Enfermedad / Diagnóstico / Quebradura:</strong> ${reg.condicion} ${textoGravedad}
                </span>
                <span style="font-size: 0.92rem; color: var(--primary-blue); font-weight: 600;">
                    🏥 Área Médica: ${reg.area}
                </span>
                <span style="font-size: 0.88rem; color: var(--text-dark);">
                    👨‍⚕️ <strong>Médicos Asignados:</strong> ${listaMedicos}
                </span>
                <span style="font-size: 0.82rem; color: var(--text-muted);">
                    Datos registrados: Paciente ${reg.nombre} (${reg.edad} años) | CUI: ${reg.cui} | Nacimiento: ${reg.fechaNacimiento} | Sexo: ${reg.sexo}
                </span>
            </p>
        `;
    });
}

// 5. EVENTOS DE BOTONES Y TECLA ENTER
document.getElementById('btnBuscarHistorial').addEventListener('click', () => {
    buscarHistorialPorCui();
});

document.getElementById('btnLimpiarBusqueda').addEventListener('click', () => {
    inputBuscarCui.value = '';
    dropdownSugerencias.style.display = 'none';
    divFichaPaciente.style.display = 'none';
    divContenedorHistorial.innerHTML = `
        <h3>Registros Clínicos:</h3>
        <p style="justify-content: center; color: var(--text-muted);">Ingrese un número de CUI arriba para visualizar las veces que el paciente estuvo en Triage y Asignación Médica.</p>
    `;
});

// Permitir buscar con la tecla Enter
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const modal = document.getElementById('modalSistema');
        if (modal && modal.style.display === 'flex') {
            e.preventDefault();
            modal.style.display = 'none';
            return;
        }

        if (document.activeElement === inputBuscarCui || inputBuscarCui.value.trim() !== '') {
            e.preventDefault();
            buscarHistorialPorCui();
        }
    }
});