function normalizarTexto(texto) {
    return (texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

// 1. DEPURACIÓN Y UNIFICACIÓN AUTOMÁTICA DE PERSONAS Y CUI CONSTANTES
function unificarYNormalizarBaseDeDatos() {
    const rawPacientes = JSON.parse(localStorage.getItem('pacientesRegistrados_SM')) || {};
    const rawHistorial = JSON.parse(localStorage.getItem('historialMedico_SM')) || {};

    const pacientesLimpios = {};
    const historialLimpio = {};
    const mapaNombreACuiOficial = {};

    // 1. Unificar pacientes garantizando 1 CUI constante por persona y 1 persona por CUI
    Object.entries(rawPacientes).forEach(([cuiOriginal, datos]) => {
        if (!datos || !datos.nombre) return;
        const cuiNorm = cuiOriginal.trim().toUpperCase();
        const nombreNorm = normalizarTexto(datos.nombre);

        if (!mapaNombreACuiOficial[nombreNorm]) {
            if (!pacientesLimpios[cuiNorm]) {
                mapaNombreACuiOficial[nombreNorm] = cuiNorm;
                pacientesLimpios[cuiNorm] = {
                    nombre: datos.nombre.trim(),
                    fecha: datos.fecha || datos.fechaNacimiento || "",
                    sexo: datos.sexo || datos.genero || ""
                };
            }
        } else {
            const cuiOficial = mapaNombreACuiOficial[nombreNorm];
            if (rawHistorial[cuiOriginal] && rawHistorial[cuiOriginal].length > 0) {
                if (!historialLimpio[cuiOficial]) historialLimpio[cuiOficial] = [];
                historialLimpio[cuiOficial].push(...rawHistorial[cuiOriginal]);
                delete rawHistorial[cuiOriginal];
            }
        }
    });

    // 2. Sincronizar el historial asegurando que todos los eventos de un CUI tengan los datos constantes del titular
    Object.entries(rawHistorial).forEach(([cuiOriginal, listaEventos]) => {
        if (!Array.isArray(listaEventos)) return;
        const cuiNorm = cuiOriginal.trim().toUpperCase();

        if (!pacientesLimpios[cuiNorm] && listaEventos.length > 0) {
            const primerEv = listaEventos[listaEventos.length - 1];
            const nombreNorm = normalizarTexto(primerEv.nombre);
            const cuiDestino = mapaNombreACuiOficial[nombreNorm] || cuiNorm;

            if (!pacientesLimpios[cuiDestino]) {
                mapaNombreACuiOficial[nombreNorm] = cuiDestino;
                pacientesLimpios[cuiDestino] = {
                    nombre: primerEv.nombre,
                    fecha: primerEv.fechaNacimiento || primerEv.fecha || "",
                    sexo: primerEv.sexo || primerEv.genero || ""
                };
            }
        }

        const datosTitular = pacientesLimpios[cuiNorm];
        if (datosTitular) {
            if (!historialLimpio[cuiNorm]) historialLimpio[cuiNorm] = [];
            listaEventos.forEach(ev => {
                historialLimpio[cuiNorm].push({
                    ...ev,
                    cui: cuiNorm,
                    nombre: datosTitular.nombre,
                    fechaNacimiento: datosTitular.fecha,
                    edad: calcularEdad(datosTitular.fecha),
                    sexo: datosTitular.sexo
                });
            });
        }
    });

    localStorage.setItem('pacientesRegistrados_SM', JSON.stringify(pacientesLimpios));
    localStorage.setItem('historialMedico_SM', JSON.stringify(historialLimpio));
}

function obtenerPacientesGuardados() {
    return JSON.parse(localStorage.getItem('pacientesRegistrados_SM')) || {};
}

function obtenerHistorialCompleto() {
    return JSON.parse(localStorage.getItem('historialMedico_SM')) || {};
}

function calcularEdad(fechaNacimiento) {
    if (!fechaNacimiento) return "N/A";
    const hoy = new Date();
    const cumple = new Date(fechaNacimiento + "T00:00:00");
    let edad = hoy.getFullYear() - cumple.getFullYear();
    const mes = hoy.getMonth() - cumple.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < cumple.getDate())) {
        edad--;
    }
    return edad;
}

// Ejecutar limpieza y unificación al abrir la página
unificarYNormalizarBaseDeDatos();

// 2. REFERENCIAS DEL DOM Y MODAL
const inputBuscarCui = document.getElementById('inputBuscarCui');
const dropdownSugerencias = document.getElementById('sugerenciasCuiDropdown');
const divFichaPaciente = document.getElementById('fichaPaciente');
const divContenedorHistorial = document.getElementById('contenedorHistorial');

function mostrarAlerta(mensaje, titulo = "Historial Médico") {
    const modal = document.getElementById('modalSistema');
    document.getElementById('modalTitulo').textContent = titulo;
    document.getElementById('modalTexto').textContent = mensaje;
    modal.style.display = 'flex';
}

document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

// 3. VALIDACIÓN ALFANUMÉRICA Y SUGERENCIAS EN TIEMPO REAL POR CUI
inputBuscarCui.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    const texto = this.value.trim();
    mostrarSugerenciasCui(texto);
});

inputBuscarCui.addEventListener('focus', function() {
    unificarYNormalizarBaseDeDatos();
    mostrarSugerenciasCui(this.value.trim());
});

function mostrarSugerenciasCui(filtro = "") {
    const pacientes = obtenerPacientesGuardados();
    const historial = obtenerHistorialCompleto();
    const todosLosCui = Object.keys(pacientes);

    dropdownSugerencias.innerHTML = "";
    let coincidencias = 0;

    todosLosCui.forEach(cui => {
        const datosPac = pacientes[cui];
        const nombre = datosPac.nombre || "Paciente Registrado";
        
        if (cui.toLowerCase().includes(filtro.toLowerCase()) || normalizarTexto(nombre).includes(normalizarTexto(filtro))) {
            coincidencias++;
            const registros = historial[cui] || [];
            const numTriage = registros.filter(r => r.modulo === "Triage").length;
            const numMedicos = registros.filter(r => r.modulo === "Asignación Médica").length;
            const numCamas = registros.filter(r => r.modulo === "Gestión de Camas").length;

            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">CUI: ${cui} — ${nombre}</span>
                <span class="dropdown-item-sub">📋 Total: ${registros.length} (🚨 Triage: ${numTriage} | 👨‍⚕️ Asignación: ${numMedicos} | 🛏️ Camas: ${numCamas})</span>
            `;

            item.addEventListener('click', () => {
                inputBuscarCui.value = cui;
                dropdownSugerencias.style.display = 'none';
                buscarHistorialPorCui(cui);
            });

            dropdownSugerencias.appendChild(item);
        }
    });

    if (todosLosCui.length > 0 && coincidencias > 0) {
        dropdownSugerencias.style.display = 'block';
    } else {
        dropdownSugerencias.style.display = 'none';
    }
}

document.addEventListener('click', (e) => {
    if (!e.target.closest('.buscador-area-container')) {
        dropdownSugerencias.style.display = 'none';
    }
});

// 4. FUNCIÓN PRINCIPAL: BUSCAR Y MOSTRAR EL HISTORIAL DEL PACIENTE
function buscarHistorialPorCui(cuiParam) {
    unificarYNormalizarBaseDeDatos();
    const cui = (cuiParam || inputBuscarCui.value).trim().toUpperCase();
    dropdownSugerencias.style.display = 'none';

    if (!cui) {
        mostrarAlerta("Por favor ingrese un número de CUI para realizar la búsqueda.", "Campo Vacío");
        return;
    }

    const pacientes = obtenerPacientesGuardados();
    const historialGeneral = obtenerHistorialCompleto();
    const registrosPaciente = historialGeneral[cui] || [];
    const datosPersonales = pacientes[cui];

    if (!datosPersonales && registrosPaciente.length === 0) {
        divFichaPaciente.style.display = 'none';
        divContenedorHistorial.innerHTML = `
            <h3>Registros Clínicos:</h3>
            <p style="justify-content: center; color: var(--text-muted);">No se encontró ningún paciente ni historial médico asociado al CUI <strong>${cui}</strong>.</p>
        `;
        mostrarAlerta(`No existen registros en Triage, Asignación Médica ni Gestión de Camas para el CUI: ${cui}`, "Sin Resultados");
        return;
    }

    // Contadores individuales para los 3 módulos operativos
    const vecesTriage = registrosPaciente.filter(r => r.modulo === "Triage").length;
    const vecesAsignacion = registrosPaciente.filter(r => r.modulo === "Asignación Médica").length;
    const vecesCamas = registrosPaciente.filter(r => r.modulo === "Gestión de Camas").length;

    const fechaNac = datosPersonales.fecha || "No registrada";
    const edadActual = calcularEdad(fechaNac);
    const sexoPac = datosPersonales.sexo || "No registrado";

    // Renderizar Ficha Constante del Paciente con los 4 contadores
    divFichaPaciente.style.display = 'block';
    divFichaPaciente.innerHTML = `
        <div class="card" style="flex-direction: column; align-items: flex-start; gap: 12px; border-left: 5px solid var(--primary-blue);">
            <div style="width: 100%; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div>
                    <h3 style="margin: 0; color: var(--primary-blue); font-size: 1.3rem;">👤 ${datosPersonales.nombre} <span style="font-size: 0.8rem; color: #2e7d32; font-weight: 600;">(🔒 Datos Constantes por CUI)</span></h3>
                    <span style="font-size: 0.9rem; color: var(--text-muted);">
                        <strong>CUI Único:</strong> ${cui} | <strong>Fecha de Nacimiento:</strong> ${fechaNac} (${edadActual} años) | <strong>Sexo:</strong> ${sexoPac}
                    </span>
                </div>
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <span style="background: rgba(0, 91, 150, 0.1); color: var(--primary-blue); padding: 6px 12px; border-radius: 20px; font-weight: 600; font-size: 0.85rem;">
                        🚨 Veces en Triage: ${vecesTriage}
                    </span>
                    <span style="background: rgba(46, 125, 50, 0.12); color: #2e7d32; padding: 6px 12px; border-radius: 20px; font-weight: 600; font-size: 0.85rem;">
                        👨‍⚕️ Veces en Asignación Médica: ${vecesAsignacion}
                    </span>
                    <span style="background: rgba(239, 108, 0, 0.12); color: #ef6c00; padding: 6px 12px; border-radius: 20px; font-weight: 600; font-size: 0.85rem;">
                        🛏️ Veces en Gestión de Camas: ${vecesCamas}
                    </span>
                    <span style="background: #f0f4f8; color: var(--text-dark); padding: 6px 12px; border-radius: 20px; font-weight: 600; font-size: 0.85rem;">
                        📋 Total de Registros: ${registrosPaciente.length}
                    </span>
                </div>
            </div>
        </div>
    `;

    divContenedorHistorial.innerHTML = `<h3>Detalle de Ingresos Clínicos (${registrosPaciente.length}):</h3>`;

    if (registrosPaciente.length === 0) {
        divContenedorHistorial.innerHTML += `
            <p style="justify-content: center; color: var(--text-muted);">El paciente está registrado con su CUI constante, pero aún no tiene ingresos guardados en el historial.</p>
        `;
        return;
    }

    // Renderizar cada registro diferenciando Triage, Asignación Médica y Gestión de Camas
    registrosPaciente.forEach((reg, index) => {
        let colorModulo = "#005b96";
        let iconoModulo = "🚨 Ingreso en Triage";
        let etiquetaDetalle = "👨‍⚕️ <strong>Médicos Asignados:</strong>";
        let etiquetaArea = "🏥 Área Médica:";

        if (reg.modulo === "Asignación Médica") {
            colorModulo = "#2e7d32";
            iconoModulo = "👨‍⚕️ Asignación Médica";
        } else if (reg.modulo === "Gestión de Camas") {
            colorModulo = "#ef6c00";
            iconoModulo = "🛏️ Asignación de Cama (Gestión de Camas)";
            etiquetaDetalle = "🧭 <strong>Cama y Ruta de Ubicación (BFS):</strong>";
            etiquetaArea = "🏢 Sala y Área Asignada:";
        }

        const textoGravedad = reg.gravedad ? ` | ⚡ Gravedad: <strong>${reg.gravedad}/10</strong>` : "";
        const detalleSecundario = Array.isArray(reg.equipo) && reg.equipo.length > 0
            ? reg.equipo.join(' + ')
            : "Asignación estándar del área";

        divContenedorHistorial.innerHTML += `
            <p style="flex-direction: column; align-items: flex-start; gap: 6px; border-left: 4px solid ${colorModulo};">
                <span style="width: 100%; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <span style="color: ${colorModulo}; font-weight: 700; font-size: 1rem;">
                        ${iconoModulo} #${registrosPaciente.length - index}
                    </span>
                    <span style="font-size: 0.82rem; color: var(--text-muted); font-weight: 500;">
                        🕒 Fecha y hora de registro: ${reg.fechaHora}
                    </span>
                </span>
                <span style="font-size: 0.92rem; color: var(--text-dark);">
                    🩺 <strong>Enfermedad / Diagnóstico / Quebradura:</strong> ${reg.condicion} ${textoGravedad}
                </span>
                <span style="font-size: 0.92rem; color: var(--primary-blue); font-weight: 600;">
                    ${etiquetaArea} ${reg.area}
                </span>
                <span style="font-size: 0.88rem; color: var(--text-dark);">
                    ${etiquetaDetalle} ${detalleSecundario}
                </span>
                <span style="font-size: 0.82rem; color: var(--text-muted);">
                    Paciente: ${datosPersonales.nombre} (${edadActual} años) | CUI: ${cui} | Nacimiento: ${fechaNac} | Sexo: ${sexoPac}
                </span>
            </p>
        `;
    });
}

// 5. EVENTOS DE BOTONES Y TECLA ENTER
document.getElementById('btnBuscarHistorial').addEventListener('click', () => {
    buscarHistorialPorCui();
});

document.getElementById('btnLimpiarBusqueda').addEventListener('click', () => {
    inputBuscarCui.value = '';
    dropdownSugerencias.style.display = 'none';
    divFichaPaciente.style.display = 'none';
    divContenedorHistorial.innerHTML = `
        <h3>Registros Clínicos:</h3>
        <p style="justify-content: center; color: var(--text-muted);">Ingrese un número de CUI arriba para visualizar las veces que el paciente estuvo en Triage, Asignación Médica y Gestión de Camas.</p>
    `;
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const modal = document.getElementById('modalSistema');
        if (modal && modal.style.display === 'flex') {
            e.preventDefault();
            modal.style.display = 'none';
            return;
        }

        if (document.activeElement === inputBuscarCui || inputBuscarCui.value.trim() !== '') {
            e.preventDefault();
            buscarHistorialPorCui();
        }
    }
});