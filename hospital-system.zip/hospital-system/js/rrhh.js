// 1. VERIFICACIÓN DE SESIÓN ACTIVA (Solo Recursos Humanos)
const sesionActiva = JSON.parse(sessionStorage.getItem('sesionActiva_SM') || localStorage.getItem('sesionActiva_SM'));
if (!sesionActiva || sesionActiva.rol !== 'rrhh') {
    window.location.replace('login.html');
}

document.getElementById('btnCerrarSesionRRHH').addEventListener('click', () => {
    sessionStorage.removeItem('sesionActiva_SM');
    localStorage.removeItem('sesionActiva_SM');
});

function normalizarTexto(texto) {
    return (texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

// 2. DATOS BASE DEL HOSPITAL
const protocolosBase = {
    "Cirugía Plástica y Estética": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación preoperatoria, control reconstructivo y tratamientos estéticos.", requeridos: ["Cirujano Plástico"] },
    "Ginecología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Consulta, diagnóstico y control ginecológico general.", requeridos: ["Ginecólogo"], sexoPermitido: "Femenino" },
    "Pediatría": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Atención médica exclusiva para el desarrollo y salud infantil (menores de 18 años).", requeridos: ["Pediatra"], edadMax: 17 },
    "Neonatología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación especializada para recién nacidos y lactantes (0 a 1 año).", requeridos: ["Neonatólogo"], edadMax: 1 },
    "Traumatología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación y tratamiento conservador de lesiones óseas y musculares.", requeridos: ["Traumatólogo"] },
    "Dermatología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Diagnóstico y tratamiento directo de afecciones de la piel.", requeridos: ["Dermatólogo"] },
    "Cardiología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación clínica cardiovascular y control de presión arterial.", requeridos: ["Cardiólogo"] },
    "Neurología Clínica": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Consulta externa para migrañas, epilepsia y trastornos nerviosos.", requeridos: ["Neurólogo"] },
    "Neumología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Diagnóstico y tratamiento de enfermedades pulmonares y vías respiratorias.", requeridos: ["Neumólogo"] },
    "Gastroenterología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Consulta y tratamiento de enfermedades del sistema digestivo.", requeridos: ["Gastroenterólogo"] },
    "Nefrología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación de la función renal e hipertensión arterial secundaria.", requeridos: ["Nefrólogo"] },
    "Endocrinología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Control de diabetes, tiroides y trastornos hormonales o metabólicos.", requeridos: ["Endocrinólogo"] },
    "Urología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Atención general de afecciones del sistema urinario y vías renales.", requeridos: ["Urólogo"] },
    "Andrología y Control Prostático": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación urológica específica masculina y salud prostática (18+ años).", requeridos: ["Urólogo"], sexoPermitido: "Masculino", edadMin: 18 },
    "Oftalmología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación y tratamiento directo de salud visual y ocular.", requeridos: ["Oftalmólogo"] },
    "Otorrinolaringología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Diagnóstico y tratamiento de oído, nariz y garganta.", requeridos: ["Otorrinolaringólogo"] },
    "Reumatología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Tratamiento de artritis, enfermedades autoinmunes y dolor articular.", requeridos: ["Reumatólogo"] },
    "Hematología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Diagnóstico de anemias, trastornos de coagulación y enfermedades de la sangre.", requeridos: ["Hematólogo"] },
    "Infectología": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Manejo de infecciones complejas, virales, bacterianas o tropicales.", requeridos: ["Infectólogo"] },
    "Oncología Médica": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Valoración diagnóstica y seguimiento clínico de tumores y cáncer.", requeridos: ["Oncólogo"] },
    "Psiquiatría y Salud Mental": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación psiquiátrica, manejo farmacológico y salud emocional.", requeridos: ["Psiquiatra"] },
    "Medicina Interna": { categoria: "Consultas y Especialidades (1 Médico)", descripcion: "Evaluación clínica integral exclusiva para pacientes adultos (18+ años).", requeridos: ["Médico Internista"], edadMin: 18 },
    "Cirugía Plástica Ambulatoria": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Procedimientos reconstructivos o estéticos menores bajo sedación controlada.", requeridos: ["Cirujano Plástico", "Anestesiólogo"] },
    "Cirugía Dermatológica Reconstructiva": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Extirpación de lesiones cutáneas profundas con cierre estético reconstructivo.", requeridos: ["Cirujano Plástico", "Dermatólogo"] },
    "Anestesiología": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Evaluación conjunta de sedación, manejo del dolor agudo y monitoreo sistémico.", requeridos: ["Anestesiólogo", "Médico Internista"] },
    "Geriatría": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Atención especializada al adulto mayor (60+ años) y control de comorbilidades.", requeridos: ["Geriatra", "Médico Internista"], edadMin: 60 },
    "Neurología": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Evaluación hospitalaria del sistema nervioso central y monitoreo clínico interno.", requeridos: ["Neurólogo", "Médico Internista"] },
    "Cirugía Traumatológica": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Reducción quirúrgica de fracturas, artroscopías y sedación especializada.", requeridos: ["Traumatólogo", "Anestesiólogo"] },
    "Endoscopía Digestiva": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Procedimiento diagnóstico y terapéutico digestivo bajo sedación.", requeridos: ["Gastroenterólogo", "Anestesiólogo"] },
    "Broncoscopía Respiratoria": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Exploración invasiva de vías aéreas y pulmones bajo sedación.", requeridos: ["Neumólogo", "Anestesiólogo"] },
    "Hemodiálisis y Soporte Renal": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Terapia de reemplazo renal con monitoreo hemodinámico interno.", requeridos: ["Nefrólogo", "Médico Internista"] },
    "Quimioterapia y Control Oncológico": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Administración de tratamiento antineoplásico y estabilización sistémica.", requeridos: ["Oncólogo", "Médico Internista"] },
    "Urgencia Cardiológica": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Estabilización hemodinámica urgente de arritmias o dolor torácico.", requeridos: ["Cardiólogo", "Médico Internista"] },
    "Cirugía Oftalmológica": { categoria: "Atención Conjunta e Intervenciones (2 Médicos)", descripcion: "Microcirugía ocular (cataratas, retina o córnea) con bloqueo anestésico.", requeridos: ["Oftalmólogo", "Anestesiólogo"] },
    "Unidad de Quemados y Cirugía Reconstructiva": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Reconstrucción de tejidos por quemaduras severas, injertos, analgesia y soporte vital.", requeridos: ["Cirujano Plástico", "Anestesiólogo", "Médico Internista"] },
    "Reconstrucción Maxilofacial y Traumática": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Cirugía combinada para fracturas graves, reconstrucción ósea y de tejidos blandos.", requeridos: ["Cirujano Plástico", "Traumatólogo", "Anestesiólogo"] },
    "Cirugía Reconstructiva Pediátrica": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Corrección quirúrgica de malformaciones congénitas (ej. labio leporino) en menores.", requeridos: ["Cirujano Plástico", "Pediatra", "Anestesiólogo"], edadMax: 17 },
    "Maternidad y Obstetricia": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Atención integral para labor de parto, cesárea y recepción del recién nacido.", requeridos: ["Ginecólogo", "Pediatra", "Anestesiólogo"], sexoPermitido: "Femenino", edadMin: 12, edadMax: 60 },
    "Parto de Alto Riesgo Neonatal": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Intervención obstétrica compleja con soporte intensivo para prematuros.", requeridos: ["Ginecólogo", "Neonatólogo", "Anestesiólogo"], sexoPermitido: "Femenino", edadMin: 12, edadMax: 60 },
    "Cirugía General": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Equipo quirúrgico completo con soporte anestésico y control metabólico.", requeridos: ["Cirujano General", "Anestesiólogo", "Médico Internista"] },
    "Cirugía Oncológica": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Resección quirúrgica de tumores complejos con estadificación oncológica en quirófano.", requeridos: ["Cirujano General", "Oncólogo", "Anestesiólogo"] },
    "Cirugía Cardiovascular": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Intervención quirúrgica de corazón o grandes vasos con monitoreo cardiológico.", requeridos: ["Cirujano Cardiovascular", "Cardiólogo", "Anestesiólogo"] },
    "Neurocirugía": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Cirugía craneal o de columna vertebral con monitoreo neurofisiológico.", requeridos: ["Neurocirujano", "Neurólogo", "Anestesiólogo"] },
    "Cuidados Intensivos": { categoria: "Unidades Complejas y Quirófano (3 Médicos)", descripcion: "Soporte vital avanzado multidisciplinario para pacientes en estado crítico.", requeridos: ["Intensivista", "Médico Internista", "Anestesiólogo"] }
};

const medicosBase = [
    { id: 1, nombre: "Dr. Alejandro Valladares", especialidad: "Cirujano Plástico", areaAsignada: "Cirugía Plástica y Estética", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 2, nombre: "Dra. Renata Mendizábal", especialidad: "Cirujano Plástico", areaAsignada: "Unidad de Quemados y Cirugía Reconstructiva", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 3, nombre: "Dr. Cristian Wyld", especialidad: "Cirujano Plástico", areaAsignada: "Reconstrucción Maxilofacial y Traumática", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 4, nombre: "Dra. Isabella Toriello", especialidad: "Cirujano Plástico", areaAsignada: "Cirugía Plástica Ambulatoria", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 5, nombre: "Dra. Patricia Castellanos", especialidad: "Ginecólogo", areaAsignada: "Ginecología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 6, nombre: "Dr. Alejandro Solares", especialidad: "Ginecólogo", areaAsignada: "Maternidad y Obstetricia", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 7, nombre: "Dra. Gabriela Marroquín", especialidad: "Ginecólogo", areaAsignada: "Parto de Alto Riesgo Neonatal", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 8, nombre: "Dra. Regina Morales", especialidad: "Ginecólogo", areaAsignada: "Ginecología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 9, nombre: "Dra. Natalia Gálvez", especialidad: "Pediatra", areaAsignada: "Pediatría", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 10, nombre: "Dr. Hugo Samayoa", especialidad: "Pediatra", areaAsignada: "Pediatría", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 11, nombre: "Dra. Valeria Fuentes", especialidad: "Pediatra", areaAsignada: "Maternidad y Obstetricia", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 12, nombre: "Dr. Daniel Orellana", especialidad: "Pediatra", areaAsignada: "Cirugía Reconstructiva Pediátrica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 13, nombre: "Dra. Mariana Batres", especialidad: "Neonatólogo", areaAsignada: "Neonatología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 14, nombre: "Dr. Ernesto Zelaya", especialidad: "Neonatólogo", areaAsignada: "Parto de Alto Riesgo Neonatal", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 15, nombre: "Dra. Rocío Argueta", especialidad: "Neonatólogo", areaAsignada: "Neonatología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 16, nombre: "Dr. Carlos Mendoza", especialidad: "Anestesiólogo", areaAsignada: "Anestesiología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 17, nombre: "Dra. Elena Rostova", especialidad: "Anestesiólogo", areaAsignada: "Cirugía General", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 18, nombre: "Dr. Mario Villatoro", especialidad: "Anestesiólogo", areaAsignada: "Cirugía Traumatológica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 19, nombre: "Dra. Lucía Paredes", especialidad: "Anestesiólogo", areaAsignada: "Maternidad y Obstetricia", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 20, nombre: "Dr. Jorge Echeverría", especialidad: "Anestesiólogo", areaAsignada: "Cuidados Intensivos", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 21, nombre: "Dra. Jimena Peralta", especialidad: "Anestesiólogo", areaAsignada: "Neurocirugía", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 22, nombre: "Dr. Roberto Chang", especialidad: "Médico Internista", areaAsignada: "Medicina Interna", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 23, nombre: "Dra. Sofía Valenzuela", especialidad: "Médico Internista", areaAsignada: "Urgencia Cardiológica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 24, nombre: "Dr. Fernando Galindo", especialidad: "Médico Internista", areaAsignada: "Geriatría", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 25, nombre: "Dra. Claudia Morales", especialidad: "Médico Internista", areaAsignada: "Cuidados Intensivos", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 26, nombre: "Dr. Javier Santizo", especialidad: "Médico Internista", areaAsignada: "Hemodiálisis y Soporte Renal", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 27, nombre: "Dra. Paola Méndez", especialidad: "Médico Internista", areaAsignada: "Quimioterapia y Control Oncológico", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 28, nombre: "Dr. Héctor Cifuentes", especialidad: "Traumatólogo", areaAsignada: "Traumatología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 29, nombre: "Dr. Rodrigo Pineda", especialidad: "Traumatólogo", areaAsignada: "Cirugía Traumatológica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 30, nombre: "Dra. Mónica Estrada", especialidad: "Traumatólogo", areaAsignada: "Traumatología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 31, nombre: "Dr. Sebastián Paz", especialidad: "Traumatólogo", areaAsignada: "Reconstrucción Maxilofacial y Traumática", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 32, nombre: "Dra. Andrea Monterroso", especialidad: "Dermatólogo", areaAsignada: "Dermatología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 33, nombre: "Dr. Pablo Girón", especialidad: "Dermatólogo", areaAsignada: "Cirugía Dermatológica Reconstructiva", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 34, nombre: "Dra. Camila Salazar", especialidad: "Dermatólogo", areaAsignada: "Dermatología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 35, nombre: "Dr. Julio Cabrera", especialidad: "Geriatra", areaAsignada: "Geriatría", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 36, nombre: "Dra. Carmen Godoy", especialidad: "Geriatra", areaAsignada: "Geriatría", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 37, nombre: "Dr. Emilio Tello", especialidad: "Geriatra", areaAsignada: "Geriatría", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 38, nombre: "Dr. Adrián Monzón", especialidad: "Cardiólogo", areaAsignada: "Cardiología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 39, nombre: "Dra. Silvia Pellecer", especialidad: "Cardiólogo", areaAsignada: "Urgencia Cardiológica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 40, nombre: "Dr. Marco Tulio Barrios", especialidad: "Cardiólogo", areaAsignada: "Cirugía Cardiovascular", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 41, nombre: "Dr. Federico Novales", especialidad: "Cirujano Cardiovascular", areaAsignada: "Cirugía Cardiovascular", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 42, nombre: "Dra. Viviana Saravia", especialidad: "Cirujano Cardiovascular", areaAsignada: "Cirugía Cardiovascular", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 43, nombre: "Dr. Esteban Coronado", especialidad: "Neurólogo", areaAsignada: "Neurología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 44, nombre: "Dra. Diana Recinos", especialidad: "Neurólogo", areaAsignada: "Neurología Clínica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 45, nombre: "Dr. César Batres", especialidad: "Neurólogo", areaAsignada: "Neurocirugía", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 46, nombre: "Dr. Leonardo Aycinena", especialidad: "Neurocirujano", areaAsignada: "Neurocirugía", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 47, nombre: "Dra. Rebeca Urruela", especialidad: "Neurocirujano", areaAsignada: "Neurocirugía", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 48, nombre: "Dr. Gonzalo Illescas", especialidad: "Neumólogo", areaAsignada: "Neumología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 49, nombre: "Dra. Adriana Rodas", especialidad: "Neumólogo", areaAsignada: "Broncoscopía Respiratoria", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 50, nombre: "Dr. Benjamín Alcázar", especialidad: "Neumólogo", areaAsignada: "Neumología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 51, nombre: "Dr. Mauricio Rosales", especialidad: "Gastroenterólogo", areaAsignada: "Gastroenterología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 52, nombre: "Dra. Karina Polanco", especialidad: "Gastroenterólogo", areaAsignada: "Endoscopía Digestiva", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 53, nombre: "Dr. Tomás Velásquez", especialidad: "Gastroenterólogo", areaAsignada: "Gastroenterología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 54, nombre: "Dr. Salvador Gándara", especialidad: "Nefrólogo", areaAsignada: "Nefrología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 55, nombre: "Dra. Olga Villagrán", especialidad: "Nefrólogo", areaAsignada: "Hemodiálisis y Soporte Renal", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 56, nombre: "Dr. Luis Pedro Mencos", especialidad: "Nefrólogo", areaAsignada: "Nefrología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 57, nombre: "Dra. Estefanía Klee", especialidad: "Endocrinólogo", areaAsignada: "Endocrinología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 58, nombre: "Dr. Juan Pablo Lehnhoff", especialidad: "Endocrinólogo", areaAsignada: "Endocrinología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 59, nombre: "Dr. Ramiro Asturias", especialidad: "Urólogo", areaAsignada: "Urología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 60, nombre: "Dr. Gustavo Ovalle", especialidad: "Urólogo", areaAsignada: "Andrología y Control Prostático", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 61, nombre: "Dra. Verónica Cordón", especialidad: "Urólogo", areaAsignada: "Urología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 62, nombre: "Dr. Sergio Arzú", especialidad: "Oftalmólogo", areaAsignada: "Oftalmología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 63, nombre: "Dra. Laura Melgar", especialidad: "Oftalmólogo", areaAsignada: "Cirugía Oftalmológica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 64, nombre: "Dr. Andrés Sinibaldi", especialidad: "Oftalmólogo", areaAsignada: "Oftalmología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 65, nombre: "Dr. Álvaro Dardón", especialidad: "Otorrinolaringólogo", areaAsignada: "Otorrinolaringología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 66, nombre: "Dra. Lorena Chinchilla", especialidad: "Otorrinolaringólogo", areaAsignada: "Otorrinolaringología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 67, nombre: "Dra. Marta Beltranena", especialidad: "Reumatólogo", areaAsignada: "Reumatología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 68, nombre: "Dr. Óscar Berger-Pemueller", especialidad: "Reumatólogo", areaAsignada: "Reumatología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 69, nombre: "Dr. David Monterroso", especialidad: "Hematólogo", areaAsignada: "Hematología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 70, nombre: "Dra. Leticia Sagastume", especialidad: "Hematólogo", areaAsignada: "Hematología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 71, nombre: "Dr. Carlos Mejía Villatoro", especialidad: "Infectólogo", areaAsignada: "Infectología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 72, nombre: "Dra. Iris Cazali", especialidad: "Infectólogo", areaAsignada: "Infectología", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 73, nombre: "Dr. Enrique Maegli", especialidad: "Oncólogo", areaAsignada: "Oncología Médica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 74, nombre: "Dra. Fabiola Berganza", especialidad: "Oncólogo", areaAsignada: "Quimioterapia y Control Oncológico", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 75, nombre: "Dr. Ricardo Bressani", especialidad: "Oncólogo", areaAsignada: "Cirugía Oncológica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 76, nombre: "Dra. Susana Neutze", especialidad: "Psiquiatra", areaAsignada: "Psiquiatría y Salud Mental", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 77, nombre: "Dr. Mateo Zirión", especialidad: "Psiquiatra", areaAsignada: "Psiquiatría y Salud Mental", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 78, nombre: "Dr. Arturo Lemus", especialidad: "Cirujano General", areaAsignada: "Cirugía General", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 79, nombre: "Dra. Beatriz Barrios", especialidad: "Cirujano General", areaAsignada: "Cirugía General", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 80, nombre: "Dr. Óscar Taracena", especialidad: "Cirujano General", areaAsignada: "Cirugía Oncológica", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 81, nombre: "Dra. Carla Aldana", especialidad: "Cirujano General", areaAsignada: "Cirugía General", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 82, nombre: "Dr. Víctor Portillo", especialidad: "Intensivista", areaAsignada: "Cuidados Intensivos", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 83, nombre: "Dra. Teresa Lima", especialidad: "Intensivista", areaAsignada: "Cuidados Intensivos", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" },
    { id: 84, nombre: "Dr. Nicolás Mérida", especialidad: "Intensivista", areaAsignada: "Cuidados Intensivos", disponible: true, guardia: 0, estadoLaboral: "Activo", detalleDescanso: "Turno normal" }
];

const catalogoClinicoBase = {
    "Quebradura de Cráneo / Traumatismo Craneoencefálico": { categoria: "Quebraduras y Traumatismos", gravedad: 10, areas: ["Neurocirugía", "Cuidados Intensivos", "Neurología"] },
    "Quebradura Expuesta de Fémur": { categoria: "Quebraduras y Traumatismos", gravedad: 9, areas: ["Cirugía Traumatológica", "Cuidados Intensivos", "Traumatología"] },
    "Quebradura de Cadera": { categoria: "Quebraduras y Traumatismos", gravedad: 8, areas: ["Cirugía Traumatológica", "Traumatología", "Geriatría"] },
    "Quebradura de Costillas con Trauma Torácico": { categoria: "Quebraduras y Traumatismos", gravedad: 8, areas: ["Cirugía Traumatológica", "Cuidados Intensivos", "Neumología"] },
    "Quebradura de Tibia y Peroné": { categoria: "Quebraduras y Traumatismos", gravedad: 7, areas: ["Cirugía Traumatológica", "Traumatología"] },
    "Quebradura Nasal y Maxilofacial": { categoria: "Quebraduras y Traumatismos", gravedad: 7, areas: ["Reconstrucción Maxilofacial y Traumática", "Cirugía Plástica Ambulatoria", "Otorrinolaringología"] },
    "Quebradura de Radio y Cúbito (Antebrazo)": { categoria: "Quebraduras y Traumatismos", gravedad: 6, areas: ["Traumatología", "Cirugía Traumatológica", "Pediatría"] },
    "Quebradura de Clavícula o Hombro": { categoria: "Quebraduras y Traumatismos", gravedad: 5, areas: ["Traumatología", "Cirugía Traumatológica", "Pediatría"] },
    "Quebradura de Tobillo o Pie": { categoria: "Quebraduras y Traumatismos", gravedad: 5, areas: ["Traumatología", "Cirugía Traumatológica"] },
    "Quebradura de Mano, Muñeca o Dedos": { categoria: "Quebraduras y Traumatismos", gravedad: 4, areas: ["Traumatología", "Cirugía Plástica Ambulatoria"] },
    "Luxación Articular / Esguince Grado III": { categoria: "Quebraduras y Traumatismos", gravedad: 4, areas: ["Traumatología"] },
    "Infarto Agudo de Miocardio (Ataque Cardíaco)": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Urgencia Cardiológica", "Cirugía Cardiovascular", "Cuidados Intensivos"] },
    "Accidente Cerebrovascular (ACV / Derrame Cerebral)": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Neurocirugía", "Neurología", "Cuidados Intensivos"] },
    "Paro Cardiorrespiratorio / Choque Séptico": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Cuidados Intensivos", "Urgencia Cardiológica"] },
    "Quemaduras Severas de Segundo y Tercer Grado": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Unidad de Quemados y Cirugía Reconstructiva", "Cuidados Intensivos"] },
    "Aneurisma Cerebral / Tumor Intracraneal": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Neurocirugía", "Neurología", "Oncología Médica"] },
    "Apendicitis Aguda / Peritonitis": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Cirugía General", "Pediatría"] },
    "Insuficiencia Respiratoria Aguda / Neumonía Severa": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Cuidados Intensivos", "Neumología", "Medicina Interna"] },
    "Preeclampsia Severa / Embarazo Ectópico Roto": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Parto de Alto Riesgo Neonatal", "Maternidad y Obstetricia", "Cuidados Intensivos"], sexoPermitido: "Femenino" },
    "Síndrome de Distrés Respiratorio Neonatal / Prematurez": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Neonatología", "Parto de Alto Riesgo Neonatal"] },
    "Labor de Parto Activo / Cesárea": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Maternidad y Obstetricia", "Parto de Alto Riesgo Neonatal"], sexoPermitido: "Femenino" },
    "Valvulopatía Cardíaca / Enfermedad Arterial Coronaria": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cirugía Cardiovascular", "Cardiología", "Urgencia Cardiológica"] },
    "Insuficiencia Cardíaca Congestiva": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cardiología", "Urgencia Cardiológica", "Geriatría", "Medicina Interna"] },
    "Hemorragia Digestiva / Úlcera Péptica Perforada": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Endoscopía Digestiva", "Gastroenterología", "Cirugía General"] },
    "Insuficiencia Renal Crónica / Crisis Urémica": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Hemodiálisis y Soporte Renal", "Nefrología", "Medicina Interna"] },
    "Diabetes Descompensada / Cetoacidosis Diabética": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Endocrinología", "Medicina Interna", "Cuidados Intensivos"] },
    "Obstrucción de Vías Aéreas / Broncoaspiración": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Broncoscopía Respiratoria", "Neumología", "Pediatría"] },
    "Tumor Maligno Sólido / Neoplasia Oncológica": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cirugía Oncológica", "Quimioterapia y Control Oncológico", "Oncología Médica"] },
    "Sepsis / Infección Sistémica Aguda (Dengue Grave)": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Infectología", "Cuidados Intensivos", "Medicina Interna"] },
    "Arritmia Cardíaca / Fibrilación Auricular": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cardiología", "Urgencia Cardiológica", "Medicina Interna"] },
    "Epilepsia y Crisis Convulsivas": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Neurología", "Neurología Clínica", "Pediatría"] },
    "Colecistitis Aguda / Cálculos en la Vesícula": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cirugía General", "Gastroenterología"] },
    "Carcinoma Cutáneo / Melanoma": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cirugía Dermatológica Reconstructiva", "Dermatología", "Oncología Médica"] },
    "Anemia Severa / Leucemia / Hemofilia": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Hematología", "Oncología Médica", "Quimioterapia y Control Oncológico"] },
    "Hipertensión Arterial Descontrolada": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Cardiología", "Medicina Interna", "Nefrología", "Geriatría"] },
    "Asma Bronquial / Crisis Asmática": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Neumología", "Pediatría"] },
    "Enfermedad Pulmonar Obstructiva Crónica (EPOC)": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Neumología", "Geriatría", "Medicina Interna"] },
    "Hepatitis Viral / Cirrosis Hepática": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Gastroenterología", "Infectología", "Medicina Interna"] },
    "Cálculos Renales (Litiasis / Cólico Nefrítico)": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Urología", "Nefrología"] },
    "Gastroenteritis Aguda y Deshidratación": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Pediatría", "Gastroenterología", "Medicina Interna"] },
    "Hernia Inguinal, Umbilical o Hiatal": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía General", "Gastroenterología"] },
    "Labio Leporino / Malformación Congénita": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía Reconstructiva Pediátrica", "Cirugía Plástica y Estética", "Pediatría"] },
    "Cataratas, Glaucoma o Desprendimiento de Retina": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía Oftalmológica", "Oftalmología"] },
    "Trastorno Depresivo Mayor / Crisis de Ansiedad": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Psiquiatría y Salud Mental"] },
    "Dolor Agudo Postoperatorio / Sedación": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Anestesiología"] },
    "Enfermedad de Parkinson / Demencia Senil / Alzheimer": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Geriatría", "Neurología Clínica", "Neurología"] },
    "Quiste Ovárico / Miomatosis Uterina / Endometriosis": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Ginecología"], sexoPermitido: "Femenino" },
    "Hiperplasia Prostática Benigna / Prostatitis": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Andrología y Control Prostático", "Urología"], sexoPermitido: "Masculino" },
    "Artritis Reumatoide / Lupus / Fibromialgia": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Reumatología", "Medicina Interna", "Geriatría"] },
    "Cicatriz Queloide / Reconstrucción Estética Corporal": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Cirugía Plástica y Estética", "Cirugía Plástica Ambulatoria"] },
    "Gastritis Crónica, Colitis y Reflujo Gastroesofágico": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Gastroenterología", "Medicina Interna"] },
    "Hipotiroidismo / Hipertiroidismo / Nódulo Tiroideo": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Endocrinología", "Medicina Interna"] },
    "Infección del Tracto Urinario (Cistitis)": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Urología", "Ginecología", "Medicina Interna"] },
    "Otitis Media, Sinusitis, Rinitis o Amigdalitis": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Otorrinolaringología", "Pediatría"] },
    "Migraña y Cefalea Tensional": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Neurología Clínica", "Medicina Interna"] },
    "Dermatitis, Psoriasis, Rosácea o Acné Severo": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Dermatología"] },
    "Conjuntivitis, Miopía o Astigmatismo": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Oftalmología"] },
    "Control Ginecológico Anual": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Ginecología"], sexoPermitido: "Femenino" },
    "Angiografía Coronaria y Cateterismo Diagnóstico": { categoria: "Diagnósticos y Estudios", gravedad: 7, areas: ["Urgencia Cardiológica", "Cirugía Cardiovascular", "Cardiología"] },
    "Tomografía Computarizada (TAC) Multicorte": { categoria: "Diagnósticos y Estudios", gravedad: 6, areas: ["Neurología", "Neurocirugía", "Cirugía General", "Neumología", "Oncología Médica", "Traumatología"] },
    "Biopsia Tumoral y Marcadores Oncológicos": { categoria: "Diagnósticos y Estudios", gravedad: 6, areas: ["Oncología Médica", "Cirugía Oncológica", "Quimioterapia y Control Oncológico"] },
    "Electrocardiograma (ECG) y Ecocardiograma Doppler": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Cardiología", "Urgencia Cardiológica", "Cirugía Cardiovascular", "Medicina Interna"] },
    "Resonancia Magnética (RMN) Cerebral y Articular": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Neurología", "Neurología Clínica", "Neurocirugía", "Traumatología", "Cirugía Traumatológica"] },
    "Endoscopía Digestiva Alta y Colonoscopía Diagnóstica": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Endoscopía Digestiva", "Gastroenterología"] },
    "Broncoscopía Diagnóstica y Espirometría Pulmonar": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Broncoscopía Respiratoria", "Neumología"] },
    "Radiografía Digital (Rayos X) Ósea y Torácica": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Traumatología", "Cirugía Traumatológica", "Neumología", "Pediatría", "Reconstrucción Maxilofacial y Traumática"] },
    "Electroencefalograma (EEG) y Potenciales Evocados": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Neurología Clínica", "Neurología", "Pediatría"] },
    "Ultrasonido Obstétrico 4D y Monitoreo Fetal Doppler": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Ginecología", "Maternidad y Obstetricia", "Parto de Alto Riesgo Neonatal"], sexoPermitido: "Femenino" },
    "Tamiz Neonatal y Ecografía Transfontanelar": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Neonatología", "Pediatría"] },
    "Evaluación Preanestésica y Riesgo Quirúrgico (ASA)": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Anestesiología", "Cirugía Plástica Ambulatoria", "Cirugía General"] },
    "Prueba de Esfuerzo Cardiovascular (Ergometría)": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Cardiología"] },
    "Biopsia Cutánea y Dermatoscopía Digital": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Dermatología", "Cirugía Dermatológica Reconstructiva", "Cirugía Plástica y Estética"] },
    "Perfil Renal, Ecografía Vesical y Urodinamia": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Nefrología", "Urología", "Hemodiálisis y Soporte Renal"] },
    "Antígeno Prostático Específico (PSA) y Ultrasonido": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Andrología y Control Prostático", "Urología"], sexoPermitido: "Masculino" },
    "Biometría Hemática, Coagulograma y Panel Infeccioso": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Hematología", "Infectología", "Medicina Interna"] },
    "Perfil Tiroideo y Hemoglobina Glicosilada": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Endocrinología", "Medicina Interna"] },
    "Evaluación Psicométrica y Diagnóstico Psiquiátrico": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Psiquiatría y Salud Mental"] },
    "Mamografía Digital y Papanicolaou": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Ginecología", "Oncología Médica"], sexoPermitido: "Femenino" },
    "Fondo de Ojo, Campimetría y Tonometría Ocular": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Oftalmología", "Cirugía Oftalmológica"] },
    "Audiometría Tonal y Nasofibrolaringoscopía": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Otorrinolaringología"] },
    "Densitometría Ósea y Perfil Reumatológico": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Reumatología", "Geriatría", "Traumatología"] }
};

const salasBase = {
    "Urgencia Cardiológica": { sala: "Sala 1 Piso 1", numSala: 1, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 4 },
    "Cuidados Intensivos": { sala: "Sala 2 Piso 1", numSala: 2, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 4 },
    "Traumatología": { sala: "Sala 3 Piso 1", numSala: 3, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 4 },
    "Cirugía Traumatológica": { sala: "Sala 4 Piso 1", numSala: 4, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 3 },
    "Unidad de Quemados y Cirugía Reconstructiva": { sala: "Sala 5 Piso 1", numSala: 5, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 3 },
    "Reconstrucción Maxilofacial y Traumática": { sala: "Sala 6 Piso 1", numSala: 6, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 3 },
    "Cirugía General": { sala: "Sala 7 Piso 1", numSala: 7, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 4 },
    "Cirugía Cardiovascular": { sala: "Sala 8 Piso 1", numSala: 8, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 3 },
    "Neurocirugía": { sala: "Sala 9 Piso 1", numSala: 9, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 3 },
    "Anestesiología": { sala: "Sala 10 Piso 1", numSala: 10, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 3 },
    "Maternidad y Obstetricia": { sala: "Sala 11 Piso 1", numSala: 11, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 4, sexoPermitido: "Femenino", edadMin: 12, edadMax: 60 },
    "Parto de Alto Riesgo Neonatal": { sala: "Sala 12 Piso 1", numSala: 12, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 3, sexoPermitido: "Femenino", edadMin: 12, edadMax: 60 },
    "Neonatología": { sala: "Sala 13 Piso 1", numSala: 13, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 4, edadMax: 1 },
    "Pediatría": { sala: "Sala 14 Piso 1", numSala: 14, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 4, edadMax: 17 },
    "Cirugía Reconstructiva Pediátrica": { sala: "Sala 15 Piso 1", numSala: 15, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 3, edadMax: 17 },
    "Ginecología": { sala: "Sala 16 Piso 1", numSala: 16, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 4, sexoPermitido: "Femenino" },
    "Broncoscopía Respiratoria": { sala: "Sala 17 Piso 1", numSala: 17, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 3 },
    "Neumología": { sala: "Sala 18 Piso 1", numSala: 18, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 4 },
    "Endoscopía Digestiva": { sala: "Sala 19 Piso 1", numSala: 19, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 3 },
    "Hemodiálisis y Soporte Renal": { sala: "Sala 20 Piso 1", numSala: 20, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 4 },
    "Neurología": { sala: "Sala 21 Piso 1", numSala: 21, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 3 },
    "Medicina Interna": { sala: "Sala 22 Piso 1", numSala: 22, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 4, edadMin: 18 },
    "Cardiología": { sala: "Sala 1 Piso 2", numSala: 1, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 4 },
    "Neurología Clínica": { sala: "Sala 2 Piso 2", numSala: 2, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 3 },
    "Gastroenterología": { sala: "Sala 3 Piso 2", numSala: 3, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 4 },
    "Nefrología": { sala: "Sala 4 Piso 2", numSala: 4, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 3 },
    "Endocrinología": { sala: "Sala 5 Piso 2", numSala: 5, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 3 },
    "Geriatría": { sala: "Sala 6 Piso 2", numSala: 6, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 4, edadMin: 60 },
    "Cirugía Plástica y Estética": { sala: "Sala 7 Piso 2", numSala: 7, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 3 },
    "Cirugía Plástica Ambulatoria": { sala: "Sala 8 Piso 2", numSala: 8, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 3 },
    "Cirugía Dermatológica Reconstructiva": { sala: "Sala 9 Piso 2", numSala: 9, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 3 },
    "Dermatología": { sala: "Sala 10 Piso 2", numSala: 10, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 3 },
    "Cirugía Oncológica": { sala: "Sala 11 Piso 2", numSala: 11, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 3 },
    "Quimioterapia y Control Oncológico": { sala: "Sala 12 Piso 2", numSala: 12, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 4 },
    "Oncología Médica": { sala: "Sala 13 Piso 2", numSala: 13, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 3 },
    "Hematología": { sala: "Sala 14 Piso 2", numSala: 14, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 3 },
    "Infectología": { sala: "Sala 15 Piso 2", numSala: 15, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 3 },
    "Urología": { sala: "Sala 16 Piso 2", numSala: 16, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Andrología y Control Prostático": { sala: "Sala 17 Piso 2", numSala: 17, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3, sexoPermitido: "Masculino", edadMin: 18 },
    "Oftalmología": { sala: "Sala 18 Piso 2", numSala: 18, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Cirugía Oftalmológica": { sala: "Sala 19 Piso 2", numSala: 19, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Otorrinolaringología": { sala: "Sala 20 Piso 2", numSala: 20, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Reumatología": { sala: "Sala 21 Piso 2", numSala: 21, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Psiquiatría y Salud Mental": { sala: "Sala 22 Piso 2", numSala: 22, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 }
};

function obtenerMedicosRRHH() {
    const guardados = JSON.parse(localStorage.getItem('medicosRRHH_SM'));
    if (!guardados) {
        localStorage.setItem('medicosRRHH_SM', JSON.stringify(medicosBase));
        return medicosBase;
    }
    return guardados;
}

function guardarMedicosRRHH(lista) {
    localStorage.setItem('medicosRRHH_SM', JSON.stringify(lista));
}

function obtenerProtocolosRRHH() {
    const guardados = JSON.parse(localStorage.getItem('protocolosRRHH_SM'));
    if (!guardados) {
        localStorage.setItem('protocolosRRHH_SM', JSON.stringify(protocolosBase));
        return protocolosBase;
    }
    return guardados;
}

function guardarProtocolosRRHH(obj) {
    localStorage.setItem('protocolosRRHH_SM', JSON.stringify(obj));
}

function obtenerEnfermedadesRRHH() {
    const guardadas = JSON.parse(localStorage.getItem('catalogoClinicoRRHH_SM'));
    if (!guardadas) {
        localStorage.setItem('catalogoClinicoRRHH_SM', JSON.stringify(catalogoClinicoBase));
        return catalogoClinicoBase;
    }
    return { ...catalogoClinicoBase, ...guardadas };
}

function guardarEnfermedadesRRHH(obj) {
    localStorage.setItem('catalogoClinicoRRHH_SM', JSON.stringify(obj));
}

function obtenerSalasRRHH() {
    const guardadas = JSON.parse(localStorage.getItem('salasRRHH_SM'));
    if (!guardadas) {
        localStorage.setItem('salasRRHH_SM', JSON.stringify(salasBase));
        return salasBase;
    }
    return guardadas;
}

function guardarSalasRRHH(obj) {
    localStorage.setItem('salasRRHH_SM', JSON.stringify(obj));
}

function mostrarAlerta(mensaje, titulo = "Recursos Humanos") {
    const modal = document.getElementById('modalSistema');
    document.getElementById('modalTitulo').textContent = titulo;
    document.getElementById('modalTexto').textContent = mensaje;
    modal.style.display = 'flex';
}

document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

// Cerrar cualquier dropdown al hacer clic fuera
document.addEventListener('click', (e) => {
    if (!e.target.closest('.buscador-area-container')) {
        document.querySelectorAll('.dropdown-areas').forEach(d => d.style.display = 'none');
    }
});

// 3. NAVEGACIÓN ENTRE PESTAÑAS DE RECURSOS HUMANOS
document.querySelectorAll('.rrhh-nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('data-target');
        document.querySelectorAll('.rrhh-nav-link').forEach(l => l.classList.remove('active'));
        link.classList.add('active');

        document.querySelectorAll('.rrhh-section').forEach(sec => {
            sec.style.display = sec.id === targetId ? 'block' : 'none';
        });
    });
});

// =========================================================================
// 4. SECCIÓN 1: GESTIÓN DE MÉDICOS (Con buscadores de Especialidad, Área y Plantilla)
// =========================================================================
const inputMedicoNombre = document.getElementById('nuevoMedicoNombre');
const inputMedicoEsp = document.getElementById('nuevoMedicoEspecialidad');
const dropdownEspRRHH = document.getElementById('dropdownEspecialidadRRHH');

const inputBuscadorAreaMed = document.getElementById('buscadorAreaMedicoRRHH');
const inputHiddenAreaMed = document.getElementById('nuevoMedicoArea');
const dropdownAreaMedRRHH = document.getElementById('dropdownAreaMedicoRRHH');

const inputFiltroMedicos = document.getElementById('filtroTablaMedicos');

// A. Buscador interactivo de Especialidad
function renderizarDropdownEspecialidades(filtro = "") {
    const medicos = obtenerMedicosRRHH();
    const especialidades = [...new Set(medicos.map(m => m.especialidad))].sort();
    const filtroNorm = normalizarTexto(filtro);

    dropdownEspRRHH.innerHTML = "";
    let coincidencias = 0;

    especialidades.forEach(esp => {
        if (normalizarTexto(esp).includes(filtroNorm)) {
            coincidencias++;
            const cant = medicos.filter(m => m.especialidad === esp).length;
            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">${esp}</span>
                <span class="dropdown-item-sub">👨‍⚕️ ${cant} especialista(s) en plantilla</span>
            `;
            item.addEventListener('click', () => {
                inputMedicoEsp.value = esp;
                dropdownEspRRHH.style.display = 'none';
            });
            dropdownEspRRHH.appendChild(item);
        }
    });

    if (coincidencias === 0 && filtro.trim() !== "") {
        dropdownEspRRHH.innerHTML = `<div class="dropdown-vacio">➕ Se registrará "${filtro.trim()}" como nueva especialidad médica.</div>`;
    }
}

inputMedicoEsp.addEventListener('focus', () => {
    dropdownAreaMedRRHH.style.display = 'none';
    renderizarDropdownEspecialidades(inputMedicoEsp.value);
    dropdownEspRRHH.style.display = 'block';
});

inputMedicoEsp.addEventListener('input', function() {
    renderizarDropdownEspecialidades(this.value);
    dropdownEspRRHH.style.display = 'block';
});

// B. Buscador interactivo de Área Médica para el nuevo médico
function renderizarDropdownAreaMedico(filtro = "") {
    const protocolos = obtenerProtocolosRRHH();
    const salas = obtenerSalasRRHH();
    const filtroNorm = normalizarTexto(filtro);

    dropdownAreaMedRRHH.innerHTML = "";
    let coincidencias = 0;

    Object.entries(protocolos).forEach(([nombreArea, datos]) => {
        const salaTxt = salas[nombreArea]?.sala || "Sala asignada";
        const textoBusqueda = normalizarTexto(`${nombreArea} ${salaTxt} ${datos.requeridos.join(" ")}`);

        if (textoBusqueda.includes(filtroNorm)) {
            coincidencias++;
            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">${nombreArea}</span>
                <span class="dropdown-item-sub">🏢 ${salaTxt} | 👨‍⚕️ ${datos.requeridos.join(' + ')}</span>
            `;
            item.addEventListener('click', () => {
                inputBuscadorAreaMed.value = nombreArea;
                inputHiddenAreaMed.value = nombreArea;
                dropdownAreaMedRRHH.style.display = 'none';
            });
            dropdownAreaMedRRHH.appendChild(item);
        }
    });

    if (coincidencias === 0) {
        dropdownAreaMedRRHH.innerHTML = `<div class="dropdown-vacio">No se encontraron áreas para "${filtro}".</div>`;
    }
}

inputBuscadorAreaMed.addEventListener('focus', () => {
    dropdownEspRRHH.style.display = 'none';
    renderizarDropdownAreaMedico(inputBuscadorAreaMed.value);
    dropdownAreaMedRRHH.style.display = 'block';
});

inputBuscadorAreaMed.addEventListener('input', function() {
    inputHiddenAreaMed.value = '';
    renderizarDropdownAreaMedico(this.value);
    dropdownAreaMedRRHH.style.display = 'block';
});

document.getElementById('btnAgregarMedico').addEventListener('click', () => {
    const nombre = inputMedicoNombre.value.trim();
    const especialidad = inputMedicoEsp.value.trim();
    let areaAsignada = inputHiddenAreaMed.value;

    // Si escribió en el buscador de área sin hacer clic, tomar la primera coincidencia
    if (!areaAsignada && inputBuscadorAreaMed.value.trim() !== '') {
        renderizarDropdownAreaMedico(inputBuscadorAreaMed.value);
        const primera = dropdownAreaMedRRHH.querySelector('.dropdown-item-titulo');
        if (primera) {
            areaAsignada = primera.textContent;
            inputBuscadorAreaMed.value = areaAsignada;
            inputHiddenAreaMed.value = areaAsignada;
        }
    }

    if (!nombre || !especialidad || !areaAsignada) {
        mostrarAlerta("Por favor complete el Nombre del médico, su Especialidad y seleccione el Área Médica asignada.", "Campos Incompletos");
        return;
    }

    const medicos = obtenerMedicosRRHH();
    const nuevoId = medicos.length > 0 ? Math.max(...medicos.map(m => m.id)) + 1 : 1;

    medicos.unshift({
        id: nuevoId,
        nombre,
        especialidad,
        areaAsignada,
        disponible: true,
        guardia: 0,
        estadoLaboral: "Activo",
        detalleDescanso: "Turno normal"
    });

    const protocolos = obtenerProtocolosRRHH();
    if (protocolos[areaAsignada] && !protocolos[areaAsignada].requeridos.includes(especialidad)) {
        protocolos[areaAsignada].requeridos.push(especialidad);
        guardarProtocolosRRHH(protocolos);
    }

    guardarMedicosRRHH(medicos);

    inputMedicoNombre.value = '';
    inputMedicoEsp.value = '';
    inputBuscadorAreaMed.value = '';
    inputHiddenAreaMed.value = '';
    dropdownEspRRHH.style.display = 'none';
    dropdownAreaMedRRHH.style.display = 'none';

    renderizarTodoRRHH();
    mostrarAlerta(`Se ha incorporado a la plantilla:\n• ${nombre}\n• Especialidad: ${especialidad}\n• Área asignada: ${areaAsignada}`, "Médico Agregado");
});

document.getElementById('btnLimpiarMedico').addEventListener('click', () => {
    inputMedicoNombre.value = '';
    inputMedicoEsp.value = '';
    inputBuscadorAreaMed.value = '';
    inputHiddenAreaMed.value = '';
});

inputFiltroMedicos.addEventListener('input', () => renderizarTodoRRHH());

document.getElementById('gridMedicosRRHH').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-eliminar-medico')) {
        const idBorrar = parseInt(e.target.getAttribute('data-id'));
        let medicos = obtenerMedicosRRHH();
        const medicoEliminado = medicos.find(m => m.id === idBorrar);

        if (medicoEliminado) {
            medicos = medicos.filter(m => m.id !== idBorrar);
            guardarMedicosRRHH(medicos);
            renderizarTodoRRHH();
            mostrarAlerta(`Se ha dado de baja definitiva del sistema a:\n${medicoEliminado.nombre} (${medicoEliminado.especialidad})`, "Médico Eliminado");
        }
    }
});

// =========================================================================
// 5. SECCIÓN 2: VACACIONES Y DESCANSOS (Con buscador de Médico y filtro de ausentes)
// =========================================================================
const inputBuscadorMedDescanso = document.getElementById('buscadorMedicoDescanso');
const inputHiddenMedDescanso = document.getElementById('selectMedicoDescanso');
const dropdownMedDescanso = document.getElementById('dropdownMedicoDescanso');

const selectTipoEstado = document.getElementById('selectTipoEstado');
const inputDetalleHorario = document.getElementById('inputDetalleHorario');
const inputFiltroEstados = document.getElementById('filtroEstadosMedicos');

function renderizarDropdownMedicoDescanso(filtro = "") {
    const medicos = obtenerMedicosRRHH();
    const filtroNorm = normalizarTexto(filtro);

    dropdownMedDescanso.innerHTML = "";
    let coincidencias = 0;

    medicos.forEach(m => {
        const estado = m.estadoLaboral || "Activo";
        const textoBusqueda = normalizarTexto(`${m.nombre} ${m.especialidad} ${m.areaAsignada || ''} ${estado}`);

        if (textoBusqueda.includes(filtroNorm)) {
            coincidencias++;
            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo" data-id="${m.id}" data-nombre="${m.nombre} (${m.especialidad})">${m.nombre} — ${m.especialidad}</span>
                <span class="dropdown-item-sub">🏥 Área: ${m.areaAsignada || 'General'} | Estado actual: <strong>${estado}</strong></span>
            `;
            item.addEventListener('click', () => {
                inputBuscadorMedDescanso.value = `${m.nombre} — ${m.especialidad}`;
                inputHiddenMedDescanso.value = String(m.id);
                selectTipoEstado.value = m.estadoLaboral || "Activo";
                dropdownMedDescanso.style.display = 'none';
            });
            dropdownMedDescanso.appendChild(item);
        }
    });

    if (coincidencias === 0) {
        dropdownMedDescanso.innerHTML = `<div class="dropdown-vacio">No se encontraron médicos con "${filtro}".</div>`;
    }
}

inputBuscadorMedDescanso.addEventListener('focus', () => {
    renderizarDropdownMedicoDescanso(inputBuscadorMedDescanso.value);
    dropdownMedDescanso.style.display = 'block';
});

inputBuscadorMedDescanso.addEventListener('input', function() {
    inputHiddenMedDescanso.value = '';
    renderizarDropdownMedicoDescanso(this.value);
    dropdownMedDescanso.style.display = 'block';
});

document.getElementById('btnLimpiarDescanso').addEventListener('click', () => {
    inputBuscadorMedDescanso.value = '';
    inputHiddenMedDescanso.value = '';
    selectTipoEstado.value = 'Activo';
    inputDetalleHorario.value = '';
});

document.getElementById('btnAplicarEstadoMedico').addEventListener('click', () => {
    // Si escribió el nombre del médico sin hacer clic en la lista, tomar el primero que coincida
    if (!inputHiddenMedDescanso.value && inputBuscadorMedDescanso.value.trim() !== '') {
        renderizarDropdownMedicoDescanso(inputBuscadorMedDescanso.value);
        const primero = dropdownMedDescanso.querySelector('.dropdown-item-titulo');
        if (primero) {
            inputHiddenMedDescanso.value = primero.getAttribute('data-id');
            inputBuscadorMedDescanso.value = primero.textContent;
        }
    }

    const idMedico = parseInt(inputHiddenMedDescanso.value);
    const nuevoEstado = selectTipoEstado.value;
    const detalle = inputDetalleHorario.value.trim() || (nuevoEstado === "Activo" ? "En turno normal" : "Autorizado por RRHH");

    if (!idMedico) {
        mostrarAlerta("Por favor busque y seleccione un médico de la lista.", "Selección Requerida");
        return;
    }

    const medicos = obtenerMedicosRRHH();
    const medico = medicos.find(m => m.id === idMedico);

    if (medico) {
        medico.estadoLaboral = nuevoEstado;
        medico.detalleDescanso = detalle;
        medico.disponible = (nuevoEstado === "Activo");

        guardarMedicosRRHH(medicos);
        inputBuscadorMedDescanso.value = '';
        inputHiddenMedDescanso.value = '';
        inputDetalleHorario.value = '';
        dropdownMedDescanso.style.display = 'none';
        renderizarTodoRRHH();

        mostrarAlerta(
            `Médico: ${medico.nombre} (${medico.especialidad})\nNuevo Estado: ${nuevoEstado}\nDetalle: ${detalle}\nDisponibilidad en Unidad Médica: ${medico.disponible ? 'Disponible' : 'No Disponible (En descanso/baja)'}`,
            "Estado Laboral Actualizado"
        );
    }
});

inputFiltroEstados.addEventListener('input', () => renderizarTodoRRHH());

document.getElementById('listaEstadosMedicos').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-reincorporar')) {
        const idMed = parseInt(e.target.getAttribute('data-id'));
        const medicos = obtenerMedicosRRHH();
        const med = medicos.find(m => m.id === idMed);
        if (med) {
            med.estadoLaboral = "Activo";
            med.detalleDescanso = "Reincorporado a turno normal";
            med.disponible = true;
            guardarMedicosRRHH(medicos);
            renderizarTodoRRHH();
        }
    }
});

// =========================================================================
// 6. SECCIÓN 3: NUEVAS ENFERMEDADES (Con buscador de casillas de áreas y de catálogo)
// =========================================================================
const inputCondNombre = document.getElementById('nuevaCondNombre');
const selectCondCategoria = document.getElementById('nuevaCondCategoria');
const inputCondGravedad = document.getElementById('nuevaCondGravedad');
const selectCondSexo = document.getElementById('nuevaCondSexo');
const inputFiltroCheckboxes = document.getElementById('filtroCheckboxesAreas');
const inputFiltroCatalogoEnf = document.getElementById('filtroCatalogoEnfermedades');
const contadorAreasMarcadas = document.getElementById('contadorAreasMarcadas');

inputCondGravedad.addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
    if (this.value !== '') {
        let v = parseInt(this.value, 10);
        if (v > 10) this.value = 10;
        if (v < 1) this.value = 1;
    }
});

// Filtrar las casillas de áreas médicas sin perder las que ya están marcadas
inputFiltroCheckboxes.addEventListener('input', function() {
    const filtro = normalizarTexto(this.value);
    document.querySelectorAll('#checkboxesAreasEnfermedad label').forEach(lbl => {
        const textoArea = normalizarTexto(lbl.textContent);
        lbl.style.display = textoArea.includes(filtro) ? 'flex' : 'none';
    });
});

document.getElementById('checkboxesAreasEnfermedad').addEventListener('change', () => {
    const totalMarcadas = document.querySelectorAll('.chk-area-enfermedad:checked').length;
    contadorAreasMarcadas.textContent = totalMarcadas;
});

document.getElementById('btnLimpiarEnfermedad').addEventListener('click', () => {
    inputCondNombre.value = '';
    inputCondGravedad.value = '';
    selectCondSexo.value = '';
    inputFiltroCheckboxes.value = '';
    document.querySelectorAll('.chk-area-enfermedad').forEach(c => c.checked = false);
    document.querySelectorAll('#checkboxesAreasEnfermedad label').forEach(lbl => lbl.style.display = 'flex');
    contadorAreasMarcadas.textContent = '0';
});

document.getElementById('btnAgregarEnfermedad').addEventListener('click', () => {
    const nombre = inputCondNombre.value.trim();
    const categoria = selectCondCategoria.value;
    const gravedad = parseInt(inputCondGravedad.value, 10);
    const sexoPermitido = selectCondSexo.value;

    const areasMarcadas = Array.from(document.querySelectorAll('.chk-area-enfermedad:checked')).map(c => c.value);

    if (!nombre || !gravedad || areasMarcadas.length === 0) {
        mostrarAlerta("Por favor ingrese el nombre de la enfermedad, su nivel de gravedad (1-10) y marque al menos un Área Médica compatible.", "Datos Incompletos");
        return;
    }

    const catalogo = obtenerEnfermedadesRRHH();
    const nuevaEntrada = {
        categoria,
        gravedad,
        areas: areasMarcadas,
        personalizadaRRHH: true
    };
    if (sexoPermitido) {
        nuevaEntrada.sexoPermitido = sexoPermitido;
    }

    catalogo[nombre] = nuevaEntrada;
    guardarEnfermedadesRRHH(catalogo);

    document.getElementById('btnLimpiarEnfermedad').click();
    renderizarTodoRRHH();

    mostrarAlerta(
        `Se ha registrado en el catálogo clínico:\n• ${nombre}\n• Categoría: ${categoria}\n• Gravedad en Triage: ${gravedad}/10\n• Áreas vinculadas: ${areasMarcadas.join(', ')}`,
        "Nueva Enfermedad Agregada"
    );
});

inputFiltroCatalogoEnf.addEventListener('input', () => renderizarTodoRRHH());

document.getElementById('listaEnfermedadesRRHH').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-borrar-enfermedad')) {
        const nombreBorrar = e.target.getAttribute('data-nombre');
        const catalogo = obtenerEnfermedadesRRHH();
        if (catalogo[nombreBorrar]) {
            delete catalogo[nombreBorrar];
            guardarEnfermedadesRRHH(catalogo);
            renderizarTodoRRHH();
        }
    }
});

// =========================================================================
// 7. SECCIÓN 4: CAMBIO DE SALAS (Con buscador de Área a reubicar y filtro de Salas)
// =========================================================================
const inputBuscadorAreaReubicar = document.getElementById('buscadorAreaReubicar');
const inputHiddenAreaReubicar = document.getElementById('selectAreaReubicar');
const dropdownAreaReubicar = document.getElementById('dropdownAreaReubicar');

const selectNuevoPiso = document.getElementById('selectNuevoPiso');
const inputNuevoNumSala = document.getElementById('inputNuevoNumSala');
const selectNuevoPasillo = document.getElementById('selectNuevoPasillo');
const inputNuevasCamas = document.getElementById('inputNuevasCamas');
const inputFiltroSalas = document.getElementById('filtroSalasRRHH');

function seleccionarAreaParaReubicar(nombreArea) {
    const salas = obtenerSalasRRHH();
    const info = salas[nombreArea];
    if (!info) return;

    inputBuscadorAreaReubicar.value = `${nombreArea} (Actual: ${info.sala})`;
    inputHiddenAreaReubicar.value = nombreArea;
    dropdownAreaReubicar.style.display = 'none';

    selectNuevoPiso.value = String(info.piso);
    inputNuevoNumSala.value = info.numSala;
    inputNuevasCamas.value = info.totalCamas;
    const letraPasillo = info.pasillo.replace('Pasillo ', '').split(' ')[0];
    if (["A", "B", "C", "D"].includes(letraPasillo)) {
        selectNuevoPasillo.value = letraPasillo;
    }
}

function renderizarDropdownAreaReubicar(filtro = "") {
    const salas = obtenerSalasRRHH();
    const filtroNorm = normalizarTexto(filtro);

    dropdownAreaReubicar.innerHTML = "";
    let coincidencias = 0;

    Object.entries(salas)
        .sort(([, a], [, b]) => a.piso !== b.piso ? a.piso - b.piso : a.numSala - b.numSala)
        .forEach(([nombreArea, info]) => {
            const textoBusqueda = normalizarTexto(`${nombreArea} ${info.sala} ${info.pasillo}`);
            if (textoBusqueda.includes(filtroNorm)) {
                coincidencias++;
                const item = document.createElement('div');
                item.className = 'dropdown-item';
                item.innerHTML = `
                    <span class="dropdown-item-titulo" data-area="${nombreArea}">${nombreArea}</span>
                    <span class="dropdown-item-sub">🏢 Ubicación actual: <strong>${info.sala}</strong> (${info.pasillo}) — 🛏️ ${info.totalCamas} camas</span>
                `;
                item.addEventListener('click', () => {
                    seleccionarAreaParaReubicar(nombreArea);
                });
                dropdownAreaReubicar.appendChild(item);
            }
        });

    if (coincidencias === 0) {
        dropdownAreaReubicar.innerHTML = `<div class="dropdown-vacio">No se encontraron áreas o salas con "${filtro}".</div>`;
    }
}

inputBuscadorAreaReubicar.addEventListener('focus', () => {
    renderizarDropdownAreaReubicar("");
    dropdownAreaReubicar.style.display = 'block';
});

inputBuscadorAreaReubicar.addEventListener('input', function() {
    inputHiddenAreaReubicar.value = '';
    renderizarDropdownAreaReubicar(this.value);
    dropdownAreaReubicar.style.display = 'block';
});

document.getElementById('btnLimpiarSala').addEventListener('click', () => {
    inputBuscadorAreaReubicar.value = '';
    inputHiddenAreaReubicar.value = '';
    inputNuevoNumSala.value = '';
    inputNuevasCamas.value = '';
});

document.getElementById('btnGuardarCambioSala').addEventListener('click', () => {
    if (!inputHiddenAreaReubicar.value && inputBuscadorAreaReubicar.value.trim() !== '') {
        renderizarDropdownAreaReubicar(inputBuscadorAreaReubicar.value);
        const primera = dropdownAreaReubicar.querySelector('.dropdown-item-titulo');
        if (primera) {
            seleccionarAreaParaReubicar(primera.getAttribute('data-area'));
        }
    }

    const areaElegida = inputHiddenAreaReubicar.value;
    const nuevoPiso = parseInt(selectNuevoPiso.value, 10);
    const nuevoNumSala = parseInt(inputNuevoNumSala.value, 10);
    const letraPasillo = selectNuevoPasillo.value;
    const nuevasCamas = parseInt(inputNuevasCamas.value, 10) || 4;

    if (!areaElegida || !nuevoNumSala) {
        mostrarAlerta("Por favor busque y seleccione el Área Médica e indique el nuevo número de Sala.", "Datos Incompletos");
        return;
    }

    const salas = obtenerSalasRRHH();
    const nuevaEtiquetaSala = `Sala ${nuevoNumSala} Piso ${nuevoPiso}`;
    const nuevoPasilloTexto = `Pasillo ${letraPasillo} (Piso ${nuevoPiso})`;

    const datosAnteriores = { ...salas[areaElegida] };

    const areaOcupante = Object.keys(salas).find(
        k => k !== areaElegida && salas[k].piso === nuevoPiso && salas[k].numSala === nuevoNumSala
    );

    let mensajeIntercambio = "";
    if (areaOcupante) {
        salas[areaOcupante].piso = datosAnteriores.piso;
        salas[areaOcupante].numSala = datosAnteriores.numSala;
        salas[areaOcupante].sala = datosAnteriores.sala;
        salas[areaOcupante].pasillo = datosAnteriores.pasillo;
        mensajeIntercambio = `\n\n🔄 Nota: Como "${areaOcupante}" ocupaba esa ubicación, fue intercambiada automáticamente a ${datosAnteriores.sala}.`;
    }

    salas[areaElegida].piso = nuevoPiso;
    salas[areaElegida].numSala = nuevoNumSala;
    salas[areaElegida].sala = nuevaEtiquetaSala;
    salas[areaElegida].pasillo = nuevoPasilloTexto;
    salas[areaElegida].totalCamas = Math.min(10, Math.max(1, nuevasCamas));

    guardarSalasRRHH(salas);
    inputBuscadorAreaReubicar.value = `${areaElegida} (Actual: ${nuevaEtiquetaSala})`;
    renderizarTodoRRHH();

    mostrarAlerta(
        `El área de "${areaElegida}" ha sido reubicada exitosamente:\n• Nueva Ubicación: ${nuevaEtiquetaSala}\n• Pasillo: ${nuevoPasilloTexto}\n• Capacidad: ${salas[areaElegida].totalCamas} camas${mensajeIntercambio}`,
        "Cambio de Sala Aplicado"
    );
});

inputFiltroSalas.addEventListener('input', () => renderizarTodoRRHH());

// =========================================================================
// 8. RENDERIZADO GENERAL CON FILTROS EN TIEMPO REAL EN LAS 4 SECCIONES
// =========================================================================
function renderizarTodoRRHH() {
    const medicos = obtenerMedicosRRHH();
    const protocolos = obtenerProtocolosRRHH();
    const enfermedades = obtenerEnfermedadesRRHH();
    const salas = obtenerSalasRRHH();
    const nombresAreas = Object.keys(protocolos);

    // KPIs superiores
    document.getElementById('rrhhTotalMedicos').textContent = medicos.length;
    document.getElementById('rrhhMedicosAusentes').textContent = medicos.filter(m => m.estadoLaboral && m.estadoLaboral !== 'Activo').length;

    // Checkboxes de áreas para nuevas enfermedades
    const divCheckboxes = document.getElementById('checkboxesAreasEnfermedad');
    if (divCheckboxes.children.length === 0) {
        divCheckboxes.innerHTML = nombresAreas.map(a => `
            <label style="font-size: 0.8rem; display: flex; align-items: center; gap: 6px; cursor: pointer;">
                <input type="checkbox" class="chk-area-enfermedad" value="${a}"> ${a}
            </label>
        `).join('');
    }

    // 1. Renderizar Cuadrícula Filtrada de Médicos
    const filtroMedTexto = normalizarTexto(inputFiltroMedicos.value);
    const gridMedicos = document.getElementById('gridMedicosRRHH');
    gridMedicos.innerHTML = '';

    const medicosFiltrados = medicos.filter(m =>
        normalizarTexto(`${m.nombre} ${m.especialidad} ${m.areaAsignada || ''} ${m.estadoLaboral || 'Activo'}`).includes(filtroMedTexto)
    );
    document.getElementById('contadorPlantillaFiltrada').textContent = medicosFiltrados.length;

    medicosFiltrados.forEach(m => {
        const estado = m.estadoLaboral || "Activo";
        const esActivo = estado === "Activo";
        const colorBorde = esActivo ? "#2e7d32" : "#ef6c00";

        gridMedicos.innerHTML += `
            <div style="background: #ffffff; border: 1px solid var(--border-color); border-left: 4px solid ${colorBorde}; padding: 12px 14px; border-radius: 8px; display: flex; flex-direction: column; justify-content: space-between; gap: 6px;">
                <div>
                    <div style="font-weight: 700; font-size: 0.94rem; color: var(--text-dark);">${m.nombre}</div>
                    <div style="font-size: 0.82rem; color: var(--primary-blue); font-weight: 600;">👨‍⚕️ ${m.especialidad}</div>
                    <div style="font-size: 0.8rem; color: var(--text-muted);">🏥 Área: <strong>${m.areaAsignada || 'Rotación General'}</strong></div>
                    <div style="font-size: 0.78rem; color: ${colorBorde}; font-weight: 600; margin-top: 4px;">● ${estado} (${m.detalleDescanso || 'Turno normal'})</div>
                </div>
                <button type="button" class="btn-eliminar btn-eliminar-medico" data-id="${m.id}" style="margin-top: 6px; width: 100%; padding: 6px; font-size: 0.8rem;">🗑️ Eliminar Médico</button>
            </div>
        `;
    });

    // 2. Renderizar Lista Filtrada de Vacaciones / Descansos / Enfermedad
    const filtroAusentesTexto = normalizarTexto(inputFiltroEstados.value);
    const divEstados = document.getElementById('listaEstadosMedicos');
    divEstados.innerHTML = '';

    const medicosAusentes = medicos
        .filter(m => m.estadoLaboral && m.estadoLaboral !== "Activo")
        .filter(m => normalizarTexto(`${m.nombre} ${m.especialidad} ${m.areaAsignada || ''} ${m.estadoLaboral} ${m.detalleDescanso || ''}`).includes(filtroAusentesTexto));

    document.getElementById('contadorAusentesFiltrados').textContent = medicosAusentes.length;

    if (medicosAusentes.length === 0) {
        divEstados.innerHTML = `<p style="justify-content: center; color: var(--text-muted);">No hay médicos en descanso, vacaciones o baja que coincidan con el filtro.</p>`;
    } else {
        medicosAusentes.forEach(m => {
            divEstados.innerHTML += `
                <div class="feed-item" style="border-left: 4px solid #ef6c00; display: flex; justify-content: space-between; align-items: center; flex-direction: row; flex-wrap: wrap; gap: 10px;">
                    <div>
                        <strong>${m.nombre}</strong> — <span style="color: var(--primary-blue); font-weight: 600;">${m.especialidad}</span> (Área: ${m.areaAsignada || 'General'})<br>
                        <span style="font-size: 0.85rem; color: #ef6c00; font-weight: 700;">Estado: ${m.estadoLaboral}</span> | 
                        <span style="font-size: 0.85rem; color: var(--text-muted);">Detalle: ${m.detalleDescanso}</span>
                    </div>
                    <button type="button" class="btn-reincorporar" data-id="${m.id}" style="background-color: #2e7d32; padding: 7px 14px; font-size: 0.82rem;">✔ Reincorporar a Turno Activo</button>
                </div>
            `;
        });
    }

    // 3. Renderizar Catálogo Filtrado de Enfermedades
    const filtroEnfTexto = normalizarTexto(inputFiltroCatalogoEnf.value);
    const entradasEnf = Object.entries(enfermedades).filter(([nombreCond, datos]) =>
        normalizarTexto(`${nombreCond} ${datos.categoria} ${datos.areas.join(' ')}`).includes(filtroEnfTexto)
    );

    document.getElementById('contadorEnfermedadesRRHH').textContent = entradasEnf.length;
    const divEnf = document.getElementById('listaEnfermedadesRRHH');
    divEnf.innerHTML = '';

    entradasEnf.forEach(([nombreCond, datos]) => {
        divEnf.innerHTML += `
            <div class="feed-item" style="border-left: 4px solid var(--primary-blue); display: flex; justify-content: space-between; align-items: center; flex-direction: row; flex-wrap: wrap; gap: 10px;">
                <div>
                    <strong>${nombreCond}</strong> <span style="font-size: 0.78rem; background: #e2e8f0; padding: 2px 8px; border-radius: 10px;">${datos.categoria}</span><br>
                    <span style="font-size: 0.82rem; color: var(--text-muted);">⚡ Gravedad Triage: <strong>${datos.gravedad}/10</strong> | 🏥 Áreas: ${datos.areas.join(', ')}</span>
                </div>
                <button type="button" class="btn-eliminar btn-borrar-enfermedad" data-nombre="${nombreCond}" style="padding: 5px 12px; font-size: 0.78rem;">Eliminar</button>
            </div>
        `;
    });

    // 4. Renderizar Mapa Filtrado de Salas por Área
    const filtroSalaTexto = normalizarTexto(inputFiltroSalas.value);
    const gridSalas = document.getElementById('gridSalasRRHH');
    gridSalas.innerHTML = '';

    const salasFiltradas = Object.entries(salas)
        .filter(([nombreArea, s]) => normalizarTexto(`${nombreArea} ${s.sala} ${s.pasillo} piso ${s.piso}`).includes(filtroSalaTexto))
        .sort(([, a], [, b]) => a.piso !== b.piso ? a.piso - b.piso : a.numSala - b.numSala);

    document.getElementById('contadorSalasFiltradas').textContent = salasFiltradas.length;

    salasFiltradas.forEach(([nombreArea, s]) => {
        const colorPiso = s.piso === 1 ? 'var(--primary-blue)' : '#2e7d32';
        gridSalas.innerHTML += `
            <div style="background: #ffffff; border: 1px solid var(--border-color); border-left: 4px solid ${colorPiso}; padding: 12px 14px; border-radius: 8px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <strong style="color: ${colorPiso}; font-size: 0.95rem;">${s.sala}</strong>
                    <span style="font-size: 0.75rem; background: #f0f4f8; padding: 2px 8px; border-radius: 10px;">${s.pasillo}</span>
                </div>
                <div style="font-weight: 600; font-size: 0.9rem; margin-top: 4px; color: var(--text-dark);">${nombreArea}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;">🛏️ Capacidad configurada: <strong>${s.totalCamas} camas</strong></div>
            </div>
        `;
    });
}

// 9. DETECTOR GLOBAL DE TECLA ENTER PARA TODOS LOS APARTADOS DE RRHH
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const modal = document.getElementById('modalSistema');

        if (modal && modal.style.display === 'flex') {
            e.preventDefault();
            modal.style.display = 'none';
            return;
        }

        // Si el cursor está dentro de una barra de búsqueda de filtrado de tablas/listas, no dispara el guardado
        if (e.target && e.target.classList.contains('rrhh-search-filter')) {
            e.preventDefault();
            return;
        }

        e.preventDefault();

        const secPersonal = document.getElementById('seccionPersonal');
        const secDescansos = document.getElementById('seccionDescansos');
        const secEnfermedades = document.getElementById('seccionEnfermedades');
        const secSalas = document.getElementById('seccionSalas');

        if (secPersonal && secPersonal.style.display !== 'none') {
            document.getElementById('btnAgregarMedico').click();
        } else if (secDescansos && secDescansos.style.display !== 'none') {
            document.getElementById('btnAplicarEstadoMedico').click();
        } else if (secEnfermedades && secEnfermedades.style.display !== 'none') {
            document.getElementById('btnAgregarEnfermedad').click();
        } else if (secSalas && secSalas.style.display !== 'none') {
            document.getElementById('btnGuardarCambioSala').click();
        }
    }
});

renderizarTodoRRHH();