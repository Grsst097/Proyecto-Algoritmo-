// Lógica general del panel de administración
document.addEventListener('DOMContentLoaded', () => {
    const dashboardContainer = document.querySelector('.container');
    
    // Inyección dinámica de datos del administrador del sistema
    const adminHeader = document.createElement('h3');
    adminHeader.style.color = 'var(--primary-blue)';
    adminHeader.innerText = `Ingeniero en Turno: Christopher Rafael González Ibarra`;
    
    if(dashboardContainer) {
        dashboardContainer.insertBefore(adminHeader, dashboardContainer.children[1]);
    }
});