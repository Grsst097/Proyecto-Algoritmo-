// 1. FUNCIONES DE MEMORIA COMPARTIDA E INMUTABLE POR CUI
function normalizarTexto(texto) {
    return (texto || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

function obtenerPacientesGuardados() {
    return JSON.parse(localStorage.getItem('pacientesRegistrados_SM')) || {};
}

function obtenerHistorialCompleto() {
    return JSON.parse(localStorage.getItem('historialMedico_SM')) || {};
}

// Busca un paciente por su CUI tanto en el padrón principal como en el historial médico
function buscarPacientePorCuiEnMemoria(cuiInput) {
    if (!cuiInput) return null;
    const cuiBuscado = cuiInput.trim().toUpperCase();
    const pacientes = obtenerPacientesGuardados();

    // 1. Búsqueda directa o insensible a mayúsculas/minúsculas en el registro de pacientes
    if (pacientes[cuiBuscado]) {
        return pacientes[cuiBuscado];
    }
    for (const [claveCui, datos] of Object.entries(pacientes)) {
        if (claveCui.trim().toUpperCase() === cuiBuscado) {
            return datos;
        }
    }

    // 2. Respaldo: buscar si existe en el Historial Médico y sincronizarlo
    const historial = obtenerHistorialCompleto();
    for (const [claveCui, listaEventos] of Object.entries(historial)) {
        if (claveCui.trim().toUpperCase() === cuiBuscado && Array.isArray(listaEventos) && listaEventos.length > 0) {
            const ev = listaEventos[0];
            const recuperado = {
                nombre: ev.nombre,
                fecha: ev.fechaNacimiento || ev.fecha || "",
                sexo: ev.sexo || ev.genero || ""
            };
            guardarPacienteConstante(cuiBuscado, recuperado);
            return recuperado;
        }
    }

    return null;
}

// Guarda al paciente como constante inmutable asociada a su CUI
function guardarPacienteConstante(cui, datosNuevos) {
    const cuiKey = cui.trim().toUpperCase();
    const registro = obtenerPacientesGuardados();

    if (registro[cuiKey]) {
        return Object.freeze({ ...registro[cuiKey] });
    }

    const datosConstantes = Object.freeze({
        nombre: datosNuevos.nombre.trim(),
        fecha: datosNuevos.fecha,
        sexo: datosNuevos.sexo
    });

    registro[cuiKey] = datosConstantes;
    localStorage.setItem('pacientesRegistrados_SM', JSON.stringify(registro));
    return datosConstantes;
}

function buscarCuiPorNombre(nombreBuscado) {
    const registro = obtenerPacientesGuardados();
    const nombreNorm = normalizarTexto(nombreBuscado);
    for (const [cuiGuardado, datos] of Object.entries(registro)) {
        if (normalizarTexto(datos.nombre) === nombreNorm) {
            return { cui: cuiGuardado.trim().toUpperCase(), datos };
        }
    }
    return null;
}

function registrarEventoHistorial(cui, evento) {
    const cuiKey = cui.trim().toUpperCase();
    const historial = obtenerHistorialCompleto();
    if (!historial[cuiKey]) {
        historial[cuiKey] = [];
    }
    historial[cuiKey].unshift(evento);
    localStorage.setItem('historialMedico_SM', JSON.stringify(historial));
}

function registrarEgresoAutomatico(datosEgreso) {
    const egresos = JSON.parse(localStorage.getItem('egresosHospital_SM')) || [];
    egresos.unshift({
        id: Date.now(),
        timestamp: Date.now(),
        fechaHora: new Date().toLocaleString('es-GT'),
        ...datosEgreso
    });
    localStorage.setItem('egresosHospital_SM', JSON.stringify(egresos));
}

// 2. CONFIGURACIÓN DEL HOSPITAL DE 2 PISOS: ÁREAS Y SALAS ("Sala X Piso 1" / "Sala X Piso 2")
const areasSalasHospital = {
    // --- PISO 1: URGENCIAS, QUIRÓFANOS, MATERNIDAD, PEDIATRÍA Y TRAUMA ---
    "Urgencia Cardiológica": { sala: "Sala 1 Piso 1", numSala: 1, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 4 },
    "Cuidados Intensivos": { sala: "Sala 2 Piso 1", numSala: 2, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 4 },
    "Traumatología": { sala: "Sala 3 Piso 1", numSala: 3, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 4 },
    "Cirugía Traumatológica": { sala: "Sala 4 Piso 1", numSala: 4, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 3 },
    "Unidad de Quemados y Cirugía Reconstructiva": { sala: "Sala 5 Piso 1", numSala: 5, piso: 1, pasillo: "Pasillo A (Piso 1)", totalCamas: 3 },
    "Reconstrucción Maxilofacial y Traumática": { sala: "Sala 6 Piso 1", numSala: 6, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 3 },
    "Cirugía General": { sala: "Sala 7 Piso 1", numSala: 7, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 4 },
    "Cirugía Cardiovascular": { sala: "Sala 8 Piso 1", numSala: 8, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 3 },
    "Neurocirugía": { sala: "Sala 9 Piso 1", numSala: 9, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 3 },
    "Anestesiología": { sala: "Sala 10 Piso 1", numSala: 10, piso: 1, pasillo: "Pasillo B (Piso 1)", totalCamas: 3 },
    "Maternidad y Obstetricia": { sala: "Sala 11 Piso 1", numSala: 11, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 4, sexoPermitido: "Femenino", edadMin: 12, edadMax: 60 },
    "Parto de Alto Riesgo Neonatal": { sala: "Sala 12 Piso 1", numSala: 12, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 3, sexoPermitido: "Femenino", edadMin: 12, edadMax: 60 },
    "Neonatología": { sala: "Sala 13 Piso 1", numSala: 13, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 4, edadMax: 1 },
    "Pediatría": { sala: "Sala 14 Piso 1", numSala: 14, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 4, edadMax: 17 },
    "Cirugía Reconstructiva Pediátrica": { sala: "Sala 15 Piso 1", numSala: 15, piso: 1, pasillo: "Pasillo C (Piso 1)", totalCamas: 3, edadMax: 17 },
    "Ginecología": { sala: "Sala 16 Piso 1", numSala: 16, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 4, sexoPermitido: "Femenino" },
    "Broncoscopía Respiratoria": { sala: "Sala 17 Piso 1", numSala: 17, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 3 },
    "Neumología": { sala: "Sala 18 Piso 1", numSala: 18, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 4 },
    "Endoscopía Digestiva": { sala: "Sala 19 Piso 1", numSala: 19, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 3 },
    "Hemodiálisis y Soporte Renal": { sala: "Sala 20 Piso 1", numSala: 20, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 4 },
    "Neurología": { sala: "Sala 21 Piso 1", numSala: 21, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 3 },
    "Medicina Interna": { sala: "Sala 22 Piso 1", numSala: 22, piso: 1, pasillo: "Pasillo D (Piso 1)", totalCamas: 4, edadMin: 18 },

    // --- PISO 2: ESPECIALIDADES CLÍNICAS, CIRUGÍA PLÁSTICA Y RECUPERACIÓN ---
    "Cardiología": { sala: "Sala 1 Piso 2", numSala: 1, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 4 },
    "Neurología Clínica": { sala: "Sala 2 Piso 2", numSala: 2, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 3 },
    "Gastroenterología": { sala: "Sala 3 Piso 2", numSala: 3, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 4 },
    "Nefrología": { sala: "Sala 4 Piso 2", numSala: 4, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 3 },
    "Endocrinología": { sala: "Sala 5 Piso 2", numSala: 5, piso: 2, pasillo: "Pasillo A (Piso 2)", totalCamas: 3 },
    "Geriatría": { sala: "Sala 6 Piso 2", numSala: 6, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 4, edadMin: 60 },
    "Cirugía Plástica y Estética": { sala: "Sala 7 Piso 2", numSala: 7, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 3 },
    "Cirugía Plástica Ambulatoria": { sala: "Sala 8 Piso 2", numSala: 8, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 3 },
    "Cirugía Dermatológica Reconstructiva": { sala: "Sala 9 Piso 2", numSala: 9, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 3 },
    "Dermatología": { sala: "Sala 10 Piso 2", numSala: 10, piso: 2, pasillo: "Pasillo B (Piso 2)", totalCamas: 3 },
    "Cirugía Oncológica": { sala: "Sala 11 Piso 2", numSala: 11, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 3 },
    "Quimioterapia y Control Oncológico": { sala: "Sala 12 Piso 2", numSala: 12, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 4 },
    "Oncología Médica": { sala: "Sala 13 Piso 2", numSala: 13, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 3 },
    "Hematología": { sala: "Sala 14 Piso 2", numSala: 14, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 3 },
    "Infectología": { sala: "Sala 15 Piso 2", numSala: 15, piso: 2, pasillo: "Pasillo C (Piso 2)", totalCamas: 3 },
    "Urología": { sala: "Sala 16 Piso 2", numSala: 16, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Andrología y Control Prostático": { sala: "Sala 17 Piso 2", numSala: 17, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3, sexoPermitido: "Masculino", edadMin: 18 },
    "Oftalmología": { sala: "Sala 18 Piso 2", numSala: 18, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Cirugía Oftalmológica": { sala: "Sala 19 Piso 2", numSala: 19, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Otorrinolaringología": { sala: "Sala 20 Piso 2", numSala: 20, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Reumatología": { sala: "Sala 21 Piso 2", numSala: 21, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 },
    "Psiquiatría y Salud Mental": { sala: "Sala 22 Piso 2", numSala: 22, piso: 2, pasillo: "Pasillo D (Piso 2)", totalCamas: 3 }
};

// 3. CATÁLOGO DE ENFERMEDADES, DIAGNÓSTICOS Y QUEBRADURAS
const catalogoClinico = {
    // --- QUEBRADURAS Y TRAUMATISMOS ---
    "Quebradura de Cráneo / Traumatismo Craneoencefálico": { categoria: "Quebraduras y Traumatismos", gravedad: 10, areas: ["Neurocirugía", "Cuidados Intensivos", "Neurología"] },
    "Quebradura Expuesta de Fémur": { categoria: "Quebraduras y Traumatismos", gravedad: 9, areas: ["Cirugía Traumatológica", "Cuidados Intensivos", "Traumatología"] },
    "Quebradura de Cadera": { categoria: "Quebraduras y Traumatismos", gravedad: 8, areas: ["Cirugía Traumatológica", "Traumatología", "Geriatría"] },
    "Quebradura de Costillas con Trauma Torácico": { categoria: "Quebraduras y Traumatismos", gravedad: 8, areas: ["Cirugía Traumatológica", "Cuidados Intensivos", "Neumología"] },
    "Quebradura de Tibia y Peroné": { categoria: "Quebraduras y Traumatismos", gravedad: 7, areas: ["Cirugía Traumatológica", "Traumatología"] },
    "Quebradura Nasal y Maxilofacial": { categoria: "Quebraduras y Traumatismos", gravedad: 7, areas: ["Reconstrucción Maxilofacial y Traumática", "Cirugía Plástica Ambulatoria", "Otorrinolaringología"] },
    "Quebradura de Radio y Cúbito (Antebrazo)": { categoria: "Quebraduras y Traumatismos", gravedad: 6, areas: ["Traumatología", "Cirugía Traumatológica", "Pediatría"] },
    "Quebradura de Clavícula o Hombro": { categoria: "Quebraduras y Traumatismos", gravedad: 5, areas: ["Traumatología", "Cirugía Traumatológica", "Pediatría"] },
    "Quebradura de Tobillo o Pie": { categoria: "Quebraduras y Traumatismos", gravedad: 5, areas: ["Traumatología", "Cirugía Traumatológica"] },
    "Quebradura de Mano, Muñeca o Dedos": { categoria: "Quebraduras y Traumatismos", gravedad: 4, areas: ["Traumatología", "Cirugía Plástica Ambulatoria"] },
    "Luxación Articular / Esguince Grado III": { categoria: "Quebraduras y Traumatismos", gravedad: 4, areas: ["Traumatología"] },

    // --- ENFERMEDADES Y CONDICIONES ---
    "Infarto Agudo de Miocardio (Ataque Cardíaco)": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Urgencia Cardiológica", "Cirugía Cardiovascular", "Cuidados Intensivos"] },
    "Accidente Cerebrovascular (ACV / Derrame Cerebral)": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Neurocirugía", "Neurología", "Cuidados Intensivos"] },
    "Paro Cardiorrespiratorio / Choque Séptico": { categoria: "Enfermedades y Condiciones", gravedad: 10, areas: ["Cuidados Intensivos", "Urgencia Cardiológica"] },
    "Quemaduras Severas de Segundo y Tercer Grado": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Unidad de Quemados y Cirugía Reconstructiva", "Cuidados Intensivos"] },
    "Aneurisma Cerebral / Tumor Intracraneal": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Neurocirugía", "Neurología", "Oncología Médica"] },
    "Apendicitis Aguda / Peritonitis": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Cirugía General", "Pediatría"] },
    "Insuficiencia Respiratoria Aguda / Neumonía Severa": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Cuidados Intensivos", "Neumología", "Medicina Interna"] },
    "Preeclampsia Severa / Embarazo Ectópico Roto": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Parto de Alto Riesgo Neonatal", "Maternidad y Obstetricia", "Cuidados Intensivos"], sexoPermitido: "Femenino" },
    "Síndrome de Distrés Respiratorio Neonatal / Prematurez": { categoria: "Enfermedades y Condiciones", gravedad: 9, areas: ["Neonatología", "Parto de Alto Riesgo Neonatal"] },
    "Labor de Parto Activo / Cesárea": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Maternidad y Obstetricia", "Parto de Alto Riesgo Neonatal"], sexoPermitido: "Femenino" },
    "Valvulopatía Cardíaca / Enfermedad Arterial Coronaria": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cirugía Cardiovascular", "Cardiología", "Urgencia Cardiológica"] },
    "Insuficiencia Cardíaca Congestiva": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cardiología", "Urgencia Cardiológica", "Geriatría", "Medicina Interna"] },
    "Hemorragia Digestiva / Úlcera Péptica Perforada": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Endoscopía Digestiva", "Gastroenterología", "Cirugía General"] },
    "Insuficiencia Renal Crónica / Crisis Urémica": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Hemodiálisis y Soporte Renal", "Nefrología", "Medicina Interna"] },
    "Diabetes Descompensada / Cetoacidosis Diabética": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Endocrinología", "Medicina Interna", "Cuidados Intensivos"] },
    "Obstrucción de Vías Aéreas / Broncoaspiración": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Broncoscopía Respiratoria", "Neumología", "Pediatría"] },
    "Tumor Maligno Sólido / Neoplasia Oncológica": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Cirugía Oncológica", "Quimioterapia y Control Oncológico", "Oncología Médica"] },
    "Sepsis / Infección Sistémica Aguda (Dengue Grave)": { categoria: "Enfermedades y Condiciones", gravedad: 8, areas: ["Infectología", "Cuidados Intensivos", "Medicina Interna"] },
    "Arritmia Cardíaca / Fibrilación Auricular": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cardiología", "Urgencia Cardiológica", "Medicina Interna"] },
    "Epilepsia y Crisis Convulsivas": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Neurología", "Neurología Clínica", "Pediatría"] },
    "Colecistitis Aguda / Cálculos en la Vesícula": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cirugía General", "Gastroenterología"] },
    "Carcinoma Cutáneo / Melanoma": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Cirugía Dermatológica Reconstructiva", "Dermatología", "Oncología Médica"] },
    "Anemia Severa / Leucemia / Hemofilia": { categoria: "Enfermedades y Condiciones", gravedad: 7, areas: ["Hematología", "Oncología Médica", "Quimioterapia y Control Oncológico"] },
    "Hipertensión Arterial Descontrolada": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Cardiología", "Medicina Interna", "Nefrología", "Geriatría"] },
    "Asma Bronquial / Crisis Asmática": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Neumología", "Pediatría"] },
    "Enfermedad Pulmonar Obstructiva Crónica (EPOC)": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Neumología", "Geriatría", "Medicina Interna"] },
    "Hepatitis Viral / Cirrosis Hepática": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Gastroenterología", "Infectología", "Medicina Interna"] },
    "Cálculos Renales (Litiasis / Cólico Nefrítico)": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Urología", "Nefrología"] },
    "Gastroenteritis Aguda y Deshidratación": { categoria: "Enfermedades y Condiciones", gravedad: 6, areas: ["Pediatría", "Gastroenterología", "Medicina Interna"] },
    "Hernia Inguinal, Umbilical o Hiatal": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía General", "Gastroenterología"] },
    "Labio Leporino / Malformación Congénita": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía Reconstructiva Pediátrica", "Cirugía Plástica y Estética", "Pediatría"] },
    "Cataratas, Glaucoma o Desprendimiento de Retina": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Cirugía Oftalmológica", "Oftalmología"] },
    "Trastorno Depresivo Mayor / Crisis de Ansiedad": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Psiquiatría y Salud Mental"] },
    "Dolor Agudo Postoperatorio / Sedación": { categoria: "Enfermedades y Condiciones", gravedad: 5, areas: ["Anestesiología"] },
    "Enfermedad de Parkinson / Demencia Senil / Alzheimer": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Geriatría", "Neurología Clínica", "Neurología"] },
    "Quiste Ovárico / Miomatosis Uterina / Endometriosis": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Ginecología"], sexoPermitido: "Femenino" },
    "Hiperplasia Prostática Benigna / Prostatitis": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Andrología y Control Prostático", "Urología"], sexoPermitido: "Masculino" },
    "Artritis Reumatoide / Lupus / Fibromialgia": { categoria: "Enfermedades y Condiciones", gravedad: 4, areas: ["Reumatología", "Medicina Interna", "Geriatría"] },
    "Cicatriz Queloide / Reconstrucción Estética Corporal": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Cirugía Plástica y Estética", "Cirugía Plástica Ambulatoria"] },
    "Gastritis Crónica, Colitis y Reflujo Gastroesofágico": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Gastroenterología", "Medicina Interna"] },
    "Hipotiroidismo / Hipertiroidismo / Nódulo Tiroideo": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Endocrinología", "Medicina Interna"] },
    "Infección del Tracto Urinario (Cistitis)": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Urología", "Ginecología", "Medicina Interna"] },
    "Otitis Media, Sinusitis, Rinitis o Amigdalitis": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Otorrinolaringología", "Pediatría"] },
    "Migraña y Cefalea Tensional": { categoria: "Enfermedades y Condiciones", gravedad: 3, areas: ["Neurología Clínica", "Medicina Interna"] },
    "Dermatitis, Psoriasis, Rosácea o Acné Severo": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Dermatología"] },
    "Conjuntivitis, Miopía o Astigmatismo": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Oftalmología"] },
    "Control Ginecológico Anual": { categoria: "Enfermedades y Condiciones", gravedad: 2, areas: ["Ginecología"], sexoPermitido: "Femenino" },

    // --- DIAGNÓSTICOS Y ESTUDIOS ---
    "Angiografía Coronaria y Cateterismo Diagnóstico": { categoria: "Diagnósticos y Estudios", gravedad: 7, areas: ["Urgencia Cardiológica", "Cirugía Cardiovascular", "Cardiología"] },
    "Tomografía Computarizada (TAC) Multicorte": { categoria: "Diagnósticos y Estudios", gravedad: 6, areas: ["Neurología", "Neurocirugía", "Cirugía General", "Neumología", "Oncología Médica", "Traumatología"] },
    "Biopsia Tumoral y Marcadores Oncológicos": { categoria: "Diagnósticos y Estudios", gravedad: 6, areas: ["Oncología Médica", "Cirugía Oncológica", "Quimioterapia y Control Oncológico"] },
    "Electrocardiograma (ECG) y Ecocardiograma Doppler": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Cardiología", "Urgencia Cardiológica", "Cirugía Cardiovascular", "Medicina Interna"] },
    "Resonancia Magnética (RMN) Cerebral y Articular": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Neurología", "Neurología Clínica", "Neurocirugía", "Traumatología", "Cirugía Traumatológica"] },
    "Endoscopía Digestiva Alta y Colonoscopía Diagnóstica": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Endoscopía Digestiva", "Gastroenterología"] },
    "Broncoscopía Diagnóstica y Espirometría Pulmonar": { categoria: "Diagnósticos y Estudios", gravedad: 5, areas: ["Broncoscopía Respiratoria", "Neumología"] },
    "Radiografía Digital (Rayos X) Ósea y Torácica": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Traumatología", "Cirugía Traumatológica", "Neumología", "Pediatría", "Reconstrucción Maxilofacial y Traumática"] },
    "Electroencefalograma (EEG) y Potenciales Evocados": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Neurología Clínica", "Neurología", "Pediatría"] },
    "Ultrasonido Obstétrico 4D y Monitoreo Fetal Doppler": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Ginecología", "Maternidad y Obstetricia", "Parto de Alto Riesgo Neonatal"], sexoPermitido: "Femenino" },
    "Tamiz Neonatal y Ecografía Transfontanelar": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Neonatología", "Pediatría"] },
    "Evaluación Preanestésica y Riesgo Quirúrgico (ASA)": { categoria: "Diagnósticos y Estudios", gravedad: 4, areas: ["Anestesiología", "Cirugía Plástica Ambulatoria", "Cirugía General"] },
    "Prueba de Esfuerzo Cardiovascular (Ergometría)": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Cardiología"] },
    "Biopsia Cutánea y Dermatoscopía Digital": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Dermatología", "Cirugía Dermatológica Reconstructiva", "Cirugía Plástica y Estética"] },
    "Perfil Renal, Ecografía Vesical y Urodinamia": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Nefrología", "Urología", "Hemodiálisis y Soporte Renal"] },
    "Antígeno Prostático Específico (PSA) y Ultrasonido": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Andrología y Control Prostático", "Urología"], sexoPermitido: "Masculino" },
    "Biometría Hemática, Coagulograma y Panel Infeccioso": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Hematología", "Infectología", "Medicina Interna"] },
    "Perfil Tiroideo y Hemoglobina Glicosilada": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Endocrinología", "Medicina Interna"] },
    "Evaluación Psicométrica y Diagnóstico Psiquiátrico": { categoria: "Diagnósticos y Estudios", gravedad: 3, areas: ["Psiquiatría y Salud Mental"] },
    "Mamografía Digital y Papanicolaou": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Ginecología", "Oncología Médica"], sexoPermitido: "Femenino" },
    "Fondo de Ojo, Campimetría y Tonometría Ocular": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Oftalmología", "Cirugía Oftalmológica"] },
    "Audiometría Tonal y Nasofibrolaringoscopía": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Otorrinolaringología"] },
    "Densitometría Ósea y Perfil Reumatológico": { categoria: "Diagnósticos y Estudios", gravedad: 2, areas: ["Reumatología", "Geriatría", "Traumatología"] }
};

// 4. SINCRONIZACIÓN CON RECURSOS HUMANOS (Ejecutada después de inicializar ambos objetos)
(function sincronizarSalasConRRHH() {
    const salasRRHH = JSON.parse(localStorage.getItem('salasRRHH_SM'));
    if (salasRRHH) {
        Object.assign(areasSalasHospital, salasRRHH);
    }
    const enfermedadesRRHH = JSON.parse(localStorage.getItem('catalogoClinicoRRHH_SM'));
    if (enfermedadesRRHH) {
        Object.assign(catalogoClinico, enfermedadesRRHH);
    }
})();

// 5. ESTRUCTURA DEL GRAFO HOSPITALARIO Y BÚSQUEDA EN ANCHURA (BFS)
class GrafoHospital {
    constructor() {
        this.adyacencia = {};
        this.estadoSalas = {};
        this.construirGrafoHospitalario();
    }

    agregarNodo(nodo) {
        if (!this.adyacencia[nodo]) {
            this.adyacencia[nodo] = [];
        }
    }

    conectar(nodoA, nodoB) {
        this.agregarNodo(nodoA);
        this.agregarNodo(nodoB);
        if (!this.adyacencia[nodoA].includes(nodoB)) this.adyacencia[nodoA].push(nodoB);
        if (!this.adyacencia[nodoB].includes(nodoA)) this.adyacencia[nodoB].push(nodoA);
    }

    construirGrafoHospitalario() {
        const entrada = "Ingreso Emergencias (Piso 1)";
        const elevadorP1 = "Elevador Central (Piso 1)";
        const elevadorP2 = "Elevador Central (Piso 2)";

        this.conectar(entrada, "Pasillo A (Piso 1)");
        this.conectar("Pasillo A (Piso 1)", "Pasillo B (Piso 1)");
        this.conectar("Pasillo B (Piso 1)", "Pasillo C (Piso 1)");
        this.conectar("Pasillo C (Piso 1)", "Pasillo D (Piso 1)");

        this.conectar(entrada, elevadorP1);
        this.conectar(elevadorP1, elevadorP2);

        this.conectar(elevadorP2, "Pasillo A (Piso 2)");
        this.conectar("Pasillo A (Piso 2)", "Pasillo B (Piso 2)");
        this.conectar("Pasillo B (Piso 2)", "Pasillo C (Piso 2)");
        this.conectar("Pasillo C (Piso 2)", "Pasillo D (Piso 2)");

        Object.entries(areasSalasHospital).forEach(([nombreArea, info]) => {
            this.conectar(info.pasillo, info.sala);

            const camas = [];
            for (let i = 1; i <= info.totalCamas; i++) {
                camas.push({ numero: i, ocupada: false, pacienteId: null });
            }

            this.estadoSalas[nombreArea] = {
                ...info,
                area: nombreArea,
                camas
            };
        });
    }

    calcularRutaBFS(salaDestino) {
        const inicio = "Ingreso Emergencias (Piso 1)";
        const cola = [[inicio]];
        const visitados = new Set([inicio]);

        while (cola.length > 0) {
            const rutaActual = cola.shift();
            const nodoActual = rutaActual[rutaActual.length - 1];

            if (nodoActual === salaDestino) {
                return rutaActual;
            }

            const vecinos = this.adyacencia[nodoActual] || [];
            for (const vecino of vecinos) {
                if (!visitados.has(vecino)) {
                    visitados.add(vecino);
                    cola.push([...rutaActual, vecino]);
                }
            }
        }
        return [inicio, salaDestino];
    }

    encontrarSalaMasCercanaDisponible(areasCandidatas) {
        let mejorOpcion = null;

        areasCandidatas.forEach(nombreArea => {
            const datosSala = this.estadoSalas[nombreArea];
            if (!datosSala) return;

            const camaLibre = datosSala.camas.find(c => !c.ocupada);
            if (camaLibre) {
                const ruta = this.calcularRutaBFS(datosSala.sala);
                const distancia = ruta.length - 1;

                if (!mejorOpcion || distancia < mejorOpcion.distancia) {
                    mejorOpcion = {
                        area: nombreArea,
                        sala: datosSala.sala,
                        piso: datosSala.piso,
                        camaLibre,
                        ruta,
                        distancia
                    };
                }
            }
        });

        return mejorOpcion;
    }
}

const hospitalGrafo = new GrafoHospital();
let pacientesInternados = [];
let filtroPisoActual = "todos";

// 6. REFERENCIAS DEL DOM Y MODAL
const inputPaciente = document.getElementById('nombrePaciente') || document.getElementById('nombreP');
const inputCui = document.getElementById('cui');
const inputFecha = document.getElementById('fechaNacimiento');
const selectSexo = document.getElementById('sexo') || document.getElementById('genero');

const inputBuscadorCondicion = document.getElementById('buscadorCondicion');
const inputCondicionSeleccionada = document.getElementById('condicionMedica');
const dropdownCondiciones = document.getElementById('listaCondicionesDropdown');

const inputBuscadorArea = document.getElementById('buscadorArea');
const inputAreaSeleccionada = document.getElementById('areaMedica');
const dropdownAreas = document.getElementById('listaAreasDropdown');
const infoUbicacionCama = document.getElementById('infoUbicacionCama');

if (inputFecha) {
    inputFecha.max = new Date().toISOString().split("T")[0];
}

function establecerBloqueoDatosPersonales(bloquear) {
    inputPaciente.readOnly = bloquear;
    inputFecha.readOnly = bloquear;
    selectSexo.disabled = bloquear;

    const opacidad = bloquear ? '0.75' : '1';
    const cursor = bloquear ? 'not-allowed' : 'text';
    inputPaciente.style.opacity = opacidad;
    inputFecha.style.opacity = opacidad;
    selectSexo.style.opacity = opacidad;
    inputPaciente.style.cursor = cursor;
    inputFecha.style.cursor = cursor;
    selectSexo.style.cursor = bloquear ? 'not-allowed' : 'pointer';
}

function mostrarAlerta(mensaje, titulo = "Sistema Médico") {
    const modal = document.getElementById('modalSistema');
    document.getElementById('modalTitulo').textContent = titulo;
    document.getElementById('modalTexto').textContent = mensaje;
    modal.style.display = 'flex';
}

document.getElementById('modalBtnAceptar').addEventListener('click', () => {
    document.getElementById('modalSistema').style.display = 'none';
});

function calcularEdad(fechaNacimiento) {
    if (!fechaNacimiento) return null;
    const hoy = new Date();
    const cumple = new Date(fechaNacimiento + "T00:00:00");
    let edad = hoy.getFullYear() - cumple.getFullYear();
    const mes = hoy.getMonth() - cumple.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < cumple.getDate())) {
        edad--;
    }
    return edad;
}

// 7. VALIDACIÓN DE COMPATIBILIDAD Y CÁLCULO DE LA SALA MÁS CERCANA
function evaluarCompatibilidadArea(nombreArea, sexo, edad, condicionActiva = "") {
    const datos = areasSalasHospital[nombreArea];
    if (!datos) return { compatible: false, motivo: "Área médica no encontrada." };

    if (sexo && datos.sexoPermitido && datos.sexoPermitido !== sexo) {
        return { compatible: false, motivo: `${datos.sala} (${nombreArea}) es exclusiva para pacientes de sexo ${datos.sexoPermitido}.` };
    }

    if (edad !== null && !isNaN(edad)) {
        if (edad < 0) return { compatible: false, motivo: "La fecha de nacimiento no puede ser futura." };
        if (datos.edadMax !== undefined && edad > datos.edadMax) {
            return { compatible: false, motivo: `${datos.sala} (${nombreArea}) solo admite pacientes de hasta ${datos.edadMax} años.` };
        }
        if (datos.edadMin !== undefined && edad < datos.edadMin) {
            return { compatible: false, motivo: `${datos.sala} (${nombreArea}) requiere al menos ${datos.edadMin} años.` };
        }
    }

    if (condicionActiva && catalogoClinico[condicionActiva]) {
        if (!catalogoClinico[condicionActiva].areas.includes(nombreArea)) {
            return { compatible: false, motivo: `${datos.sala} (${nombreArea}) no corresponde a "${condicionActiva}".` };
        }
    }

    return { compatible: true, motivo: "" };
}

function evaluarCompatibilidadCondicion(nombreCondicion, sexo, edad, areaActiva = "") {
    const datos = catalogoClinico[nombreCondicion];
    if (!datos) return { compatible: false, motivo: "Condición no encontrada." };

    if (sexo && datos.sexoPermitido && datos.sexoPermitido !== sexo) {
        return { compatible: false, motivo: `"${nombreCondicion}" aplica únicamente para pacientes de sexo ${datos.sexoPermitido}.` };
    }

    if (areaActiva && !datos.areas.includes(areaActiva)) {
        return { compatible: false, motivo: `"${nombreCondicion}" no se atiende en ${areasSalasHospital[areaActiva]?.sala} (${areaActiva}).` };
    }

    const tieneAreaValida = datos.areas.some(a => evaluarCompatibilidadArea(a, sexo, edad, "").compatible);
    if (!tieneAreaValida) {
        return { compatible: false, motivo: `"${nombreCondicion}" no es compatible con la edad o sexo del paciente.` };
    }

    return { compatible: true, motivo: "" };
}

function actualizarBannerUbicacion() {
    const cond = inputCondicionSeleccionada.value;
    const area = inputAreaSeleccionada.value;
    const cuiKey = inputCui.value.trim().toUpperCase();
    const existeCui = Boolean(buscarPacientePorCuiEnMemoria(cuiKey));

    if (!cond && !area && !existeCui) {
        infoUbicacionCama.style.display = 'none';
        return;
    }

    let html = "";
    if (existeCui) {
        html += `<div style="color: #2e7d32; margin-bottom: 4px;">🔒 <strong>CUI Registrado (${cuiKey}):</strong> Los datos personales de este paciente son constantes y se han cargado automáticamente.</div>`;
    }
    if (cond && catalogoClinico[cond]) {
        html += `<div><strong>${catalogoClinico[cond].categoria}:</strong> ${cond}</div>`;
    }
    if (area && areasSalasHospital[area]) {
        const estadoSala = hospitalGrafo.estadoSalas[area];
        const camaDisponible = estadoSala.camas.find(c => !c.ocupada);
        const ruta = hospitalGrafo.calcularRutaBFS(estadoSala.sala);

        if (camaDisponible) {
            html += `<div style="margin-top: 4px;">📍 <strong>Ubicación Más Cercana Asignada:</strong> <span style="color: #2e7d32; font-weight: 700;">${estadoSala.sala}</span> — Área de <strong>${area}</strong> (Cama #${camaDisponible.numero} disponible)</div>`;
            html += `<div style="font-size: 0.82rem; color: var(--text-muted); margin-top: 2px;">🧭 <strong>Ruta más corta (BFS):</strong> ${ruta.join(' ➔ ')}</div>`;
        } else {
            html += `<div style="color: #d32f2f; margin-top: 4px;">⚠️ <strong>${estadoSala.sala} (${area}):</strong> Todas las camas de esta sala están ocupadas actualmente.</div>`;
        }
    }

    infoUbicacionCama.innerHTML = html;
    infoUbicacionCama.style.display = 'block';
}

function revalidarSelecciones() {
    const sexo = selectSexo.value;
    const edad = calcularEdad(inputFecha.value);
    const condActual = inputCondicionSeleccionada.value;
    const areaActual = inputAreaSeleccionada.value;

    if (condActual) {
        const valCond = evaluarCompatibilidadCondicion(condActual, sexo, edad, areaActual);
        if (!valCond.compatible) {
            inputBuscadorCondicion.value = '';
            inputCondicionSeleccionada.value = '';
        }
    }

    if (areaActual) {
        const valArea = evaluarCompatibilidadArea(areaActual, sexo, edad, inputCondicionSeleccionada.value);
        if (!valArea.compatible) {
            inputBuscadorArea.value = '';
            inputAreaSeleccionada.value = '';
        }
    }

    actualizarBannerUbicacion();
}

// 8. BUSCADOR INTERACTIVO DE ENFERMEDAD / DIAGNÓSTICO / QUEBRADURA
function renderizarOpcionesCondicion(filtro = "") {
    dropdownCondiciones.innerHTML = "";
    const filtroNorm = normalizarTexto(filtro);
    const sexoActual = selectSexo.value;
    const edadActual = calcularEdad(inputFecha.value);
    const areaActual = inputAreaSeleccionada.value;

    let categoriaActual = "";
    let coincidencias = 0;

    Object.entries(catalogoClinico).forEach(([nombreCond, datos]) => {
        if (!evaluarCompatibilidadCondicion(nombreCond, sexoActual, edadActual, areaActual).compatible) {
            return;
        }

        const salasCompatiblesTexto = datos.areas
            .map(a => `${a} (${areasSalasHospital[a]?.sala || ''})`)
            .join(', ');

        const textoBusqueda = normalizarTexto(`${nombreCond} ${datos.categoria} ${salasCompatiblesTexto}`);
        if (textoBusqueda.includes(filtroNorm)) {
            coincidencias++;
            if (datos.categoria !== categoriaActual) {
                categoriaActual = datos.categoria;
                const divCat = document.createElement('div');
                divCat.className = 'dropdown-categoria';
                divCat.textContent = categoriaActual;
                dropdownCondiciones.appendChild(divCat);
            }

            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">${nombreCond}</span>
                <span class="dropdown-item-sub">🛏️ Ubicaciones: ${salasCompatiblesTexto}</span>
            `;

            item.addEventListener('click', () => {
                seleccionarCondicion(nombreCond);
            });

            dropdownCondiciones.appendChild(item);
        }
    });

    if (coincidencias === 0) {
        dropdownCondiciones.innerHTML = `<div class="dropdown-vacio">No hay enfermedades, diagnósticos o quebraduras compatibles con el filtro actual.</div>`;
    }
}

function seleccionarCondicion(nombreCond) {
    inputBuscadorCondicion.value = nombreCond;
    inputCondicionSeleccionada.value = nombreCond;
    dropdownCondiciones.style.display = 'none';

    const sexo = selectSexo.value;
    const edad = calcularEdad(inputFecha.value);
    const datos = catalogoClinico[nombreCond];

    const areasCompatibles = datos.areas.filter(
        a => evaluarCompatibilidadArea(a, sexo, edad, nombreCond).compatible
    );

    if (!inputAreaSeleccionada.value || !areasCompatibles.includes(inputAreaSeleccionada.value)) {
        const salaOptima = hospitalGrafo.encontrarSalaMasCercanaDisponible(areasCompatibles);
        if (salaOptima) {
            inputAreaSeleccionada.value = salaOptima.area;
            inputBuscadorArea.value = `${salaOptima.sala} — ${salaOptima.area}`;
        } else if (areasCompatibles.length > 0) {
            const primera = areasCompatibles[0];
            inputAreaSeleccionada.value = primera;
            inputBuscadorArea.value = `${areasSalasHospital[primera].sala} — ${primera}`;
        }
    }

    actualizarBannerUbicacion();
}

// 9. BUSCADOR INTERACTIVO DE SALAS Y ÁREAS
function renderizarOpcionesArea(filtro = "") {
    dropdownAreas.innerHTML = "";
    const filtroNorm = normalizarTexto(filtro);
    const sexoActual = selectSexo.value;
    const edadActual = calcularEdad(inputFecha.value);
    const condicionActual = inputCondicionSeleccionada.value;

    let pisoActualHeader = null;
    let coincidencias = 0;

    const listaAreasOrdenadas = Object.entries(areasSalasHospital).sort(([, a], [, b]) => {
        if (a.piso !== b.piso) return a.piso - b.piso;
        return a.numSala - b.numSala;
    });

    listaAreasOrdenadas.forEach(([nombreArea, datos]) => {
        if (!evaluarCompatibilidadArea(nombreArea, sexoActual, edadActual, condicionActual).compatible) {
            return;
        }

        const estadoSala = hospitalGrafo.estadoSalas[nombreArea];
        const libres = estadoSala.camas.filter(c => !c.ocupada).length;
        const ruta = hospitalGrafo.calcularRutaBFS(datos.sala);

        const textoBusqueda = normalizarTexto(`${datos.sala} ${nombreArea} ${datos.pasillo}`);
        if (textoBusqueda.includes(filtroNorm)) {
            coincidencias++;
            if (datos.piso !== pisoActualHeader) {
                pisoActualHeader = datos.piso;
                const divCat = document.createElement('div');
                divCat.className = 'dropdown-categoria';
                divCat.textContent = datos.piso === 1
                    ? "Planta Baja — Piso 1 (Ubicaciones Más Cercanas a Emergencias)"
                    : "Nivel Superior — Piso 2 (Acceso por Elevador Central)";
                dropdownAreas.appendChild(divCat);
            }

            const item = document.createElement('div');
            item.className = 'dropdown-item';
            item.innerHTML = `
                <span class="dropdown-item-titulo">${datos.sala} — ${nombreArea}</span>
                <span class="dropdown-item-sub">🛏️ Camas libres: <strong>${libres}/${datos.totalCamas}</strong> | 📍 Distancia BFS: ${ruta.length - 1} tramos (${datos.pasillo})</span>
            `;

            item.addEventListener('click', () => {
                seleccionarArea(nombreArea);
            });

            dropdownAreas.appendChild(item);
        }
    });

    if (coincidencias === 0) {
        dropdownAreas.innerHTML = `<div class="dropdown-vacio">No hay salas compatibles con la condición y el perfil del paciente.</div>`;
    }
}

function seleccionarArea(nombreArea) {
    const info = areasSalasHospital[nombreArea];
    inputBuscadorArea.value = `${info.sala} — ${nombreArea}`;
    inputAreaSeleccionada.value = nombreArea;
    dropdownAreas.style.display = 'none';

    if (inputCondicionSeleccionada.value && !catalogoClinico[inputCondicionSeleccionada.value].areas.includes(nombreArea)) {
        inputBuscadorCondicion.value = '';
        inputCondicionSeleccionada.value = '';
    }

    actualizarBannerUbicacion();
}

inputBuscadorCondicion.addEventListener('focus', () => {
    dropdownAreas.style.display = 'none';
    renderizarOpcionesCondicion(inputBuscadorCondicion.value);
    dropdownCondiciones.style.display = 'block';
});

inputBuscadorCondicion.addEventListener('input', function() {
    inputCondicionSeleccionada.value = '';
    actualizarBannerUbicacion();
    renderizarOpcionesCondicion(this.value);
    dropdownCondiciones.style.display = 'block';
});

inputBuscadorArea.addEventListener('focus', () => {
    dropdownCondiciones.style.display = 'none';
    renderizarOpcionesArea("");
    dropdownAreas.style.display = 'block';
});

inputBuscadorArea.addEventListener('input', function() {
    inputAreaSeleccionada.value = '';
    actualizarBannerUbicacion();
    renderizarOpcionesArea(this.value);
    dropdownAreas.style.display = 'block';
});

document.addEventListener('click', (e) => {
    if (!e.target.closest('.buscador-area-container')) {
        dropdownCondiciones.style.display = 'none';
        dropdownAreas.style.display = 'none';
    }
});

// 10. VALIDACIONES Y AUTORELLENO CONSTANTE POR CUI EN TIEMPO REAL
inputPaciente.addEventListener('input', function() {
    if (this.readOnly) return;
    this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
});

function verificarYAutorellenarCui() {
    inputCui.value = inputCui.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    const cuiIngresado = inputCui.value.trim();
    const paciente = buscarPacientePorCuiEnMemoria(cuiIngresado);

    if (paciente) {
        inputPaciente.value = paciente.nombre || '';
        inputFecha.value = paciente.fecha || paciente.fechaNacimiento || '';
        selectSexo.value = paciente.sexo || paciente.genero || '';
        establecerBloqueoDatosPersonales(true);
        revalidarSelecciones();
    } else {
        establecerBloqueoDatosPersonales(false);
        actualizarBannerUbicacion();
    }
}

inputCui.addEventListener('input', verificarYAutorellenarCui);
inputCui.addEventListener('change', verificarYAutorellenarCui);

inputFecha.addEventListener('change', revalidarSelecciones);
selectSexo.addEventListener('change', revalidarSelecciones);

function limpiarFormulario() {
    establecerBloqueoDatosPersonales(false);
    inputPaciente.value = '';
    inputCui.value = '';
    inputFecha.value = '';
    selectSexo.value = '';
    inputBuscadorCondicion.value = '';
    inputCondicionSeleccionada.value = '';
    inputBuscadorArea.value = '';
    inputAreaSeleccionada.value = '';
    infoUbicacionCama.style.display = 'none';
    dropdownCondiciones.style.display = 'none';
    dropdownAreas.style.display = 'none';
}

document.getElementById('btnLimpiar').addEventListener('click', limpiarFormulario);

// 11. ASIGNACIÓN DE LA CAMA MÁS CERCANA (BFS)
function asignarCamaMasCercana() {
    const cui = inputCui.value.trim().toUpperCase();
    const pacienteExistentePorCui = buscarPacientePorCuiEnMemoria(cui);

    const paciente = pacienteExistentePorCui ? pacienteExistentePorCui.nombre : inputPaciente.value.trim();
    const fecha = pacienteExistentePorCui ? (pacienteExistentePorCui.fecha || pacienteExistentePorCui.fechaNacimiento) : inputFecha.value;
    const sexo = pacienteExistentePorCui ? (pacienteExistentePorCui.sexo || pacienteExistentePorCui.genero) : selectSexo.value;
    const edad = calcularEdad(fecha);

    if (!pacienteExistentePorCui && paciente) {
        const coincidenciaNombre = buscarCuiPorNombre(paciente);
        if (coincidenciaNombre && coincidenciaNombre.cui !== cui) {
            mostrarAlerta(
                `El paciente "${coincidenciaNombre.datos.nombre}" ya se encuentra registrado con el CUI constante: ${coincidenciaNombre.cui}.\n\nSe ha cargado su CUI oficial automáticamente.`,
                "Paciente Ya Registrado"
            );
            inputCui.value = coincidenciaNombre.cui;
            inputPaciente.value = coincidenciaNombre.datos.nombre;
            inputFecha.value = coincidenciaNombre.datos.fecha;
            selectSexo.value = coincidenciaNombre.datos.sexo;
            establecerBloqueoDatosPersonales(true);
            revalidarSelecciones();
            return;
        }
    }

    let condicion = inputCondicionSeleccionada.value;
    let area = inputAreaSeleccionada.value;

    if (!condicion && inputBuscadorCondicion.value.trim() !== '') {
        const textoCond = normalizarTexto(inputBuscadorCondicion.value);
        const encontrada = Object.keys(catalogoClinico).find(k => normalizarTexto(k) === textoCond);
        if (encontrada) seleccionarCondicion(encontrada);
        condicion = inputCondicionSeleccionada.value;
        area = inputAreaSeleccionada.value;
    }

    if (!paciente || !cui || !fecha || !sexo || !condicion || !area) {
        mostrarAlerta("Por favor complete todos los datos del paciente (Nombre, CUI, Fecha, Sexo, Enfermedad/Diagnóstico/Quebradura y Sala/Área).", "Datos Incompletos");
        return;
    }

    const valCond = evaluarCompatibilidadCondicion(condicion, sexo, edad, area);
    if (!valCond.compatible) {
        mostrarAlerta(valCond.motivo, "Incompatibilidad Clínica");
        return;
    }

    const valArea = evaluarCompatibilidadArea(area, sexo, edad, condicion);
    if (!valArea.compatible) {
        mostrarAlerta(valArea.motivo, "Sala No Compatible");
        return;
    }

    let estadoSala = hospitalGrafo.estadoSalas[area];
    let camaAsignada = estadoSala.camas.find(c => !c.ocupada);
    let areaFinal = area;

    if (!camaAsignada) {
        const areasAlternativas = catalogoClinico[condicion].areas.filter(
            a => evaluarCompatibilidadArea(a, sexo, edad, condicion).compatible
        );
        const alternativaBFS = hospitalGrafo.encontrarSalaMasCercanaDisponible(areasAlternativas);

        if (alternativaBFS) {
            areaFinal = alternativaBFS.area;
            estadoSala = hospitalGrafo.estadoSalas[areaFinal];
            camaAsignada = alternativaBFS.camaLibre;
        } else {
            mostrarAlerta(
                `Actualmente todas las camas de las salas compatibles con "${condicion}" se encuentran ocupadas.`,
                "Sin Camas Disponibles"
            );
            return;
        }
    }

    const rutaMasCorta = hospitalGrafo.calcularRutaBFS(estadoSala.sala);
    const idInternamiento = Date.now();

    camaAsignada.ocupada = true;
    camaAsignada.pacienteId = idInternamiento;

    // Guardar paciente como constante por su CUI para todos los módulos
    const datosConstantes = guardarPacienteConstante(cui, { nombre: paciente, fecha, sexo });

    registrarEventoHistorial(cui, {
        id: idInternamiento,
        modulo: "Gestión de Camas",
        fechaHora: new Date().toLocaleString('es-GT'),
        nombre: datosConstantes.nombre,
        cui,
        fechaNacimiento: datosConstantes.fecha,
        edad: calcularEdad(datosConstantes.fecha),
        sexo: datosConstantes.sexo,
        condicion,
        area: `${estadoSala.sala} (${areaFinal})`,
        gravedad: catalogoClinico[condicion].gravedad,
        equipo: [`Cama #${camaAsignada.numero} — Ruta: ${rutaMasCorta.join(' ➔ ')}`]
    });

    pacientesInternados.push({
        id: idInternamiento,
        paciente: datosConstantes.nombre,
        cui,
        fecha: datosConstantes.fecha,
        edad: calcularEdad(datosConstantes.fecha),
        sexo: datosConstantes.sexo,
        condicion,
        area: areaFinal,
        sala: estadoSala.sala,
        piso: estadoSala.piso,
        numeroCama: camaAsignada.numero,
        ruta: rutaMasCorta
    });

    mostrarAlerta(
        `Paciente: ${datosConstantes.nombre} (${calcularEdad(datosConstantes.fecha)} años)\nMotivo: ${condicion}\n\n🛏️ Ubicación más cercana asignada:\n${estadoSala.sala} — Cama #${camaAsignada.numero}\nÁrea: ${areaFinal}\n\n🧭 Ruta más corta (BFS):\n${rutaMasCorta.join(' ➔ ')}`,
        "Cama Asignada con Éxito"
    );

    limpiarFormulario();
    actualizarUI();
}

document.getElementById('btnAsignarCama').addEventListener('click', asignarCamaMasCercana);

// Detector global de tecla Enter
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const modal = document.getElementById('modalSistema');
        if (modal && modal.style.display === 'flex') {
            e.preventDefault();
            modal.style.display = 'none';
            return;
        }

        e.preventDefault();

        if (!inputCondicionSeleccionada.value && inputBuscadorCondicion.value.trim() !== '') {
            renderizarOpcionesCondicion(inputBuscadorCondicion.value);
            const primeraCond = dropdownCondiciones.querySelector('.dropdown-item-titulo');
            if (primeraCond) seleccionarCondicion(primeraCond.textContent);
        }

        asignarCamaMasCercana();
    }
});

// 12. DAR DE ALTA Y LIBERAR CAMA (+ Registro en Estadísticas)
document.getElementById('listaCamasAsignadas').addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-eliminar')) {
        const idInternamiento = parseInt(e.target.getAttribute('data-id'));
        const index = pacientesInternados.findIndex(p => p.id === idInternamiento);

        if (index !== -1) {
            const reg = pacientesInternados[index];
            const salaEstado = hospitalGrafo.estadoSalas[reg.area];
            if (salaEstado) {
                const cama = salaEstado.camas.find(c => c.numero === reg.numeroCama);
                if (cama) {
                    cama.ocupada = false;
                    cama.pacienteId = null;
                }
            }

            registrarEgresoAutomatico({
                cui: reg.cui,
                nombre: reg.paciente,
                modulo: "Gestión de Camas",
                condicion: reg.condicion,
                area: `${reg.sala} (${reg.area})`,
                detalle: `Alta de Cama #${reg.numeroCama} liberada`
            });

            pacientesInternados.splice(index, 1);
            actualizarUI();
        }
    }
});

document.querySelectorAll('.filtro-piso-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        filtroPisoActual = btn.getAttribute('data-piso');
        document.querySelectorAll('.filtro-piso-btn').forEach(b => b.classList.add('btn-secondary'));
        btn.classList.remove('btn-secondary');
        actualizarUI();
    });
});

// 13. RENDERIZADO DE LA INTERFAZ
function actualizarUI() {
    const divAsignadas = document.getElementById('listaCamasAsignadas');
    divAsignadas.innerHTML = '<h3>Pacientes Ubicados en Sala:</h3>';

    if (pacientesInternados.length === 0) {
        divAsignadas.innerHTML += '<p style="justify-content: center; color: var(--text-muted);">No hay camas ocupadas en este momento.</p>';
    } else {
        pacientesInternados.forEach(item => {
            divAsignadas.innerHTML += `
                <p style="flex-direction: column; align-items: flex-start; gap: 6px;">
                    <span style="width: 100%; display: flex; justify-content: space-between; align-items: center;">
                        <span>Paciente: <strong>${item.paciente}</strong> (${item.edad} años) — <strong style="color: #2e7d32;">${item.sala} (Cama #${item.numeroCama})</strong></span>
                        <button class="btn-eliminar" data-id="${item.id}" style="background-color: #2e7d32;">Dar de alta</button>
                    </span>
                    <span style="font-size: 0.88rem; color: var(--primary-blue); font-weight: 500;">
                        🩺 ${item.condicion} | 🏥 Área: <strong>${item.area}</strong>
                    </span>
                    <span style="font-size: 0.84rem; color: var(--text-dark);">
                        🧭 Ruta desde Emergencias: ${item.ruta.join(' ➔ ')}
                    </span>
                    <span style="font-size: 0.82rem; color: var(--text-muted);">
                        CUI: ${item.cui} | Nacimiento: ${item.fecha} | Sexo: ${item.sexo}
                    </span>
                </p>`;
        });
    }

    const grid = document.getElementById('gridSalas');
    grid.innerHTML = '';

    const listaSalas = Object.values(hospitalGrafo.estadoSalas).sort((a, b) => {
        if (a.piso !== b.piso) return a.piso - b.piso;
        return a.numSala - b.numSala;
    });

    listaSalas.forEach(s => {
        if (filtroPisoActual !== "todos" && String(s.piso) !== filtroPisoActual) return;

        const libres = s.camas.filter(c => !c.ocupada).length;
        const colorEstado = libres > 0 ? '#2e7d32' : '#d32f2f';
        const fondoTarjeta = libres > 0 ? '#ffffff' : '#f8f9fa';

        const badgesCamas = s.camas.map(c => {
            const bg = c.ocupada ? '#ffebee' : '#e8f5e9';
            const col = c.ocupada ? '#c62828' : '#2e7d32';
            const txt = c.ocupada ? 'Ocupada' : 'Libre';
            return `<span style="background: ${bg}; color: ${col}; padding: 2px 7px; border-radius: 6px; font-size: 0.73rem; font-weight: 600;">Cama ${c.numero}: ${txt}</span>`;
        }).join(' ');

        grid.innerHTML += `
            <div style="background: ${fondoTarjeta}; border: 1px solid var(--border-color); border-left: 4px solid ${colorEstado}; padding: 12px 14px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.04); display: flex; flex-direction: column; gap: 6px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: 700; font-size: 0.95rem; color: var(--primary-blue);">${s.sala}</span>
                    <span style="font-size: 0.75rem; background: #f0f4f8; padding: 2px 8px; border-radius: 12px; color: var(--text-muted);">${s.pasillo}</span>
                </div>
                <div style="font-weight: 600; font-size: 0.88rem; color: var(--text-dark);">${s.area}</div>
                <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 4px;">
                    ${badgesCamas}
                </div>
            </div>`;
    });
}

actualizarUI();