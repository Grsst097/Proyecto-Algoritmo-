import { HospitalGraph } from './estructuras/Graph.js';

// Inicializar el grafo del hospital
const hospital = new HospitalGraph();
const bedStatus = new Map();

// Configurar salas y camas
['SalaEmergencias', 'SalaGeneralA', 'UCI', 'Recuperacion'].forEach(sala => {
    hospital.addWard(sala);
    bedStatus.set(sala, 'OCUPADA'); // Por defecto ocupadas para la prueba
});

// Conectar pasillos (Aristas del grafo)
hospital.addEdge('SalaEmergencias', 'SalaGeneralA');
hospital.addEdge('SalaEmergencias', 'UCI');
hospital.addEdge('UCI', 'Recuperacion');

// Liberar una cama específica
bedStatus.set('Recuperacion', 'DISPONIBLE'); 

document.getElementById('btnBuscarCama').addEventListener('click', () => {
    // Usar algoritmo BFS interno del Grafo
    const camaLibre = hospital.findNearestAvailableBed('SalaEmergencias', bedStatus);
    const resultDiv = document.getElementById('resultadoCama');
    
    if(camaLibre) {
        resultDiv.innerHTML = `<p style="color: var(--stable-green);">Cama disponible más cercana encontrada en: <strong>${camaLibre}</strong></p>`;
    } else {
        resultDiv.innerHTML = `<p style="color: var(--urgent-red);">No hay camas disponibles en la red hospitalaria.</p>`;
    }
});